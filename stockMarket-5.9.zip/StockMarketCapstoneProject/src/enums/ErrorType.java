package enums;

public enum ErrorType 
{
notLoggedIn,
InvalidPass,
InvalidStock,
InvalidQuantity,
InvalidPrice,
NotEnoughFunds,
InvalidPlayer,
noErrors,
InvalidMarketOrder,
InvalidBidOrder,
InvalidAmendOrder,
EmptyField,
UsernameTaken,
InvalidPasswordType
}
