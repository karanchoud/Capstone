package controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import enums.ErrorType;
import enums.SuccessType;
import model.Database;
import model.ShareMarket;
import model.Validation;
import yahoofinance.Stock;

@SuppressWarnings("serial")
public class AmendOrderServlet extends HttpServlet
{
	
	private ShareMarket shareMarket = new ShareMarket();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		HttpSession session = request.getSession();
		
		if(Validation.redirectedToLogin(request, response, session))
		{
			return;
		}
		
		Database database = Database.getInstance();
		this.printRequestParameters(request, response);
		String userName = (String) session.getAttribute("username");
		String stockSymbol = request.getParameter("stockSymbol");
		BigDecimal stockPrice;
		int quantity;

		String quantitySTR = request.getParameter("quantity");
		String StockPriceSTR = request.getParameter("limitValue");
		
		if(request.getParameter("stockSymbol").equals("none"))
		{
			session.setAttribute("errorMsg", ErrorType.InvalidStock);
			
			String referer = request.getHeader("Referer");
			
			
						
				//RequestDispatcher dispatcher = request.getRequestDispatcher(referer); 
				//dispatcher.forward(request, response);
			response.sendRedirect(referer);
			return;
		}
		
		if(request.getParameter("remBuyReqBtn") != null)
		{
			System.out.println("remove buy amend btn was pressed!");
			//request.setAttribute("stockCode", request.getParameter("stockSymbol"));
			database.RemoveBuyRequest(session.getAttribute("username").toString(), request.getParameter("stockSymbol"));
			session.setAttribute("successMsg", SuccessType.amendDelete);
			RequestDispatcher dispatcher = request.getRequestDispatcher("amendBuy.jsp"); 
			dispatcher.forward(request, response);
			return;
		}
		if(request.getParameter("remSellReqBtn") != null)
		{
			System.out.println("remove sell amend btn was pressed!");
			database.RemoveSellRequest(session.getAttribute("username").toString(), request.getParameter("stockSymbol"));
			
			session.setAttribute("successMsg", SuccessType.amendDelete);
			RequestDispatcher dispatcher = request.getRequestDispatcher("amendSell.jsp"); 
			dispatcher.forward(request, response);
			return;
		}
		
		//this.printRequestParameters(request, response);

		if (!stockSymbol.endsWith(".AX")) 
		{
			stockSymbol = stockSymbol + ".AX";
		}
		
		
		if(validInput(stockSymbol, StockPriceSTR, quantitySTR) == 1) //if the form data is all valid
		{
			if(request.getParameter("OrderType").equals("buy")) //if its an amendBbuy request
			{
				System.out.println("valid input calling amendBuy");
				
				quantity = Integer.parseInt(quantitySTR);
				stockPrice = new BigDecimal(StockPriceSTR);
				
				if(shareMarket.amendBuy(userName, stockSymbol, stockPrice, quantity))
				{
					session.setAttribute("successMsg", SuccessType.amendSuccess);
				}
			}
			else //its an amendSell request
			{
				System.out.println("valid input calling amendSell");
				
				quantity = Integer.parseInt(quantitySTR);
				stockPrice = new BigDecimal(StockPriceSTR);
				
				if(shareMarket.amendSell(userName, stockSymbol, stockPrice, quantity))
				{
					session.setAttribute("successMsg", SuccessType.bidSuccess);
				}
			}
		}
		else
		{
			System.out.println("could not complete amend request, input is invalid!");
			
			session.setAttribute("errorMsg", ErrorType.InvalidAmendOrder);
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp"); 
		dispatcher.forward(request, response);
		
		
		
		
	}
	
	/**
	 * Returns True if all the form data sent by the player is valid and can be
	 * used to call a share market method
	 * 
	 * @param stockSymbol
	 * @param stockPriceSTR
	 * @param quantitySTR
	 * @return
	 * 
	 * True if Input is valid for a bidOrder or bidOrderSell
	 */
	public int validInput(String stockSymbol, String stockPriceSTR, String quantitySTR) 
	{
		if(stockIsValid(stockSymbol) && priceIsValid(stockPriceSTR) && quantityIsValid(quantitySTR))
		{
			return 1;
		}
		else
		{
			if(stockIsValid(stockSymbol) == false)
			{
				return -1; // stock not valid
			}
			if(priceIsValid(stockPriceSTR) == false)
			{
				return -2; //stockPrice entered not valid
			}
			
		}
		return -3; // quantity entered not valid
	}
	
	
	/**
	 * returns true if the quantity is a valid number
	 * 
	 * @param quantitySTR
	 * @return
	 */
	private boolean quantityIsValid(String quantitySTR) 
	{
		for (int i = 0; i < quantitySTR.length(); i++) 
		{
			if (Character.isDigit(quantitySTR.charAt(i))) 
			{
				continue;
			} 
			else 
			{
				System.out.println("quantitiy is not valid!");
				
				
				
				return false;
			}
		}

		System.out.println("quantity is valid");
		return true;
	}

	/**
	 * returns true if the price is valid
	 * 
	 * @param stockPriceSTR
	 * @return
	 */
	private boolean priceIsValid(String stockPriceSTR) 
	{
		try 
		{
			BigDecimal stockPrice = new BigDecimal(stockPriceSTR/* .replaceAll(",", "") */);
		} 
		catch (NumberFormatException e) 
		{
			e.printStackTrace();
			System.out.println("price invalid couldnt be converted to Big Decimal");
			return false;
		}

		System.out.println("price is valid");
		return true;
	}

	/**
	 * Returns true if the stock symbol passed is a valid AX stock
	 * 
	 * @param stockSymbol
	 * @return
	 */
	private boolean stockIsValid(String stockSymbol) 
	{
		Stock stock = shareMarket.getSingleStock(stockSymbol);

		if (stock != null && stock.getQuote().getAsk() != null) //if the stock has an ask price quote and is not null its a valid .AX stock
		{
			System.out.println("stock is valid");

			return true;
		} 
		else 
		{
			System.out.println("Stock is not valid!");
			return false;
		}
	}
	
	private void printRequestParameters(HttpServletRequest request, HttpServletResponse response)
	{
		Enumeration<?> params = request.getParameterNames(); 
		
		while(params.hasMoreElements())
		{
			String paramName = (String)params.nextElement();
			System.out.println("Parameter Name - "+paramName+", Value - "+request.getParameter(paramName));
		}
	}
}
