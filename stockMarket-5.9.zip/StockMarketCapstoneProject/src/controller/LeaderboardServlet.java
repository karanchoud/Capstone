package controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Database;
import model.Leaderboard;
import model.Validation;

/**
 * Returns a sorted Leader board to the front end on HTTP get Requests
 */
public class LeaderboardServlet extends HttpServlet
{
	private Database database = Database.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		HttpSession session = request.getSession();
		
		if(Validation.redirectedToLogin(request, response, session)) //checks if the user needs to login and was redirected to the login page
		{
			return;
		}
		
		Leaderboard leaderBoard = this.returnTop10LeaderBoard();			
		request.setAttribute("leaderBoard", leaderBoard);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("leaderboard.jsp");
		dispatcher.forward(request,response);		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		
		HttpSession session = request.getSession();
		
		if(Validation.redirectedToLogin(request, response, session)) //checks if the user needs to login and was redirected to the login page
		{
			return;
		}
		
		Leaderboard leaderBoard = this.returnEntireLeaderBoard();	
		request.setAttribute("leaderBoard", leaderBoard);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("leaderboard.jsp");
		dispatcher.forward(request,response);
	}
	
	/**
	 * Used to Load initial Leader board page
	 * @return Top 10 players in the game
	 */
	private Leaderboard returnTop10LeaderBoard()
	{
		Leaderboard leaderBoard = new Leaderboard();
		
		leaderBoard.getPlayerLeaderBoard().addAll(database.getTop10Players());//populate the leaderBoard from the database
		
		leaderBoard.sortLeaderBoard(); //sort the leaderBoard
		
		return leaderBoard; 
	}
	/**
	 * Handles the Post request on the page for players wanting to see the full leader board
	 * @return Entire leader board of players
	 */
	private Leaderboard returnEntireLeaderBoard()
	{
		Leaderboard leaderBoard = new Leaderboard();
		
		leaderBoard.getPlayerLeaderBoard().addAll(database.getAllPlayers()); //populate the leaderBoard from the database
				
		leaderBoard.sortLeaderBoard(); //sort the leaderBoard
		
		return leaderBoard; 
	}
}
