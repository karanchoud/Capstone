package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ShareMarket;
import yahoofinance.Stock;


public class APITestServlet extends HttpServlet
{
	ShareMarket shareMarket = new ShareMarket();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		Stock stock = shareMarket.getSingleStock("JBH.AX");
		
		if(checkStockValues(stock))
		{
			request.setAttribute("stockValue", true);	
		}
		else
		{
			request.setAttribute("stockValue", false);
		}
		
		if(checkStockHistory(stock))
		{
			request.setAttribute("stockHistory", true);
		}
		else
		{
			request.setAttribute("stockHistory", false);
		}
		
		if(checkAPIWorks(stock))
		{
			request.setAttribute("APITest", true);
			request.setAttribute("APITestStock", stock);
		}
		else
		{
			request.setAttribute("APITest", false);
			request.setAttribute("APITestStock", stock);
		}
		
		 RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); 
		 dispatcher.forward(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request,response);
	}
	
	public boolean checkAPIWorks(Stock stock)
	{			
		return(checkStockValues(stock) && this.checkStockHistory(stock));	
	}
	
	private boolean checkStockValues(Stock stock)
	{
		if(stock != null && stock.getQuote().getAsk() != null)
		{
			return true;
		}
		else
		{
			return false;
		}	
	}
	
	private boolean checkStockHistory(Stock stock)
	{
		try 
		{
			if(stock.getHistory() != null)
			{
				return true;
			}
			else
			{
				return false;
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			return false;
		}
	}
	
	
	
}
