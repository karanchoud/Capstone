package model;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import enums.ErrorType;
import yahoofinance.Stock;
/**
 * Class used to perform checks on various things that need validating before the game can continue
 * 
 */
public class Validation 
{
	static ShareMarket shareMarket = new ShareMarket();
	
	/**
	 * Checks if the user is logged in and redirects them to the login page if they need to login
	 * @param request
	 * @param response
	 * @param session
	 * @return true if the user was directed to the login page
	 * @throws ServletException
	 * @throws IOException
	 */
	public static boolean redirectedToLogin(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException
	{
	
		if(!userLoggedIn(session))
		{
			session.setAttribute("errorMsg", ErrorType.notLoggedIn);
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
			
			dispatcher.forward(request, response);
			return true;
			
		}
		else
		{
			return false;
		}
		
	}
	
	/**
	 * 
	 * @param session
	 * @return true if the user is logged in false if they are not
	 */
	private static boolean userLoggedIn(HttpSession session)
	{
		if(session.getAttribute("username") != null)
		{					
			return true;
		}
		else
		{
			return false;
		}
	}
	/**
	 * Checks if the passed in Stock symbol is a valid stock on the stock market
	 * @param stockSymbol
	 * @return true if the stock is valid
	 */
	public static boolean stockIsValid(String stockSymbol) 
	{
		Stock stock = shareMarket.getSingleStock(stockSymbol);

		if (stock != null && stock.getQuote().getAsk() != null) 
		{
			System.out.println("stock is valid");
			
			System.out.println(stock.getQuote().getAsk());

			return true;
		} 
		else 
		{
			System.out.println("Stock is not valid!");
			
			
			return false;
		}
	}
	
	
	/**
	 * returns true if the price is valid
	 * 
	 * @param stockPriceSTR
	 * @return
	 */
	public static boolean priceIsValid(String stockPriceSTR) 
	{
		try 
		{
			@SuppressWarnings("unused")
			BigDecimal stockPrice = new BigDecimal(stockPriceSTR);
		} 
		catch (NumberFormatException e) 
		{
			e.printStackTrace();
			System.out.println("price invalid couldnt be converted to Big Decimal");
			return false;
		}

		System.out.println("price is valid");
		return true;
	}
	
	/**
	 * returns true if the quantity is a valid number
	 * 
	 * @param quantitySTR
	 * @return
	 */
	public static boolean quantityIsValid(String quantitySTR) 
	{
		if(quantitySTR.length() == 0)
		{
			System.out.println("quantitiy is not valid!");
			return false;
		}
		for (int i = 0; i < quantitySTR.length(); i++) 
		{
			if (Character.isDigit(quantitySTR.charAt(i))) 
			{
				continue;
			} 
			else 
			{
				System.out.println("quantitiy is not valid!");
				return false;
			}
		}

		System.out.println("quantity is valid");
		return true;
	}
	
	/**
	 * Returns True if all the form data sent by the player is valid and can be
	 * used to call a share market method
	 * 
	 * @param stockSymbol
	 * @param stockPriceSTR
	 * @param quantitySTR
	 * @return
	 * 
	 * True if Input is valid for a bidOrder or bidOrderSell
	 */
	public static boolean validInput(String stockSymbol, String stockPriceSTR, String quantitySTR) 
	{
		return (stockIsValid(stockSymbol) && priceIsValid(stockPriceSTR) && quantityIsValid(quantitySTR));
	}
	
	/**
	 * Same as validInput except does not check for a price as MarketOrders do not use a price specified by the user
	 * 
	 * @param stockSymbol
	 * @param quantitySTR
	 * @return
	 * True if the input is valid for a arkerOrder or MarketOrderSell
	 */
	public static boolean validMarketInput(String stockSymbol, String quantitySTR) 
	{
		return (stockIsValid(stockSymbol) && quantityIsValid(quantitySTR));
	}
}
