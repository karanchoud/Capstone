package unitTests;

import static org.junit.Assert.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;




import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

public class BidSellTest
{	
	private RegisterServlet server;
	Player player;
	
	Stock stock;
	
	String user, user2;
	String invalidStockCode, stockCode, duplicateStockCode, unownedStockCode, stockCode2;
	BigDecimal stockPrice;
	int quantity, negativeQuantity, zeroQuantity, greaterQuantity, lesserQuantity;
	ShareMarket sm;

	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "ruff";
		invalidStockCode = "notastockcode";
		stockCode = "MXC.AX";
		stockCode2 = "AWE.AX";
		unownedStockCode = "JBH.AX";
		user2 = "testPlayer4";
		db = Database.getInstance();
		sm = new ShareMarket();
		stockPrice = new BigDecimal(0.50);
		quantity = 1000;
		negativeQuantity = -1000;
		zeroQuantity = 0;
		greaterQuantity = 3000;
		lesserQuantity = 50;
		
	}
	@Test
	public void TestIncorrectStockInput() 
	{
		
		//player = db.getPlayer(user);
		
		boolean result = sm.bidOrderSell(user, invalidStockCode, stockPrice, quantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestIncorrectQuantityNegativeInput() 
	{
		
		
		
		boolean result = sm.bidOrderSell(user, stockCode, stockPrice, negativeQuantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestIncorrectQuantityZeroInput() 
	{
		
		
		
		boolean result = sm.bidOrderSell(user, stockCode, stockPrice, zeroQuantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestQuantityGreaterThanOwned() throws IOException 
	{
		stockPrice = YahooFinance.get(stockCode).getQuote().getAsk();
		

		boolean result = sm.bidOrderSell(user2, stockCode, stockPrice, greaterQuantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestQuantityExact() throws IOException 
	{
		stockPrice = YahooFinance.get(stockCode).getQuote().getAsk();
	

		boolean result = sm.bidOrderSell(user2, stockCode, stockPrice, quantity);
		assertEquals(true, result);
	}
	
	
	@Test
	public void TestQuantityLess() throws IOException 
	{
		stockPrice = YahooFinance.get(stockCode2).getQuote().getAsk();
	

		boolean result = sm.bidOrderSell(user2, stockCode2, stockPrice, lesserQuantity);
		assertEquals(true, result);
	}
	
	@After
	public void postTest() throws IOException
	{
		System.out.println("testing complete");
		
		//db.deletePlayerSellRequest(user2, stockCode);
		//db.deletePlayerSellRequest(user2, stockCode2);
	}
}
