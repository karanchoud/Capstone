package controller;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import enums.ErrorType;
import enums.OrderType;
import enums.adminType;
import model.Admin;
import model.Database;
import model.Player;


/**Servlet responsible for handling admin based functionality requests **/

@SuppressWarnings("serial")
public class AdminCommandServlet extends HttpServlet
{
	Database database = Database.getInstance();
	String fundsStr;
	Player player;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		
		 HttpSession session = request.getSession();
		 
		 //detect form submission
		 if(request.getParameter("submitPlayer") != null)
		 {
			 
		 if(request.getParameter("submitPlayer").equals("1"))
		 {
			 System.out.println("need to look for player");
			 
			 //obtain field input for players username
			 String userName = (String) request.getParameter("search");
			 //query database for possible existance of player
			 Player player = database.getPlayer(userName);
			 
			 //check if player exists and is returned by previous database call
			 if(player != null)
			 {
		     //player exists, set session variable for dynamic page reload of that players information
			 session.setAttribute("resetPlayerUsername", userName);
			 System.out.println("player exists!");
			 }
			 //player does not exist, throw error msg and simply return back to resetPlayer page
			
			 RequestDispatcher dispatcher = request.getRequestDispatcher("resetPlayer.jsp");
			 dispatcher.forward(request,response);
			 return;
		 }
		 }
		 
		 //player exists, check which command is being requested by admin
		 adminType order = checkOrderType(request, response);
		 Admin admin = new Admin();
		 
		 //if a funds parameter has been set then extract this to a variable
		 if(request.getParameter("funds")!=null)
		 {
			 System.out.println(request.getParameter("funds"));
			 fundsStr = (String) request.getParameter("funds");
		 }
		 
		 
		 //identify the command being requested by the admin, and take appropriate action
		 switch (order) 
			{
		 	// player reset detected
			case reset:
				System.out.println("RESET DETECTED");
				System.out.println(request.getParameter("user"));
				//extract player details
				player = database.getPlayer(request.getParameter("user"));
				if(player !=null) 
				{
					//perform reset function based on specific players identified via username and return to resetPlayer page
					System.out.println("VALID RESET ORDER");
					
					admin.resetPlayer(request.getParameter("user"));
					System.out.println("heeellooooo");
					RequestDispatcher dispatcher = request.getRequestDispatcher("resetPlayer.jsp"); //return all info back to the client
					dispatcher.forward(request,response);
					return;
					
				}
				System.out.println("failed!");
				//player doesnt exist, set error msg and return to page
				session.setAttribute("errorMsg", ErrorType.InvalidPlayer);
				break;
			case inject:
				//funds injection detected
				if(quantityIsValid(fundsStr)) 
				{
					//check if player exists
					player = database.getPlayer(request.getParameter("user"));
					if(player !=null)
					{
						//perform valid injection admin command
					System.out.println("VALID INJECT ORDER");
					BigDecimal funds = new BigDecimal (fundsStr);
					admin.amendFunds(player.getUserName(), funds);
					break;
					}
					
				}
				System.out.println("failed!");
				
				session.setAttribute("errorMsg", ErrorType.InvalidQuantity);
				RequestDispatcher dispatcher = request.getRequestDispatcher("injectFunds.jsp"); //return all info back to the client
				dispatcher.forward(request,response);
				return;
				//break;
			
			}
		 
		 //retrieve player info after fund modification for reporting information back to the user 
		 player = database.getPlayer(player.getUserName());
		 session.setAttribute("confirmUser", player.getUserName());
		 session.setAttribute("confirmFunds", player.getFundsRounded());
		 
		 System.out.println(session.getAttribute("confirmUser"));
		 System.out.println(session.getAttribute("confirmFunds"));
		 //return to inject funds page
		 RequestDispatcher dispatcher = request.getRequestDispatcher("injectFunds.jsp"); //return all info back to the client
		 dispatcher.forward(request,response);
	}
	
	
	/** Returns the type of command being request by the admin using enumeration
	 * @param HttpServletRequest - the page request containing submitted form values
	 * @param HttpServlerResponse - the page request allowing submittable values
	 * @return adminType - enumeration indicating command type **/
	public adminType checkOrderType(HttpServletRequest request, HttpServletResponse response) 
	{
		//indicates a reset form has been submitted
		if (request.getParameter("command").equals("reset")) 
		{
			
			return adminType.reset;
		}
		
		//indicates a inject funds form has been submitted
		if (request.getParameter("command").equals("inject")) 
		{
			return adminType.inject;
		}
		
		return null;
		
	}
	
	/** checks to see if entered quantity on inject funds page is valid
	 * @param quantitySTR - value input by user extracted from field
	 * @return boolean value indicating success or failure of validation **/
	
	private boolean quantityIsValid(String quantitySTR) 
	{
		//null check and empty submit check of quantity
		if(quantitySTR == null | quantitySTR.length() == 0)
		{
			System.out.println("null or length is zero");
			return false;
		}
		
		//digit check, ensure all entered characters are digits
		for (int i = 0; i < quantitySTR.length(); i++) 
		{
			if (Character.isDigit(quantitySTR.charAt(i))) 
			{
				continue;
			} 
			else 
			{
				System.out.println("quantitiy is not valid!");
				return false;
			}
		}

		System.out.println("quantity is valid so far");
		
		//BigDecimal quantityConvert = new BigDecimal(quantitySTR);
		
		//convert to bigdecimal type, ensures the entered value is convertable into a type holding numerical values only.
		try 
		{
			BigDecimal quantityConvert = new BigDecimal(
					quantitySTR .replaceAll(",", "") );
		} 
		catch (NumberFormatException e) 
		{
			e.printStackTrace();
			System.out.println("price invalid couldnt be converted to Big Decimal");
			return false;
		}
		
		return true;
	}

	 	 
}
