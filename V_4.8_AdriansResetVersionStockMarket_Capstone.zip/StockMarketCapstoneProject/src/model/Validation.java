package model;

import java.math.BigDecimal;

import yahoofinance.Stock;

public class Validation 
{
	static ShareMarket shareMarket = new ShareMarket();
	
	
	public static boolean stockIsValid(String stockSymbol) 
	{
		Stock stock = shareMarket.getSingleStock(stockSymbol);

		if (stock != null && stock.getQuote().getAsk() != null) 
		{
			System.out.println("stock is valid");
			
			System.out.println(stock.getQuote().getAsk());

			return true;
		} 
		else 
		{
			System.out.println("Stock is not valid!");
			
			
			return false;
		}
	}
	
	
	/**
	 * returns true if the price is valid
	 * 
	 * @param stockPriceSTR
	 * @return
	 */
	public static boolean priceIsValid(String stockPriceSTR) 
	{
		try 
		{
			@SuppressWarnings("unused")
			BigDecimal stockPrice = new BigDecimal(stockPriceSTR);
		} 
		catch (NumberFormatException e) 
		{
			e.printStackTrace();
			System.out.println("price invalid couldnt be converted to Big Decimal");
			return false;
		}

		System.out.println("price is valid");
		return true;
	}
	
	/**
	 * returns true if the quantity is a valid number
	 * 
	 * @param quantitySTR
	 * @return
	 */
	public static boolean quantityIsValid(String quantitySTR) 
	{
		if(quantitySTR.length() == 0)
		{
			System.out.println("quantitiy is not valid!");
			return false;
		}
		for (int i = 0; i < quantitySTR.length(); i++) 
		{
			if (Character.isDigit(quantitySTR.charAt(i))) 
			{
				continue;
			} 
			else 
			{
				System.out.println("quantitiy is not valid!");
				return false;
			}
		}

		System.out.println("quantity is valid");
		return true;
	}
	
	/**
	 * Returns True if all the form data sent by the player is valid and can be
	 * used to call a share market method
	 * 
	 * @param stockSymbol
	 * @param stockPriceSTR
	 * @param quantitySTR
	 * @return
	 * 
	 * True if Input is valid for a bidOrder or bidOrderSell
	 */
	public static boolean validInput(String stockSymbol, String stockPriceSTR, String quantitySTR) 
	{
		return (stockIsValid(stockSymbol) && priceIsValid(stockPriceSTR) && quantityIsValid(quantitySTR));
	}
	
	/**
	 * Same as validInput except does not check for a price as MarketOrders do not use a price specified by the user
	 * 
	 * @param stockSymbol
	 * @param quantitySTR
	 * @return
	 * True if the input is valid for a arkerOrder or MarketOrderSell
	 */
	public static boolean validMarketInput(String stockSymbol, String quantitySTR) 
	{
		return (stockIsValid(stockSymbol) && quantityIsValid(quantitySTR));
	}
}
