package model;

/**
 * Admin class models the functionalities that the admin has the ability to do.
 * i.e admins can reset player accounts as well as inject funds into a players account.
@author Adrian, s3383708
**/

import java.math.BigDecimal;

import yahoofinance.Stock;

public class Admin extends Player 
{
	private Database dataBase = Database.getInstance();
	
	private ShareMarket shareMarket = new ShareMarket();
	
	
	
	/** will amend the funds of a player by adding the amount of fund specified by the administrator
	 * @param username- the username of the player the admin wishes to inject funds into
	 * @param funds - the amount of funds being injected
	 * @return boolean - indication of a success or failure to inject funds. */
	public boolean amendFunds(String userName, BigDecimal funds)
	{
		boolean flag = false;
		//retrieve player to ensure player exists
		Player currentPlayer = dataBase.getPlayer(userName);
		if(currentPlayer !=null)
		{
			//add player funds to user and use return value to indicate the success/failure of this transaction.
		flag = dataBase.addPlayerFunds(currentPlayer.getUserName(), funds);
		//set funds into currently loaded player object
		currentPlayer.setFunds(funds);
		}
		return flag;
	}
	
	public void removePlayer(String userName)
	{
		//dataBase.removePlayer(String userName);
	}
	
	/** resets a player based on the specific players username passed into this function.
	 * @param - userName - the unique identifier and player admin wishes to reset.
	 * @return boolean - indication of success/failure of this function */
	public boolean resetPlayer(String userName)
	{
		//extract player from the database
		Player resettingPlayer = dataBase.getPlayer(userName);
		//run the resetPlayer database function and use returning boolean value to indicate success/failure.
		boolean flag = dataBase.ResetPlayer(resettingPlayer);
		return flag;
	}
	
}
