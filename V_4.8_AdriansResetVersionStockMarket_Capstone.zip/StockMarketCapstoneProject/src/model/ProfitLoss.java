package model;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Profit/Loss class holds an object which holds profit and loss values based upon specific portfolio items. 
 * portfolio items are analysed based upon the initial investment values and this is compared to the current valuation of
 * the stock based upon current stock price and amount of quantity owned. e.g. 1000 stock purchased at $1.00 = investment
 * of $1,000 however, stock may be valued at $1.20 now therefore, current valuation of stock is $1,200 meaning $200 profit.
 * this class holds that value of difference along with a percentage difference between invested value and current stock
 * valuation. **/

/**
@author Adrian, s3383708
**/
public class ProfitLoss 
{

	private BigDecimal percentChange; //holds percentage value of difference
	private BigDecimal valueChange; //holds actual dollar value of difference
	private int posNegFlag; //indicates gain,loss or exact valuation.
	
	
	/** Constructor: parameters passed in used to create object **/
	public ProfitLoss(BigDecimal valueChange, BigDecimal percentChange)
	{
		this.percentChange = percentChange;
		this.valueChange = valueChange;
		posNegFlag = 0;
	}
	
	/** getter - gets percentage change **/
	public BigDecimal getPercentChange()
	{
		BigDecimal roundedPercent = percentChange.setScale(2, RoundingMode.HALF_EVEN);
		return roundedPercent;
	}
	
	/** getter - gets value change **/
	public BigDecimal getValueChange()
	{
		BigDecimal roundedValue = valueChange.setScale(2, RoundingMode.HALF_EVEN);
		return roundedValue;
	}
	/** setter - sets the percentage change **/
	public void setPercentChange(BigDecimal percentChange)
	{
		this.percentChange = percentChange;
	}
	
	/** setter - sets the value change **/
	public void setValueChange(BigDecimal valueChange)
	{
		this.valueChange = valueChange;
	}
	
	/** getter - gets the flag for gain,loss,neutral **/
	public int getPosNeg()
	{
		return posNegFlag;
	}
	
	/** setter - sets the flag for gain,loss,neutral **/
	public void setPosNeg(int posNeg)
	{
		posNegFlag = posNeg;
	}
	
}
