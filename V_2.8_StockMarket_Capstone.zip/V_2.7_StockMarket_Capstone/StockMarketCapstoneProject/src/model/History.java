package model;

import java.math.BigDecimal;
import java.math.RoundingMode;

import yahoofinance.Stock;

public class History 
{
	private String username, stockSymbol, dateTime;
	//private Stock stock;
	private int quantity;
	private BigDecimal stockPrice;
	
	//TODO calculate base investment stuff
	
	public History(String username, String stockSymbol, int quantity, BigDecimal stockPrice, String dateTime)
	{
		this.username = username;
		this.stockSymbol = stockSymbol;
		this.quantity = quantity;
		this.stockPrice = stockPrice;
		this.dateTime = dateTime;
	}
	


	
	
	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}

	public BigDecimal getstockPrice() 
	{
		return stockPrice;
	}
	
	public void setStockPrice(BigDecimal stockPrice)
	{
		this.stockPrice = stockPrice;
	}

	public String getStockSymbol()
	{
		return stockSymbol;
	}
	
	public void setStockSymbol(String stockSymbol)
	{
		this.stockSymbol = stockSymbol;
	}
	
	public String getUsername()
	{
		return username;
	}
	
	public String getDateTime()
	{
		return dateTime;
	}
	
	public void setDateTime(String dateTime)
	{
		this.dateTime = dateTime;
	}
}
