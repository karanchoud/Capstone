package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import enums.ErrorType;
import model.CPstock;
import model.Database;
import model.Player;
import model.ProfitLoss;
import model.ShareMarket;
import model.Validation;

@SuppressWarnings("serial")
public class PortfolioServlet extends HttpServlet
{
	/**
	 * Used for loading the Player Information page, Provides all the player data for that page and forwards the user to PlayerInformation.jsp
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{		
		HttpSession session = request.getSession();
		
		if (Validation.redirectedToLogin(request, response, session)) 
		{
			return;
		}
		
		Database dataBase = Database.getInstance();
		ShareMarket shareMarket = new ShareMarket();
		
		Player player = dataBase.getPlayer((String) session.getAttribute("username"));
		
		if(player == null)
		{
			session.setAttribute("errorMsg", ErrorType.InvalidPlayer);
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
			dispatcher.forward(request, response);			
		}
		else
		{
			ArrayList<CPstock> playerPortFolio = player.getPortfolio();
			ArrayList<ProfitLoss> portfolioCalculations = shareMarket.calculateProfitLoss(playerPortFolio);
			
			request.setAttribute("Player", player);
			request.setAttribute("playerPortFolio", playerPortFolio);
			request.setAttribute("portfolioCalculations", portfolioCalculations);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("portfolio.jsp");
			dispatcher.forward(request, response);
		}	
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doGet(request,response);
	}
	 	 
}
