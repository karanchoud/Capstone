package enums;

public enum adminType 
{
	reset,inject
}
