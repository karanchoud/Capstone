package model;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

//API interface down loaded from http://financequotes-api.com/


public class API_TEST 
{
	
	public static void main(String args[]) throws IOException
	{
		Stock stock = null;
		
		
		stock = YahooFinance.get("INTC");
		stock.print();
	
		String[] stockSymbols = {"INTC", "BABA", "TSLA", "AIR.PA", "YHOO"};
		
		Map<String,Stock> stockMap; //map to store stock info
		
		stockMap = YahooFinance.get(stockSymbols); //API request for stock info
		
		printStockmap(stockMap); //print stock map
		
		
		
		
			
	}
	
	public static void printStockmap(Map<String,Stock> stockMap) //prints all stock info from a map
	{
		for(Entry<String,Stock> mapEntry : stockMap.entrySet()) //loop through each entry in the map
		{
			//String currentKey = mapEntry.getKey();
			//System.out.println(currentKey);
			Stock currentStock = mapEntry.getValue(); //assigns the map key's value to a stock object
						
			currentStock.print(); //print the current stock's info
		}
	}
		
	
	
	
}
