/**
 * 
 */
package model;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.UUID;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

/**
 * @author Dan
 * 
 * The MarketPlace for the stock market game, handles all the transactions logic passed in by the servlet and returns the values
 * This includes buying, selling and trading between players and companies
 *
 */
public class ShareMarket 
{
	private FAKEDatabase database;
	private Database db;
	public ShareMarket(FAKEDatabase database)
	{
		this.database = database;
		db = Database.getInstance();
	}
	
	
	/* Constructor for ShareMarket Object */
	public ShareMarket()
	{
		db = Database.getInstance();
	}
	
	/**
	 * Makes a call to the Yahoo finance API for stock information.
	 * @param stockSymbol - The Symbol used to represent a company's stock.
	 * @return
	 * 
	 * A stock object containing all information regarding that stock
	 */
	public Stock getSingleStock(String stockSymbol) //makes a call to the Yahoo finance API for a stock's latest information
	{
		Stock stock;
		try 
		{
			stock = YahooFinance.get(stockSymbol);
			
			return stock;
		} 
		catch (IOException e) 
		{
			System.out.println("ERROR: Invalid stock symbol returning NULL");
			e.printStackTrace();
		}
		
		return null;
	}
	
	/**
	 * allows players to submit a bid buy request. Players can decide the quantity of stock to be purchased, the stock itself and the amount they wish
	 * to purchase at. Database will be updated accordingly.
	 * 
	 * @param username - players unique identifier and alias
	 * @param stockSymbol - The Symbol used to represent a company's stock. 
	 * @param stockPrice - The price the player is willing to buy the stock at.
	 * @param quantity - The amount of stock the Player is trying to buy.
	 */
	public void bidOrder(String username, String stockSymbol, BigDecimal stockPrice, int quantity) //a player order that will buy stock at the current ask price of the stock
	{
		Stock stock = getSingleStock(stockSymbol);
		
		/*check to see if the same stock has already been executed by this player. */
		boolean duplicateCheck = db.checkStockDuplicity(username, stockSymbol);
		if(duplicateCheck)
		{
			/* Stock buy request exists therefore, notify user that they can instead amend this stock. */
			System.out.println("unable to perform buy request, identical record detected, you can amend this stock instead");
			return;
		}
		
			/* Obtain player credentials for database */
			Player player = db.getPlayer(username);
			
			/* check if player has sufficient funds after the purchase transaction and remove the funds accordingly */
			BigDecimal checkFunds = calcNewFunds(player,stockPrice,quantity);
			
			if(checkFunds != null) //if they can afford to buy the stock at market price
			{
				player.setFunds(checkFunds); //update the players funds
				
				/* Apply a brokerage fee to the buy request */
				this.applyPurchaseBrokerFee(player, stockPrice);
				
				addStock(player,stock,quantity); //adds the stock to the players portfolio
				
				/* execute the buy request by updating the database with players request */
				db.buyUpdate(player, stockSymbol,quantity, stockPrice);
			}
			
			
		
		
		
	}
	
	/**
	 * allows players to submit an amend bid buy request. Players can decide the quantity of stock to be amended, and the amount they wish
	 * to amend in regards to quantity. Database will be updated accordingly.
	 * 
	 * @param username - players unique identifier and alias
	 * @param stockSymbol - The Symbol used to represent a company's stock. 
	 * @param stockPrice - The price the player is willing to amend the stock at
	 * @param quantity - The amount of stock the Player is willing to amend
	 */
	public void amendBuy(String username, String stockSymbol, BigDecimal stockPrice, int quantity)
	
	{
		//obtain up to date information on the stock being amended by the player
		Stock stock = getSingleStock(stockSymbol);
		
		
		//obtain player information from the database
		Player player = db.getPlayer(username); 
		
		/* perform a check to evaluate if players have enough funds to perform the amending purchase request as well as evaluate
		 * the difference from old purchase price to new purchase price in order to update the players available funds after the amendment.
		 */
		BigDecimal checkFunds = amendFunds(player,stockPrice, stockSymbol, quantity);
		
		
		/*
		 * check to see if there is a record to be amended at all or the user cannot amends funds due to their own funds becoming overdrawn by the
		 * amended buying request.
		 * If amendment is okay to proceed, players funds are updated in both the Player object as well as the database
		 */
		
		if(checkFunds !=null)
		{
			player.setFunds(checkFunds);
			//modify player funds and players buy request in the database
			db.buyUpdate(player, stockSymbol, quantity, stockPrice);
			}
		else
			{
			//unable to amend due to overdrawn funds or buy request is not in the database
			System.out.println("error cannot amend funds due to overdrawn funds or buy request record doesn't exist");
			}
		return;
	}
	
	
/**
 * Method performs a sell request made by a user. users can select from a list of stocks they wish to sell 
 * 
 * @param username - Players unique identifier and alias
 * @param stockPrice - The price the player is willing to sell the stock at
 * @param stockSymbol -  The stock company symbol. used to determine which stock to sell
 * @param quantity - The amount of stock the Player is willing to amend
 */
	
	public void bidOrderSell(String username, String stockSymbol, BigDecimal stockPrice, int quantity) //a player order that will buy stock at the current ask price of the stock
	{
		// obtain up to date information on the stock to be sold.
		Stock stock = getSingleStock(stockSymbol);
		
		// obtained Player credentials and information.
		Player player = db.getPlayer(username); 
		
		/*
		 * perform check to see if sell request has already been made on this particular stock.
		 */
		boolean duplicateCheck = db.checkStockDuplicitySell(username, stockSymbol);
		if(duplicateCheck)
		{
			//notify user that sell request has been made and it can be amended.
			System.out.println("unable to perform sell request, identical record detected, you can amend this stock instead");
			return;
		}
		
		if(quantity <=0)
		{
			//validate quantity being entered by Player, if it is less than zero then it is considered an invalid input.
			System.out.println("invalid input, quantity cannot be less than or equal to 0");
			return;
		}
		
		/*
		 * check to see if the quantity entered is less than the quantity which the player has available to them.
		 */
		boolean checkQuantity = db.checkStockQuantity(username, stockSymbol,quantity);
		if(checkQuantity == false)
		{
			//quantity is larger than what the user has available in the portfolio of the specific stock
			System.out.println("quantity entered is larger than the quantity available");
			return;
		}
		
			
			//update the database accordingly and add the sell request.
			db.sellUpdate(player, stockSymbol, quantity, stockPrice);
			return;
		
		
	}

	/**
	 * Method performs a sell amend request made by a user. users can select from a list of stocks they wish to amend. Method will validate 
	 * to ensure that the Player has enough stock available and does not attempt to amend larger than the quantity of stock they own.
	 * 
	 * @param username - Players unique identifier and alias
	 * @param stockSymbol - The stock company symbol. used to determine which stock to amend
	 * @param stockPrice -  The price the player is willing to sell the stock at
	 * @param quantity - The amount of stock the Player is willing to amend
	 */
	
public void amendSell(String username, String stockSymbol, BigDecimal stockPrice, int quantity)
	{
	//Obtain player credentials
	Player player = db.getPlayer(username); 
	
	/*
	 * check to see if the quantity inputted is less than zero
	 */
	if(quantity <=0)
	{
		System.out.println("invalid input, quantity cannot be less than or equal to 0");
		return;
	}
	
	/*
	 * check to see if the quantity entered is less than the quantity which the player has available to them.
	 */
	boolean checkQuantity = db.checkStockQuantity(username, stockSymbol,quantity);
	if(checkQuantity == false)
	{
		//quantity is larger than what the user has available in the portfolio of the specific stock
		System.out.println("quantity entered is larger than the quantity available");
		return;
	}
	
	//perform sell amendment correctly. 
	db.sellUpdate(player, stockSymbol, quantity, stockPrice);
	
	
	}
	
	

/**
 * Internal method used by the amendBuy method. Will evaluate the difference between the old purchase price stored in the database with the new amending
 * price. validates whether player has enough funds and whether the amendment can be performed if the request for the specific stock actually
 * exists.
 * 
 * @param Player - player object housing all player information
 * @param stockPrice - The price the player is willing to amend the stock at
 * @param stockSymbol -  The stock company symbol. used to evaluate which buy request to amend
 * @param quantity - The amount of stock the Player is willing to amend
 */
	private BigDecimal amendFunds(Player player, BigDecimal stockPrice, String stockSymbol, int quantity) {

		//determine the new purchase price based on the price player wishes to buy at and the quantity they wish to purchase.
		BigDecimal newCost = stockPrice.multiply(new BigDecimal(quantity)); 
		
		//determine the old buy price based on the buy request previously made.
		BigDecimal oldCost = db.getOldBuyPrice(player.getUserName(), stockSymbol);
		
		/*
		 *  return null if the oldCost cannot be obtained because the record does not exist
		 */
		if(oldCost == null)
		{
			return null;
		}
		
		
		/*
		 * Calculate difference between old purchase price and new purchase price
		 */
		BigDecimal difference = newCost.subtract(oldCost);
		
		//finalFunds represents the funds of the player and will be manipulated by the end of this method
		BigDecimal finalFunds = player.getFunds();
		
		/*
		 * evaluate if the difference was negative (meaning the amending request will be spending less than the current request so deposit the difference
		 * into the Players funds.
		 */
		if(difference.compareTo(BigDecimal.ZERO) <0)
		{
			//convert negative value into positive value
			difference = difference.multiply(new BigDecimal(-1));
			//add difference into the Players funds
			finalFunds = finalFunds.add(difference);
		}
		else
		{
			/*
			 * if difference was positive this means Players amendment request costs more than their previous request stored therefore, reduce the players
			 * funds by the difference.
			 */
			finalFunds.subtract(difference);
		}
		if(finalFunds.compareTo(BigDecimal.ZERO) >= 0) //if the exchange doesn't put the players funds into negative funds
		{
			return finalFunds; //return the new total
		}
		else
		{
			//overdrawn account therefore return null
			System.out.println("not enough funds change cant be made");
		}
		return null;
		
		
	}

	/**
	 * Allows the player to sell their stock on the market at the current asking price
	 * 
	 * @param playerID - Identifies the player
	 * @param stockSymbol - the symbol used to identify the stock
	 * @param stockPrice - the price the stock will be sold at (the current asking price at the time)
	 * @param quantity - the amount of stock being sold in the transaction
	 */
	public void marketOrderSell(String playerID, String stockSymbol, BigDecimal stockPrice, int quantity) //sells player stock at market ask price
	{
		Stock stock = getSingleStock(stockSymbol);
		
		if(stock.getQuote().getAsk().equals(stockPrice))
		{
			System.out.println("sell price matches current Ask price processing.....");
			
			Player currentPlayer = database.findPlayer(playerID);
			
			if(removeStock(currentPlayer,stock,quantity)) //if the player's stock request is valid and removed
			{
				BigDecimal totalProfit = stockPrice.multiply(new BigDecimal(quantity)); //calculate the players profit
				
				currentPlayer.setFunds(currentPlayer.getFunds().add(totalProfit)); //add the profits to the players funds
				
				this.applyPurchaseBrokerFee(currentPlayer, stockPrice);
				
				System.out.println("Market Order sell transaction completed.....");
			}
			else
			{
				System.out.println("market order cancelled.. removeStock returned false");
			}			
		}
			
	}
	
	/**
	 * Removes a stock from the Player's portfolio
	 * 
	 * @param currentPlayer
	 * @param stock
	 * @param quantity
	 * @return
	 */
	private boolean removeStock(Player currentPlayer, Stock stock, int quantity) //remove stock from the players port folio
	{
		for(int i = 0; i < currentPlayer.getPortfolio().size(); i ++) //loop through the players port folio
		{
			if(currentPlayer.getPortfolio().get(i).getStock().getSymbol().equals(stock.getSymbol())) //if the stock exists in the player port folio 
			{
				int oldQuantity = currentPlayer.getPortfolio().get(i).getQuantity(); 
				
				int newQuantity = oldQuantity - quantity;
				
				if(oldQuantity < quantity)
				{
					System.out.println("ERROR: player trying to sell more stock then they own...");
					return false;
				}
				
				
				if(newQuantity == 0)
				{
					currentPlayer.getPortfolio().remove(i); //if the player doesn't own any stock in the company anymore
					
					return true;
				}
				else
				{
					currentPlayer.getPortfolio().get(i).setQuantity(newQuantity); //remove the amount of stock being sold
					return true;
				}
			}
		}
		
		return false;
		
	}
	/**
	 * adds a CPstock object to the player's port folio
	 * or increases the quantity if a player already owns a number of that stock
	 * @param currentPlayer - The player object
	 * @param stock - the stock to be added
	 * @param quantity - the amount of stock being added
	 */
	private void addStock(Player currentPlayer,Stock stock,int quantity) //adds the stock to the players portfolio
	{
		for(int i = 0; i < currentPlayer.getPortfolio().size(); i++) //loop through the list of currently owned stocks
		{
			if(currentPlayer.getPortfolio().get(i).getStock().getSymbol().equals(stock.getSymbol())) //if the player has invested in this stock before
			{
				currentPlayer.getPortfolio().get(i).setQuantity(quantity + currentPlayer.getPortfolio().get(i).getQuantity()); //increase the quantity of owned stock
				
				System.out.println("Market Order purchase completed...increased quantity of existing stock: " + stock.getSymbol());
				return;
			}
		}
		//if the player doesnt own any of this stock create a new stock and add it to the port folio				
		currentPlayer.getPortfolio().add(new CPstock(stock,quantity)); //adds the purchased stock to the player's portfolio
		
		System.out.println("Market Order purchase completed added new stock to portfolio: " + stock.getSymbol());	
	}
	
	public BigDecimal calcNewFunds(Player player, BigDecimal stockPrice, int quantity) //deducts the current purchase from the players total
	{
		BigDecimal newTotal = player.getFunds(); //current funds before the purchase
		
		if(quantity == 1)
		{
			newTotal = newTotal.subtract(stockPrice);
			
			if(newTotal.compareTo(BigDecimal.ZERO) >= 0) //if the exchange doesn't put the players funds into negative
			{
				return newTotal; //return the new total
			}
			else
			{
				System.out.println("not enough funds");
				return null;
			}
		}
		else
		{
			BigDecimal totalCost = stockPrice.multiply(new BigDecimal(quantity)); //the cost to buy all the stock in the order
			
			newTotal = newTotal.subtract(totalCost);
			
			if(newTotal.compareTo(BigDecimal.ZERO) >= 0) //if the exchange doesn't put the players funds into negative
			{
				return newTotal; //return the new total
			}
			else
			{
				System.out.println("not enough funds");
				return null;
			}
			
		}	
	}
	
	/**
	 * Returns the amount of money a player has in stock
	 * @param player
	 * @return
	 */
	private BigDecimal calcEquityFunds(Player player) //calculates the players equity funds after purchase
	{
		BigDecimal equityFunds = new BigDecimal(0);
		
		for(CPstock stock: player.getPortfolio())
		{
			equityFunds = equityFunds.add(stock.getStock().getQuote().getAsk().multiply(new BigDecimal(stock.getQuantity()))); //current ask price * quantity of stock
		}
		
		return equityFunds;
	}
	/**
	 * returns the total amount of money a player has on the stock market in actual money and amount invested into stock
	 * @param player
	 */
	private void calcTotalFunds(Player player) //calculates the players total amount of money based on current stock investments and money
	{
		BigDecimal totalFunds = new BigDecimal(0);
		
		totalFunds = player.getFunds().add(player.getEquityFunds());
	}
	
	/**
	 * calculates and applies the purchase tax for purchasing stock on the market
	 */
	public void applyPurchaseBrokerFee(Player player, BigDecimal stockPrice)
	{
		BigDecimal brokerageFee = new BigDecimal(50); //base cost of 50
		
		BigDecimal purchaseTax = stockPrice.divide(new BigDecimal(100).divide(new BigDecimal(0.25))); 
		
		brokerageFee  = brokerageFee.add(purchaseTax);
		
		player.setFunds(player.getFunds().subtract(brokerageFee));
		
	}
	
	/**
	 * calculates and applies the sales tax for selling stock on the market
	 * @param player
	 * @param stockPrice
	 */
	public void applySalesBrokerFee(Player player, BigDecimal stockPrice)
	{
		BigDecimal brokerageFee = new BigDecimal(50); //base cost of 50
		
		BigDecimal saleTax = stockPrice.divide(new BigDecimal(100).divide(new BigDecimal(1.0))); //calculate the sales tax
		
		brokerageFee  = brokerageFee.add(saleTax); //calculate the total brokerage fee
		
		player.setFunds(player.getFunds().subtract(brokerageFee)); //apply brokerage tax

	}

	
}
