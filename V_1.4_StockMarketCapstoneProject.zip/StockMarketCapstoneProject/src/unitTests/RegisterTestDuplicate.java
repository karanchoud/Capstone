package unitTests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.Database;
import model.Player;
import yahoofinance.Stock;

public class RegisterTestDuplicate
{	
	private RegisterServlet server;
	Player player;
	
	Stock stock;
	
	String user, pass, first, last, email;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "ruff4";
		pass = "pass2";
		first = "testname";
		last = "testlastname";
		email = "testing@hotmail.com";
		db = Database.getInstance();
		server = new RegisterServlet();
		
		
		
		
	}
	@Test
	public void test() 
	{
		/*test checks for addition of new player, NOTE: username must be a duplicate!*/
		assertEquals(false, db.addPlayer(user, pass, first, last, email));
		System.out.println("its true");
		
	
		
	}

}
