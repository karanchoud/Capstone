package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Database;
import model.FAKEDatabase;
import model.Player;


public class WelcomeServlet extends HttpServlet
{
	
	private FAKEDatabase Fdatabase = FAKEDatabase.getInstance();
	
	private Database database = Database.getInstance();
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	 {
		 if(database.getConnectionSuccess() == false)
		 {
			 System.out.println("connection failed to database");
			 database = null;
			 RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp"); //return all info back to the client
			 dispatcher.forward(request,response);
			 return;
		 }
		 else
		 {
			 HttpSession session = request.getSession();
		 }
	}
}
