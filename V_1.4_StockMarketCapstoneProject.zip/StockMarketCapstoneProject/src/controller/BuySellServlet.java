package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Database;
import model.FAKEDatabase;
import model.Player;
import model.ShareMarket;
import yahoofinance.Stock;


public class BuySellServlet extends HttpServlet
{
	
	private FAKEDatabase Fdatabase = FAKEDatabase.getInstance();
	
	private Database database = Database.getInstance();
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	 {
		 //Fdatabase.addPlayer(new Player());
		 
		 //PrintWriter out=response.getWriter();
		 /* At the moment this servlet is only used for testing buy and sell requests until a page can be built for user input */
		 ShareMarket sm = new ShareMarket();
		 Stock stock = sm.getSingleStock("MMJ.AX");
		 stock.getQuote().getPrice();
		 System.out.println("hi");
		 BigDecimal b = new BigDecimal(0.80);
		 System.out.println("process sell");
		 sm.amendSell("ruff", stock.getSymbol(), b, 400);
		 
		 
		 //ShareMarket sm = new ShareMarket();
		 //Stock stock = sm.getSingleStock("MMJ.AX");
		 
		 //stock.print();
		 //BigDecimal b = stock.getQuote().getPrice();
		 //System.out.println(b);
		 //sm.bidOrder("ruff", stock.getSymbol(), b, 100);
		// sm.amendBuy("ruff", stock.getSymbol(), new BigDecimal(0.60), 100);
		 
	 }
}
