package controller;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import enums.OrderType;
import enums.adminType;
import model.Admin;
import model.Database;
import model.Player;




@SuppressWarnings("serial")
public class AdminCommandServlet extends HttpServlet
{
	Database database = Database.getInstance();
	String fundsStr;
	Player player;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		
		 HttpSession session = request.getSession();
		 
		 
		 if(request.getParameter("submitPlayer") != null)
		 {
	
		 if(request.getParameter("submitPlayer").equals("1"))
		 {
			 System.out.println("need to look for player");
			 String userName = (String) request.getParameter("search");
			 Player player = database.getPlayer(userName);
			 if(player != null)
			 {
			 session.setAttribute("resetPlayerUsername", userName);
			 }
			 RequestDispatcher dispatcher = request.getRequestDispatcher("resetPlayer.jsp"); //return all info back to the client
			 dispatcher.forward(request,response);
			 return;
		 }
		 }
		 //Player adminPlayer = database.getPlayer(userName);
		 //Admin admin = new Admin(adminPlayer.getUserName(), adminPlayer.getPassword(), adminPlayer.getFirstName(), adminPlayer.getLastName(), adminPlayer.getID(), adminPlayer.getFunds(), adminPlayer.getPortfolio(), adminPlayer.getEmail());
		 adminType order = checkOrderType(request, response);
		 Admin admin = new Admin();
		 if(request.getParameter("funds")!=null)
		 {
			 System.out.println(request.getParameter("funds"));
			 fundsStr = (String) request.getParameter("funds");
		 }
		 
		 
		 switch (order) 
			{
			case reset:
				System.out.println(request.getParameter("user"));
				player = database.getPlayer(request.getParameter("user"));
				if(player !=null) 
				{
					System.out.println("VALID RESET ORDER");
					//database.ResetPlayer(player);
					admin.resetPlayer(request.getParameter("user"));
					System.out.println("heeellooooo");
					RequestDispatcher dispatcher = request.getRequestDispatcher("resetPlayer.jsp"); //return all info back to the client
					dispatcher.forward(request,response);
					return;
					//break;
				}
				System.out.println("failed!");
				session.setAttribute("errorMsg", "Player does not exist");
				break;
			case inject:
				
				if(quantityIsValid(fundsStr)) 
				{
					player = database.getPlayer(request.getParameter("user"));
					if(player !=null)
					{
					System.out.println("VALID INJECT ORDER");
					BigDecimal funds = new BigDecimal (fundsStr);
					admin.amendFunds(player.getUserName(), funds);
					//database.addPlayerFunds(player.getUserName(), funds);
					break;
					//database.addPlayerFunds(userName, funds);
					}
					
				}
				System.out.println("failed!");
				session.setAttribute("errorMsg", "quantity entered is not valid, please try again");
				RequestDispatcher dispatcher = request.getRequestDispatcher("injectFunds.jsp"); //return all info back to the client
				dispatcher.forward(request,response);
				return;
				//break;
			
			}
		 
		
		 player = database.getPlayer(player.getUserName());
		 session.setAttribute("confirmUser", player.getUserName());
		 session.setAttribute("confirmFunds", player.getFundsRounded());
		 
		 System.out.println(session.getAttribute("confirmUser"));
		 System.out.println(session.getAttribute("confirmFunds"));
		 RequestDispatcher dispatcher = request.getRequestDispatcher("injectFunds.jsp"); //return all info back to the client
		 dispatcher.forward(request,response);
	}
	
	public adminType checkOrderType(HttpServletRequest request, HttpServletResponse response) 
	{
		if (request.getParameter("command").equals("reset")) 
		{
			
			return adminType.reset;
		}
		
		if (request.getParameter("command").equals("inject")) 
		{
			return adminType.inject;
		}
		
		return null;
		
	}
	
	private boolean quantityIsValid(String quantitySTR) 
	{
		if(quantitySTR == null | quantitySTR.length() == 0)
		{
			System.out.println("null or length is zero");
			return false;
		}
		for (int i = 0; i < quantitySTR.length(); i++) 
		{
			if (Character.isDigit(quantitySTR.charAt(i))) 
			{
				continue;
			} 
			else 
			{
				System.out.println("quantitiy is not valid!");
				return false;
			}
		}

		System.out.println("quantity is valid so far");
		
		//BigDecimal quantityConvert = new BigDecimal(quantitySTR);
		
		try 
		{
			BigDecimal quantityConvert = new BigDecimal(
					quantitySTR .replaceAll(",", "") );
		} 
		catch (NumberFormatException e) 
		{
			e.printStackTrace();
			System.out.println("price invalid couldnt be converted to Big Decimal");
			return false;
		}
		
		return true;
	}

	 	 
}
