package model;

import java.math.BigDecimal;
import java.math.RoundingMode;

import yahoofinance.Stock;

public class CPstock 
{
	private Stock stock;
	private int quantity;
	private BigDecimal baseInvestment;
	
	public CPstock()
	{
		
	}
	
	public CPstock(Stock stock, int quantity)
	{
		this.stock = stock;
		this.quantity = quantity;
		baseInvestment = new BigDecimal(0);
	}
	
	public CPstock(Stock stock, int quantity, BigDecimal baseInvestment) 
	{
		this.stock = stock;
		this.quantity = quantity;
		this.baseInvestment = baseInvestment;
	}

	public Stock getStock()
	{
		return stock;
	}
	
	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}

	public BigDecimal getInvestment() 
	{
		return baseInvestment;
	}
	
	public BigDecimal getInvestmentRounded()
	{
		BigDecimal rounded = baseInvestment.setScale(2, RoundingMode.HALF_EVEN);
		return rounded;
	}
	
	public void setBaseInvestment(BigDecimal baseInvestment)
	{
		this.baseInvestment = baseInvestment;
	}
	
	public void addToBaseInvestment(BigDecimal stockPrice)
	{
		baseInvestment = baseInvestment.add(stockPrice);
	}
	
	public void removeFromBaseInvestment(BigDecimal stockPrice)
	{
		baseInvestment = baseInvestment.subtract(stockPrice);
	}
	
	
	
	
	
}
