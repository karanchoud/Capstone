package model;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Random;

public class FAKEDatabase

//this is a dummy implementation to test other methods until the actual database is implemented 

{
	
	
	private static FAKEDatabase database = new FAKEDatabase();
	
	private FAKEDatabase()
	{
		
	}
	
	public static FAKEDatabase getInstance()
	{
		return database;
	}
	
	HashMap<String,Player> playerMap = new HashMap<String,Player>();
	
	
	/*public boolean addPlayer(Player player)
	{
		//add the player to the hashmap
		
		if(playerMap.containsKey(player.getID()))
		{
			System.out.println("ERROR player ID already exists: fake database addplayer");
			return false;
			
		}
		else
		{
			playerMap.put(player.getID(),player);
			return true;
		}
		
	}
	*/
	
	public boolean addPlayer(Player player)
	{
		//add the player to the hashmap
		
		if(playerMap.containsKey(player.getUserName()))
		{
			System.out.println("ERROR player ID already exists: fake database addplayer");
			return false;
			
		}
		else
		{
			playerMap.put(player.getUserName(),player);
			return true;
		}
		
	}
	public boolean removePlayer(Player player)
	{
		if(playerMap.containsKey(player.getUserName()))
		{
			playerMap.remove(player.getUserName(),player);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public Player findPlayer(String playerID) //find the corresponding player within the map and return them
	{
		Player player = playerMap.get(playerID);
		
		
		return player;
	}
	
	public Player retrievePlayer(String username)
	{
		Player player = playerMap.get(username);
		
		return player;
	}

	public HashMap<String, Player> getPlayerMap() {
		return playerMap;
	}

	public void setPlayerMap(HashMap<String, Player> playerMap) 
	{
		this.playerMap = playerMap;
	}

	public boolean checkPlayerID(String playerID, String userName) 
	{
		
		return true;
	}
	
	public void generateTestPlayers(int playerNum) //generates a set of random players, amount specified by playerNum
	{
		for( int i = 0; i < playerNum; i ++)
		{
			Random rand = new Random();
			int randFunds = rand.nextInt();
			Player player = new Player("username" + Integer.toString(i),"password","firstName" + Integer.toString(i), "lastName" + Integer.toString(i), "IDNUM" + Integer.toString(i),"email");
			
			player.setFunds(new BigDecimal(randFunds));
			
			this.addPlayer(player);
		}
	}
	
	

	public void addPlayer(String userName, String password, String firstName, String lastName) 
	{
		System.out.println("this overwrite only exists on the real DB");
		
	}
	
	
	
}
