package unitTests;

import static org.junit.Assert.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

public class MarketSellTest
{	
	private RegisterServlet server;
	Player player;
	
	Stock stock;
	
	String user, user2, user3;
	String invalidStockCode, stockCode, stockCode2;
	BigDecimal stockPrice, staticStockPrice;
	BigDecimal expectedFunds;
	int quantity, negativeQuantity, zeroQuantity, greaterQuantity, lesserQuantity;
	ShareMarket sm;
	ArrayList<CPstock> portfolio;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "ruff";
		invalidStockCode = "notastockcode";
		stockCode = "MXC.AX";
		stockCode2 = "AJC.AX";
		user2 = "testPlayer2";
		user3 = "testPlayer3";
		
		db = Database.getInstance();
		sm = new ShareMarket();
		stockPrice = new BigDecimal(0.50);
		staticStockPrice = new BigDecimal(1);
		quantity = 1000;
		negativeQuantity = -1000;
		zeroQuantity = 0;
		greaterQuantity = 3000;
		lesserQuantity = 50;
		
	}
	@Test
	public void TestIncorrectStockInput() 
	{
		
		//player = db.getPlayer(user);
		
		boolean result = sm.marketOrderSell(user, invalidStockCode, stockPrice, quantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestIncorrectQuantityNegativeInput() 
	{
		
		
		
		boolean result = sm.marketOrderSell(user, stockCode, stockPrice, negativeQuantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestIncorrectQuantityZeroInput() 
	{
		
		
		
		boolean result = sm.marketOrderSell(user, stockCode, stockPrice, zeroQuantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestQuantityGreaterThanOwned() throws IOException 
	{
		stockPrice = YahooFinance.get(stockCode).getQuote().getAsk();
		

		boolean result = sm.marketOrderSell(user3, stockCode, stockPrice, greaterQuantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestQuantityExact() throws IOException 
	{
		stockPrice = YahooFinance.get(stockCode).getQuote().getAsk();
	

		boolean result = sm.marketOrderSell(user3, stockCode, stockPrice, quantity);
		assertEquals(true, result);
	}
	
	
	@Test
	public void TestQuantityLess() throws IOException 
	{
		stockPrice = YahooFinance.get(stockCode2).getQuote().getAsk();
	

		boolean result = sm.marketOrderSell(user3, stockCode2, stockPrice, lesserQuantity);
		assertEquals(true, result);
	}
	
	@After
	public void postTest() throws IOException
	{
		System.out.println("testing complete");
		//db.addToPlayerPortfolio(user3, YahooFinance.get(stockCode), quantity, new BigDecimal(1000));
		//db.addToPlayerPortfolio(user3, YahooFinance.get(stockCode2), quantity, new BigDecimal(50));
	}


}
