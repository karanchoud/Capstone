package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Database;
import model.FAKEDatabase;
import model.Player;

public class RegisterServlet extends HttpServlet
{
	private FAKEDatabase Fdatabase = FAKEDatabase.getInstance();
	
	private Database database = Database.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	 {
		if(request.getParameter("registerForm") != null)
		{
			
			System.out.println("handled by register servlet!");
			
			String firstName = request.getParameter("name");
			
			String lastName = request.getParameter("lastname");
			
			String userName = request.getParameter("username");
			
			String password = request.getParameter("password");
			
			String email = request.getParameter("email");
			
			System.out.println(firstName);		
			System.out.println(lastName);
			System.out.println(userName);
			System.out.println(password);
			
			//Fdatabase.addPlayer(userName,password,firstName,lastName);
			
			//database.addPlayer(userName,password,firstName,lastName,email);
			
			if(database.addPlayer(userName,password,firstName,lastName,email))
			{
				System.out.println("Player: " + userName + " registered to database successfully");
			}
			else
			{
				System.out.println("ERROR: database.addPlayer returned false. new player was not added to database");
			}
			
			//response.sendRedirect("login.jsp");		
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
			dispatcher.forward(request,response);
			
		}
		else
		{
			System.out.println("ERROR: RegisterServlet doPost: form was null");
		}
			
	}
}
