package model;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletMain extends HttpServlet {
	
	
	Connection conn;
	
	//conn = 
	public void authPlayer()
	{
		//Statement stmt = 
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://166.62.28.123:3306/stockmarketDB", "stockMarketAdmin", "passs");
		
		 Statement st = conn.createStatement();                                 

	     String query = "INSERT INTO test VALUES(1001, 'Adrian', 'Riscica')";

		st.executeUpdate(query);
		
		conn.close();
		} catch (SQLException ex) {
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		} 
		catch (ClassNotFoundException e) {
			System.out.println("Where is your MySQL JDBC Driver?");
			e.printStackTrace();
			return;
		}

		System.out.println("connection established!");
		
		 //Statement st = conn.createStatement();                                 

	        String query = "INSERT INTO Example (`TestColumn`) VALUES('hello')";

	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		System.out.println("hello world");
		authPlayer();
	}
		
		

	public void addPlayer(String user, String pass) 
	{
		
	}

}
