package unitTests;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;



import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;

public class LoginTest
{	
	private RegisterServlet server;
	Player player;
	
	Stock stock;
	
	String user, user2, correctPass, wrongPass, nullPass, nullUser;
	ArrayList<CPstock> portfolio;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "ruff";
		user2 = "aFakeUsername";
		nullUser = "";
		nullPass = "";
		correctPass = "CorrectPass1";
		wrongPass = "doesnotMatch23"; //less than 6 characters long
		db = Database.getInstance();
		Player player;
		
		
		
		
	}
	@Test
	public void checkForValidUser() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(true, db.authPlayer(user, correctPass));
		//assertEquals(true, db.getPlayer(user));
		System.out.println("its true");
		player = db.getPlayer(user);
		assertEquals(true, player != null);
	
		
	}
	
	@Test
	public void checkForInvalidUsername() 
	{
		/*test checks for addition of new player, NOTE: username must be a duplicate!*/
		assertEquals(false, db.authPlayer(user2, correctPass));
		
		
	
		
	}
	
	@Test
	public void checkNullUser() 
	{
		/*test checks for addition of new player, NOTE: username must be a duplicate!*/
		assertEquals(false, db.authPlayer(nullUser, correctPass));
		System.out.println("username is null");
	
		
	}
	
	@Test
	public void checkNullPass()
	{
		assertEquals(false, db.authPlayer(user, nullPass));
		
	}
	
	@Test
	public void checkPlayerLoadFailure()
	{
		player = db.getPlayer(user2);
		assertEquals(true, player == null);
	}
	
	@Test
	public void checkPassInvalid()
	{
		assertEquals(false, db.authPlayer(user, wrongPass));
		
	}
	
	@Test
	public void checkPortfolioNotEmpty()
	{
		player = db.getPlayer(user);
		portfolio = player.getPortfolio();
		assertEquals(true, player.getPortfolio() != null);
		
	}

}
