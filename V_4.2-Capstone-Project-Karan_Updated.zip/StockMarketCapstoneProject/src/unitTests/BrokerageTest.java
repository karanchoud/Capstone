package unitTests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;



import app.ServletMain;
import model.Player;
import yahoofinance.Stock;

public class BrokerageTest 
{	
	private ServletMain server;
	Player player;
	
	Stock stock;
	
	@Before
	public void setup() throws Exception 
	{
		server = new ServletMain();
		player = new Player();
		stock = server.getSingleStock("YHOO");
		
		server.getDatabase().addPlayer(player);
		
		
		
	}
	@Test
	public void test() 
	{
		server.marketOrder(player.getID(), "YHOO", stock.getQuote().getAsk(), 1);
		
		server.applyPurchaseBrokerFee(player, stock.getQuote().getAsk());
		
		System.out.println();
		
	}

}
