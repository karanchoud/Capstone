package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;


import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;

public class portfolioTest
{	
	private RegisterServlet server;
	Player player;
	
	Stock stock;
	ShareMarket sm = new ShareMarket();
	String user, user2, correctPass, password, first, last, email;
	double expectedFunds;
	ArrayList<CPstock> portfolio;
	int expectedPortfolioItems;
	private Database db;
	ArrayList<BigDecimal> expectedInvestments = new ArrayList<BigDecimal>();
	int[] expectedQuantities = new int[2];
	@Before
	public void setup() throws Exception 
	{
		
		user = "testPortfolioPlayer";
		user2 = "idontexist";
		password = "Password1";
		first = "Adrian";
		last = "Riscica";
		email = "s3383708@student.rmit.edu.au";
		db = Database.getInstance();
		Player player;
		expectedFunds = 1000000;
		db.addPlayer(user, password, first, last, email);
		expectedPortfolioItems = 2;
		expectedInvestments.add(new BigDecimal(3000));
		expectedInvestments.add(new BigDecimal(5000));
		expectedQuantities[0] = 30;
		expectedQuantities[1] = 50;
		
	}
	@Test
	public void TestPortfolioCountCorrect() 
	{
		
		Player player = db.getPlayer(user);
		int portfolioCount = player.getPortfolio().size();
		assertEquals(expectedPortfolioItems, portfolioCount); //0 indicates match (ie same value)
		
	}
		
	@Test
	public void TestPortfolioCalculationValue() 
	{
		//testing first portfolio item only, will indicate correctness of calculations.
		Player player = db.getPlayer(user);
		ArrayList<CPstock> portfolio = player.getPortfolio();
		
		BigDecimal currentValue = portfolio.get(0).getStock().getQuote().getPrice();
		BigDecimal currentPrice = new BigDecimal(portfolio.get(0).getQuantity());
		BigDecimal currentInvestment = portfolio.get(0).getInvestment();
		currentPrice = currentPrice.multiply(currentValue);
		BigDecimal finalValue = currentInvestment.subtract(currentPrice);
		if(finalValue.compareTo(BigDecimal.ZERO) < 0)
		{
			finalValue = finalValue.multiply(new BigDecimal(-1));
		}
		
		
		ArrayList<ProfitLoss> profitsLoss = sm.calculateProfitLoss(player.getPortfolio());
		
		assertEquals(profitsLoss.get(0).getValueChange(), finalValue);
		
		
		
	
		
	}
	
	@Test
	public void TestPortfolioCalculationPercentage() 
	{
		//testing first portfolio item only, will indicate correctness of calculations.
		Player player = db.getPlayer(user);
		ArrayList<CPstock> portfolio = player.getPortfolio();
		
		BigDecimal currentValue = portfolio.get(0).getStock().getQuote().getPrice();
		BigDecimal currentPrice = new BigDecimal(portfolio.get(0).getQuantity());
		BigDecimal currentInvestment = portfolio.get(0).getInvestment();
		currentPrice = currentPrice.multiply(currentValue);
		BigDecimal finalValue = currentInvestment.subtract(currentPrice);
		if(finalValue.compareTo(BigDecimal.ZERO) < 0)
		{
			finalValue = finalValue.multiply(new BigDecimal(-1));
		}
		
		
		ArrayList<ProfitLoss> profitsLoss = sm.calculateProfitLoss(player.getPortfolio());
		BigDecimal calculatePercent = finalValue.divide(currentInvestment, 3, RoundingMode.HALF_EVEN);
		calculatePercent = calculatePercent.multiply(new BigDecimal(100));
		System.out.println(calculatePercent);
		System.out.println(profitsLoss.get(0).getPercentChange());
		
		
		BigDecimal roundedPercent = calculatePercent.setScale(2, RoundingMode.HALF_EVEN);
		
		assertEquals(profitsLoss.get(0).getPercentChange(), roundedPercent);
		
		
		
	
		
	}	
	
	@Test
	public void checkInvestmentValues()
	{
		Player player = db.getPlayer(user);
		ArrayList<CPstock> portfolio = player.getPortfolio();
		
		for(int i=0; i<portfolio.size();i++)
		{
			assertEquals(portfolio.get(i).getInvestment(), expectedInvestments.get(i));
		}
		
	}

	
	@Test
	public void checkQuantityValues()
	{
		Player player = db.getPlayer(user);
		ArrayList<CPstock> portfolio = player.getPortfolio();
		
		for(int i=0; i<portfolio.size();i++)
		{
			assertEquals(portfolio.get(i).getQuantity(), expectedQuantities[i]);
		}
		
	}
	
}
