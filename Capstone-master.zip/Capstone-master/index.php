<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<head>
</head>
<title> Welcome to The Stock Market Trading Web Page </title>
<link rel="stylesheet" type="text/css" href="styling.css" />
<body>
<div class="content">
<h1> Stock Market </h1>
</div>
<div class="content">
<h2><i> Build No: 1.0 </i></h2>
</div>

<div class="menu">

<ul>
  <li><a href="#home">Home</a></li>
  <li><a href="#news">News</a></li>
  <li><a href="#contact">Contact</a></li>
  <li><a href="#about">About</a></li>
</ul>

</div>
<div class="tablebg">
<div class="table-wrapper">
<div class="table-scroll">
    <table cellspacing="0" cellpadding="1" border="1" align = "center">
        <thead>

        </thead>
        <tbody>

        </tbody>
    </table>
	</div>
  </div>
</div>
</body>



</html>