/**
 * 
 */
package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import model.FAKEDatabase;
import model.OrderBook;
import model.Player;
import model.Request;
import model.ShareMarket;
import yahoofinance.Stock;

/**
 * @author Dan
 *
 */
public class OrderBookTest {

	private OrderBook orderBook;
	private ShareMarket market = new ShareMarket();
	//private FAKEDatabase database;
	
	private Request buyRequest;	
	private Request buyRequest2;	
	private Request sellRequest;	
	private Request sellRequest2;
	
	private Player buyer;
	private Player buyer2;
	private Player buyer3;
	
	private Player seller;
	private Player seller2;
	private Request buyRequest3;
	private Request buyRequest4;
	
	


	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception 
	{		
		 
		 orderBook = new OrderBook(/*market*/);
		
		//generateTestRequests(10,orderBook);
		
		buyer = new Player();
		buyer.setUserName("buyer");
		
		buyer2 = new Player();
		buyer2.setUserName("buyer2");
		
		seller = new Player();
		seller.setUserName("seller");
		
		seller2 = new Player();
		seller2.setUserName("seller2");
		
		buyer3 = new Player();
		buyer3.setUserName("buyer3");
		
		Stock stock = market.getSingleStock("YHOO");
		
		market.addStock(seller, stock, 25, stock.getQuote().getAsk());
		
		market.addStock(seller2, stock, 25,stock.getQuote().getAsk());
		
		
		market.getTESTDatabase().addPlayer(buyer);
		market.getTESTDatabase().addPlayer(buyer2);
		market.getTESTDatabase().addPlayer(seller);
		market.getTESTDatabase().addPlayer(seller2);
		
		market.getTESTDatabase().addPlayer(buyer3);
		
		
		buyRequest = new Request("buyer", "YHOO", 10, new BigDecimal(25));

		buyRequest2 = new Request("buyer2", "YHOO", 15, new BigDecimal(25));
		
		buyRequest3 = new Request("buyer3","YHOO",50, new BigDecimal(25));
		
		buyRequest4 = new Request("buyer","YHOO",25,new BigDecimal(25));

		sellRequest = new Request("seller", "YHOO", 25, new BigDecimal(25));

		sellRequest2 = new Request("seller2", "YHOO", 25, new BigDecimal(20));

		orderBook.getBuyOrderQueue().add(buyRequest);

		orderBook.getBuyOrderQueue().add(buyRequest2);

		orderBook.getSellOrderQueue().add(sellRequest);

		orderBook.getSellOrderQueue().add(sellRequest2);
		
	}
	
	@After
	public void tearDown()
	{
		market.getTESTDatabase();
		FAKEDatabase.getInstance().getPlayerMap().clear();
	}

	@Test
	public void testRequestMatch() 
	{
		Request Request = new Request("name", "YHOO",10, new BigDecimal(25));
		Request Request2 = new Request("name", "YHOO",10, new BigDecimal(25));
		
		assertEquals(orderBook.requestMatch(Request, Request2),false); //false because of the same name
				
		Request Request3 = new Request("name", "YHOO",20, new BigDecimal(25));
		Request Request4 = new Request("name2", "YHOO",30, new BigDecimal(30));
		
		assertEquals(orderBook.requestMatch(Request3, Request4),false); //false because the seller (request4) is too high
		
		Request Request5 = new Request("name", "no",10, new BigDecimal(25));
		Request Request6 = new Request("name", "YHOO",10, new BigDecimal(25));
		
		assertEquals(orderBook.requestMatch(Request5, Request6),false); //false because the stock doesn't match
		
		Request Request7 = new Request("name", "YHOO",10, new BigDecimal(25));
		Request Request8 = new Request("name2", "YHOO",10, new BigDecimal(25));

		assertEquals(orderBook.requestMatch(Request7, Request8),true);
		
		Request.setCompleted(true);
		
		assertEquals(orderBook.requestMatch(Request, Request2),false); //false because buy is a completed request
		
		Request2.setCompleted(true);
		
		assertEquals(orderBook.requestMatch(Request, Request2),false); //false because sell is a completed request
	}
	
	@Test
	public void TestMatchOrder()
	{
		orderBook.matchOrder(buyRequest, sellRequest);
		
		assertEquals(buyRequest.isCompleted(),true);
		
		assertEquals(buyer.getPortfolio().get(0).getQuantity(),10);
		
		assertEquals(seller.getPortfolio().get(0).getQuantity(),15);
		
		assertEquals(sellRequest.isCompleted(),false);
		
		
	}
	
	@Test
	public void testBuyMoreThanSeller() //tests to see if the buyer can buy from multiple sellers to complete their order
	{
		orderBook.matchOrder(buyRequest3, sellRequest);
		
		assertEquals(sellRequest.isCompleted(),true);
		
		assertEquals(buyRequest3.isCompleted(),false);
		
		orderBook.matchOrder(buyRequest3, sellRequest2);
		
		assertEquals(sellRequest2.isCompleted(),true);
		
		assertEquals(buyRequest3.isCompleted(),true);
				
	}
	
	@Test
	public void TestSellToMultipleBuyers()
	{
		orderBook.matchOrder(buyRequest, sellRequest);
		
		assertEquals(buyRequest.isCompleted(),true);
		
		assertEquals(sellRequest.isCompleted(),false);
		
		orderBook.matchOrder(buyRequest2, sellRequest);
		
		assertEquals(sellRequest.isCompleted(),true);
	}
	
	@Test
	public void TestBuyLessThanSeller()
	{		
		orderBook.matchOrder(buyRequest, sellRequest);
		
		assertEquals(buyRequest.isCompleted(),true);
		
		assertEquals(sellRequest.isCompleted(),false);
		
	}
	
	@Test
	public void TestBuyEqualAmountToSeller()
	{
		orderBook.matchOrder(buyRequest4, sellRequest);
		
		assertEquals(buyRequest4.isCompleted(),true);
		
		assertEquals(sellRequest.isCompleted(),true);
		
		
	}
}
