package model;

import java.math.BigDecimal;

public class ProfitLoss {

	private BigDecimal percentChange;
	private BigDecimal valueChange;
	private int posNegFlag; 
	public ProfitLoss(BigDecimal percentChange, BigDecimal valueChange)
	{
		this.percentChange = percentChange;
		this.valueChange = valueChange;
		posNegFlag = 0;
	}
	
	public BigDecimal getPercentChange()
	{
		return percentChange;
	}
	
	public BigDecimal getValueChange()
	{
		return valueChange;
	}
	
	public void setPercentChange(BigDecimal percentChange)
	{
		this.percentChange = percentChange;
	}
	
	public void setValueChange(BigDecimal valueChange)
	{
		this.valueChange = valueChange;
	}
	
	public int getPosNeg()
	{
		return posNegFlag;
	}
	
	public void setPosNeg(int posNeg)
	{
		posNegFlag = posNeg;
	}
	
}
