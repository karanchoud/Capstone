/**
 * 
 */
package model;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.LinkedList;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;



/**
 * Handles all the trading requests of the stock market game. 
 * Uses a price/Time Priority Queue to handle player requests 
 * to trade stock.The two Queues are supplied by the external
 * Database as well as the Players information. After checking 
 * all the Requests, all completed requests will be deleted 
 * and the updated Queues uploaded to the database.
 * 
 * @author Dan, s3388091
 *
 */
public class OrderBook implements Runnable
{
	private LinkedList<Request> buyOrders;
	private LinkedList<Request> sellOrders;
	private Database database;
	private FAKEDatabase Fdatabase;
	private ShareMarket shareMarket;
	
	public OrderBook(/*ShareMarket shareMarket*/)
	{
		//this.shareMarket = shareMarket;
		this.shareMarket = new ShareMarket();
		database = Database.getInstance();
		Fdatabase = FAKEDatabase.getInstance();
		buyOrders = new LinkedList<Request>();
		sellOrders = new LinkedList<Request>();
	}
	//use .add() and .removeFirst() to manage to queues buyOrders and sellOrders
	
	
	public void run()
	{
		System.out.println("RUNNING INSIDE ORDERBOOK RUN METHOD");
		try {
			checkOrders();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Loops through the buying and selling Queues to find suitable trade requests and processes them
	 * @throws IOException 
	 * 
	 */
	public void checkOrders() throws IOException
	{
		
		buyOrders = database.getAllBuyRequests();
		sellOrders = database.getAllSellRequests();
		
		if(buyOrders.isEmpty()|sellOrders.isEmpty()) //if one of the queues is empty no requests can be done 
		{
			System.out.println("buy or sell Queue empty cannot complete any trades.... terminating OrderBook checkOrders();");
			return;
		}
		
		Request sellRequest = sellOrders.getFirst();	
		Request buyRequest = buyOrders.getFirst();
		
		
		for(int i = 0; i < buyOrders.size(); i++)//loop through the queue of buyers and sellers searching for a match
		{
			buyRequest = buyOrders.get(i);
			
			for(int j = 0; j < sellOrders.size(); j++)
			{
				sellRequest = sellOrders.get(j);
				
				if(requestMatch(buyRequest,sellRequest)) //if the requests match
				{
					matchOrder(buyRequest,sellRequest); //complete the trade
				}
			}
		}
		this.updateAllRecords(); //update the Queues to the database
	}
	
	
	
	/**
	 * Handles a buy and sell request that are compatible, if orders are only partially completed the request is updated accordingly
	 * @param buyRequest
	 * @param sellRequest
	 */
	public void matchOrder(Request buyRequest, Request sellRequest)
	{
				
		//if the requests match
		if(requestMatch(buyRequest,sellRequest))
		{
			int quantityToBeTraded = 0;
			
			if(buyRequest.getQuantity() == sellRequest.getQuantity()) //if both orders will be completed
			{
				quantityToBeTraded = buyRequest.getQuantity();
				
				processRequests(buyRequest,sellRequest,quantityToBeTraded); //exchange money and stock accordingly
				
				sellRequest.setCompleted(true); //set requests to completed ready to be removed
				
				buyRequest.setCompleted(true);
				
				return;				
			}
			
			
			//calculate how much of the buy order is being done if the quantities do not match
			
			
			//if the buyer is trying to buy more stock than what the seller is offering
			if(buyRequest.getQuantity() > sellRequest.getQuantity())
			{
				quantityToBeTraded = buyRequest.getQuantity() - sellRequest.getQuantity(); //calculate the amount of stock to be exchanged
				
				processRequests(buyRequest,sellRequest,quantityToBeTraded); //exchange money and stock accordingly
				
				buyRequest.setQuantity(buyRequest.getQuantity() - quantityToBeTraded); //update the request to search for remaining stock in the order
				
				sellRequest.setCompleted(true);
				
				buyRequest.setModified(true); //the buy request has changed and must be updated on the database
			}
			
			//if the buyer is trying to buy less stock than what the seller is offering
			else 
			{
				//quantityToBeTraded = sellRequest.getQuantity() - buyRequest.getQuantity();
				quantityToBeTraded = buyRequest.getQuantity();
				
				processRequests(buyRequest,sellRequest,quantityToBeTraded); //exchange money and stock accordingly
				
				sellRequest.setQuantity(sellRequest.getQuantity() - quantityToBeTraded);
				
				buyRequest.setCompleted(true); //buy request is completed ready to be deleted
				
				sellRequest.setModified(true); //the sell request has changed and must be updated on the database
				
			}
			
		}
		
		
		//process order and update them accordingly
		
		
		//continue through buy requests to fill rest of selling request
		
	}
	
	/**
	 * Checks to see if The buying and selling requests are a match
	 * @param buyRequest
	 * @param sellRequest
	 * @return
	 * Returns true if the requests match and false if they are not
	 */
	public boolean requestMatch(Request buyRequest, Request sellRequest)
	{
		if(buyRequest.isCompleted()) //if the buy request is already completed
		{
			return false;
		}
		if(sellRequest.isCompleted()) //if the sell request is already completed
		{
			return false;
		}
		
		if(buyRequest.getUsername().equals(sellRequest.getUsername())) //if the buyer and the seller are the same player
		{
			return false;
		}
		
		//if the buying price is higher or equal to the sellers price and its the same stock
		if(buyRequest.getPrice().compareTo(sellRequest.getPrice()) >= 0 && sellRequest.getSymbol().equals(buyRequest.getSymbol())) 
		{
			return true; //the requests are a trade match
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * Exchanges stock and funds between players
	 * The price to be traded at will always be the sellers request as the system benefits the buyer, if the buyers limit order is 20
	 * and the seller is selling at 15 the buyer will buy at 15 for that transaction.
	 * This method must be called after requestMatch() to ensure prices are in acceptable ranges of each other
	 * 
	 * @param buyRequest - The buyers information regarding the trade, Price, QTY and the stock
	 * @param sellRequest - The sellers information regarding the trade, price QTY and the stock
	 * @param quantityToBeTraded - The amount of Stock to be exchanged 
	 */
	private void processRequests(Request buyRequest, Request sellRequest, int quantityToBeTraded) 
	{
		BigDecimal tradePrice = sellRequest.getPrice();
		
		Player buyer = database.getPlayer(buyRequest.getUsername());			
		Player seller = database.getPlayer(sellRequest.getUsername());
		
		//Player buyer = Fdatabase.retrievePlayer(buyRequest.getUsername()); //fake database used when running JUNIT TESTS to avoid adding test players on the real database			
		//Player seller = Fdatabase.retrievePlayer(sellRequest.getUsername());
		
		if(buyer == null || seller == null) //the players are not in the database
		{
			System.out.println(" ERROR in processRequests: Players buyer or seller were null");
			
			return;
		}
		
		
		BigDecimal sellersProfit = tradePrice.multiply(new BigDecimal(quantityToBeTraded)); //returns how much the seller is making
		
		//handle seller side
				
		if(shareMarket.removeStock(seller, sellRequest.returnStock(), quantityToBeTraded,tradePrice)) //if the seller has the stock remove it
		{
			seller.setFunds(seller.getFunds().add(sellersProfit)); //add the new funds to the seller
			System.out.println("should run remove Here");
			
			//database.removeFromPlayerPortfolio(seller.getUserName(), sellRequest.returnStock(), quantityToBeTraded);
			//amend database funds here
			//database.modifyPlayerFunds(seller.getUserName(), sellersProfit);
			shareMarket.applySalesBrokerFee(seller, tradePrice); //apply broker tax
			database.ModifyPlayerFunds(seller.getUserName(), seller.getFunds());
			//handle buyers side
			buyer.setFunds(buyer.getFunds().subtract(sellersProfit)); //take the funds from the buyer
			
			//database.addToPlayerPortfolio(buyer.getUserName(), buyRequest.returnStock(), quantityToBeTraded, sellersProfit);
			//amend database funds here
			//database.deductPlayerFunds(buyer.getUserName(), sellersProfit);
			shareMarket.applyPurchaseBrokerFee(buyer, tradePrice); //apply broker tax
			database.ModifyPlayerFunds(buyer.getUserName(), buyer.getFunds());
			shareMarket.addStock(buyer, buyRequest.returnStock(), quantityToBeTraded,tradePrice); //add the stock to the buyer
			
			//database.removeFromPlayerPortfolio(seller.getUserName(), sellRequest.returnStock(), quantityToBeTraded);
			//database.addToPlayerPortfolio(buyer.getUserName(), buyRequest.returnStock(), quantityToBeTraded, sellersProfit);
		}
		else
		{
			System.out.println("ERROR: could not remove stock from seller, request invalid!...... inside processRequests()");
		}
		
		
	}
		
	/**
	 * updates the current state of the buying and selling Queue to the Player Request database records
	 * @throws IOException 
	 */
	private void updateAllRecords() throws IOException
	{
		for(int i = 0; i < buyOrders.size(); i++) //loop through the buying Queue, remove completed requests and update the database
		{
			if(buyOrders.get(i).isCompleted())
			{
				database.deletePlayerBuyRequest(buyOrders.get(i)); //delete the record in the database
				
				buyOrders.remove(i);
			}
			else if(buyOrders.get(i).wasModified()) //the order wasn't completed fully so the record must be updated on the database
			{
				Player player = database.getPlayer(buyOrders.get(i).getUsername());
				
				database.buyUpdate(player, buyOrders.get(i).getSymbol(), buyOrders.get(i).getQuantity(), buyOrders.get(i).getPrice()); //update the record in the database
				
			}
		}
		
		for(int i = 0; i < sellOrders.size(); i++) //loop through the selling Queue, remove completed requests and update the database
		{
			if(sellOrders.get(i).isCompleted())
			{
				database.deletePlayerSellRequest(sellOrders.get(i)); //delete the record in the database
				sellOrders.remove(i);
				
			}
			else if(sellOrders.get(i).wasModified()) //the order wasn't completed fully so the record must be updated on the database
			{
				Player player = database.getPlayer(sellOrders.get(i).getUsername());
				
				database.sellUpdate(player, sellOrders.get(i).getSymbol(), sellOrders.get(i).getQuantity(), sellOrders.get(i).getPrice()); //update the record in the database
			}
		}
		
		
	}



	/**
	 * 
	 * @return 
	 * the Queue containing all the buy Requests
	 */
	public LinkedList<Request> getBuyOrderQueue() 
	{		
		return buyOrders;
	}
	/**
	 * 
	 * @return
	 * the Queue containing all the buy Requests
	 */
	public LinkedList<Request> getSellOrderQueue() 
	{	
		return sellOrders;
	}

	
	
	
	
	
	
	
}
