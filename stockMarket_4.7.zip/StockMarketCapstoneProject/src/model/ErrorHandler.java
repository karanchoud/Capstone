package model;

import java.io.IOException;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;

import enums.ErrorType;

public class ErrorHandler 
{
	private HttpSession session;
	private JspWriter out;
	
	public ErrorHandler(HttpSession session, JspWriter out)
	{
		this.session = session;
		this.out = out;
	}
	
	public void checkForErrors() throws IOException
	{
		ErrorType error = (ErrorType) session.getAttribute("errorMsg");
		
		if(error == null)
		{
			error = ErrorType.noErrors;
		}
		
		
		switch(error)
		{

		case noErrors:
				System.out.println("CASE: NO ERRORS");
				
				
			break;

		case notLoggedIn:
			System.out.println("CASE: notLoggedIn");
			
			out.println("you need to login first");
			
			this.clearErrorMsg();

			break;

		case InvalidPass:
			System.out.println("CASE: InvalidPass");
			
			out.println("Invalid username or password!");
			this.clearErrorMsg();
			
			break;

		case InvalidQuantity:
			System.out.println("CASE: InvalidQuantity");
			
			out.println("Invalid Quantity entered!");
			this.clearErrorMsg();

			break;
		
		case InvalidPrice:
			System.out.println("CASE: InvalidPrice");
			
			out.println("Invalid Price entered");
			this.clearErrorMsg();

			break;
		
		case NotEnoughFunds:
			System.out.println("CASE: NotEnoughFunds");
			
			out.println("you dont have enough funds for this transaction");
			
			this.clearErrorMsg();

			break;

		case InvalidPlayer:
			System.out.println("CASE: InvalidPlayer");
			
			out.println("Player could not be found or is invalid");
			this.clearErrorMsg();

			break;
		case InvalidMarketOrder:
			System.out.println("CASE: Invalid Market Order");
			
			out.println("Market Order was Invalid please check Price and quantity are correct");
			this.clearErrorMsg();
			break;
			
		case InvalidBidOrder:
			System.out.println("CASE: Invalid Bid Order");
			
			out.println("Bid Order was Invalid please check Price and quantity are correct");
			this.clearErrorMsg();
			break;
			
		case InvalidAmendOrder:
			System.out.println("CASE: Invalid Amend Order");
			
			out.println("Bid Order was Invalid please check Price and quantity are correct");
			this.clearErrorMsg();
			
			break;

		default:
			System.out.println("default case inside error handler something went wrong");
			break;
	
		}
	}
	
	public boolean checkForLogin()
	{
		if(session.getAttribute("username") != null)
		{
			
			String userName = (String) session.getAttribute("username");
			
			System.out.println("Logged in as:" + userName);
			return true;
		}
		else
		{
			System.out.println("No user logged in");
			return false;
		}
	}
	
	public void clearErrorMsg()
	{
		session.setAttribute("errorMsg",ErrorType.noErrors);
	}
	
	
	
	
}


