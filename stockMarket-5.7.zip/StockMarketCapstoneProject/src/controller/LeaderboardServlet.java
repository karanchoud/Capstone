package controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Database;
import model.Leaderboard;
import model.Validation;

/**
 * Returns a sorted Leader board to the front end on HTTP get Requests
 */
public class LeaderboardServlet extends HttpServlet
{
	private Database database = Database.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		HttpSession session = request.getSession();
		
		if(Validation.redirectedToLogin(request, response, session))
		{
			return;
		}
		
		
		Leaderboard leaderBoard = new Leaderboard();
		
		
		leaderBoard.getPlayerLeaderBoard().addAll(database.getAllPlayers()); //populate the leaderBoard from the database
		//leaderBoard.getPlayerLeaderBoard().addAll(database.getTop10Players());//populate the leaderBoard from the database
		
		leaderBoard.sortLeaderBoard(); //sort the leaderBoard
		
		request.setAttribute("leaderBoard", leaderBoard);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("leaderboard.jsp"); //return all info back to the client
		dispatcher.forward(request,response);
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doGet(request,response);
	}
}
