package unitTests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import model.Leaderboard;


public class LeaderBoardTest 
{
	private Leaderboard leaderBoard;
	
	@Before
	public void setUp() throws Exception 
	{
		leaderBoard = new Leaderboard();	
	}

	@Test
	public void test() 
	{
		leaderBoard.generateTestPlayers(20);
		
		leaderBoard.ShowTopPlayers(15);
		
		for(int i = 1; i < leaderBoard.getPlayerLeaderBoard().size(); i++)
		{
			if(leaderBoard.getPlayerLeaderBoard().get(i).getTotalFunds().doubleValue() < leaderBoard.getPlayerLeaderBoard().get(i - 1).getTotalFunds().doubleValue())
			{
				assertTrue(true);
			}
			else
			{
				assertTrue(false);
			}
		}	
	}

}
