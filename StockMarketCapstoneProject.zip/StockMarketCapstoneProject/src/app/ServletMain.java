package app;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.CPstock;
import model.Database;
import model.Player;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

/**
 * The main HTTPServlet Application for the stock market program. Handles all player requests when
 * playing the game, buying, selling and trading stock. 
 * @author Daniel Lenders s3388091@student.rmit.edu.au
 *
 */

@SuppressWarnings("serial")
public class ServletMain extends HttpServlet
{	
	
	private Database database = new Database(); //stores player info
	/**
	 * Handles all get method requests from the jsp pages
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException //returning stocks and player field updates
	{	
		System.out.println("testing?");
		
		String playerSingleStock = req.getParameter("singleStock");
		
		String[] stockList = req.getParameterValues("stockarray");
		
		//TODO stock symbol validation and sanitation
		
		if(playerSingleStock != null) //if the form submitted contained a request for 1 stocks data
		{
			//Stock stock = YahooFinance.get(playerSingleStock);
			
			Stock stock = getSingleStock(playerSingleStock);
			
			req.setAttribute("singleStockReq", stock);
		}
		
		if(stockList != null)
		{
			Map<String,Stock> stockMap; //map to store stock info
			
			stockMap = YahooFinance.get(stockList); //API request for stock info
			
			printStockmap(stockMap); //print stock map mainly here for testing values
			
			//return the stockmap to the user			
		}
		
		
		System.out.println(playerSingleStock);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp?singleStockReq=good"); //return all info back to the client
		dispatcher.forward(req,resp);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException //handles buy sell requests from player
	{
		
	}
	
	
	
	
	
	
	
	private static void printStockmap(Map<String,Stock> stockMap) //prints all stock info from a map
	{
		for(Entry<String,Stock> mapEntry : stockMap.entrySet()) //loop through each entry in the map
		{
			//String currentKey = mapEntry.getKey();
			//System.out.println(currentKey);
			Stock currentStock = mapEntry.getValue(); //assigns the map key's value to a stock object
						
			currentStock.print(); //print the current stock's info
		}
	}
	
	/**
	 * Makes a call to the Yahoo finance API for stock information.
	 * @param stockSymbol - The Symbol used to represent a company's stock.
	 * @return
	 * 
	 * A stock object containing all information regarding that stock
	 */
	public Stock getSingleStock(String stockSymbol) //makes a call to the Yahoo finance API for a stock's latest information
	{
		Stock stock;
		try 
		{
			stock = YahooFinance.get(stockSymbol);
			
			return stock;
		} 
		catch (IOException e) 
		{
			System.out.println("ERROR: Invalid stock symbol returning NULL");
			e.printStackTrace();
		}
		
		return null;
	}
	/**
	 * allows players to purchase stock and add stock to their port folio. updates player funds accordingly
	 * 
	 * @param playerID  - The players unique ID to the server.
	 * @param stockSymbol - The Symbol used to represent a company's stock. 
	 * @param stockPrice - The price the player is willing to buy the stock at.
	 * @param quantity - The amount of stock the Player is trying to buy.
	 */
	public void marketOrder(String playerID, String stockSymbol, BigDecimal stockPrice, int quantity) //a player order that will buy stock at the current ask price of the stock
	{
		Stock stock = getSingleStock(stockSymbol);
		
		if(stock.getQuote().getAsk().equals(stockPrice)) //if the player bid matches the stocks current ask price
		{
			System.out.println("Market order match found processing order......");
			
			Player currentPlayer = database.findPlayer(playerID); //retrieve the player object from the database
			
			BigDecimal checkFunds = calcNewFunds(currentPlayer,stockPrice,quantity); //verify the player can afford to purchase the stock(s)
			
			if(checkFunds != null) //if they can afford to buy the stock at market price
			{
				currentPlayer.setFunds(checkFunds); //update the players funds
				//TODO calculate equity funds
				//currentPlayer.setEquityFunds(equityFunds);
				
				addStock(currentPlayer,stock,quantity); //adds the stock to the players portfolio
				
			}
			
		}
		else
		{
			System.out.println("stock ask price does not match player bid, unable to complete Market Order");
		}
		
		
	}
	/**
	 * 
	 * @param playerID
	 * @param stockSymbol
	 * @param stockPrice
	 * @param quantity
	 */
	public void marketOrderSell(String playerID, String stockSymbol, BigDecimal stockPrice, int quantity) //sells player stock at market ask price
	{
		Stock stock = getSingleStock(stockSymbol);
		
		if(stock.getQuote().getAsk().equals(stockPrice))
		{
			System.out.println("sell price matches current Ask price processing.....");
			
			Player currentPlayer = database.findPlayer(playerID);
			
			if(removeStock(currentPlayer,stock,quantity)) //if the player's stock request is valid and removed
			{
				BigDecimal totalProfit = stockPrice.multiply(new BigDecimal(quantity)); //calculate the players profit
				
				currentPlayer.setFunds(currentPlayer.getFunds().add(totalProfit)); //add the profits to the players funds
				
				System.out.println("Market Order sell transaction completed.....");
			}
			else
			{
				System.out.println("market order cancelled.. removeStock returned false");
			}			
		}
		
		
		
	}
	
	private boolean removeStock(Player currentPlayer, Stock stock, int quantity) //remove stock from the players port folio
	{
		for(int i = 0; i < currentPlayer.getPortfolio().size(); i ++) //loop through the players port folio
		{
			if(currentPlayer.getPortfolio().get(i).getStock().getSymbol().equals(stock.getSymbol())) //if the stock exists in the player port folio 
			{
				int oldQuantity = currentPlayer.getPortfolio().get(i).getQuantity(); 
				
				int newQuantity = oldQuantity - quantity;
				
				if(oldQuantity < quantity)
				{
					System.out.println("ERROR: player trying to sell more stock then they own...");
					return false;
				}
				
				
				if(newQuantity == 0)
				{
					currentPlayer.getPortfolio().remove(i); //if the player doesn't own any stock in the company anymore
					
					return true;
				}
				else
				{
					currentPlayer.getPortfolio().get(i).setQuantity(newQuantity); //remove the amount of stock being sold
					return true;
				}
			}
		}
		
		return false;
		
	}

	private void addStock(Player currentPlayer,Stock stock,int quantity) //adds the stock to the players portfolio
	{
		for(int i = 0; i < currentPlayer.getPortfolio().size(); i++) //loop through the list of currently owned stocks
		{
			if(currentPlayer.getPortfolio().get(i).getStock().getSymbol().equals(stock.getSymbol())) //if the player has invested in this stock before
			{
				currentPlayer.getPortfolio().get(i).setQuantity(quantity + currentPlayer.getPortfolio().get(i).getQuantity()); //increase the quantity of owned stock
				
				System.out.println("Market Order purchase completed...increased quantity of existing stock: " + stock.getSymbol());
				return;
			}
		}
		//if the player doesnt own any of this stock create a new stock and add it to the port folio				
		currentPlayer.getPortfolio().add(new CPstock(stock,quantity)); //adds the purchased stock to the player's portfolio
		
		System.out.println("Market Order purchase completed added new stock to portfolio: " + stock.getSymbol());	
	}
	
	public BigDecimal calcNewFunds(Player player, BigDecimal stockPrice, int quantity) //deducts the current purchase from the players total
	{
		BigDecimal newTotal = player.getFunds(); //current funds before the purchase
		
		if(quantity == 1)
		{
			newTotal = newTotal.subtract(stockPrice);
			
			if(newTotal.compareTo(BigDecimal.ZERO) >= 0) //if the exchange doesn't put the players funds into negative
			{
				return newTotal; //return the new total
			}
			else
			{
				System.out.println("not enough funds");
				return null;
			}
		}
		else
		{
			BigDecimal totalCost = stockPrice.multiply(new BigDecimal(quantity)); //the cost to buy all the stock in the order
			
			newTotal = newTotal.subtract(totalCost);
			
			if(newTotal.compareTo(BigDecimal.ZERO) >= 0) //if the exchange doesn't put the players funds into negative
			{
				return newTotal; //return the new total
			}
			else
			{
				System.out.println("not enough funds");
				return null;
			}
			
		}	
	}
	
	
	private BigDecimal calcEquityFunds(Player player) //calculates the players equity funds after purchase
	{
		BigDecimal equityFunds = new BigDecimal(0);
		
		
		
		BigDecimal currentMarketPrice = new BigDecimal(0);
		
		
		
		return equityFunds;
	}
	
	private void calcTotalFunds(Player player) //calculates the players total amount of money based on current stock investments and money
	{
		
	}
	
	public Database getDatabase()
	{
		return database;
	}
	
	public Player createPlayer(String userName, String pass, String firstName, String lastName)
	{
		
		String playerID = UUID.randomUUID().toString();
		
		if(database.checkPlayerID(playerID,userName))
		{
			Player newPlayer = new Player(userName, pass, firstName, lastName, playerID);
			
			return newPlayer;
		}
		
		
		return null;
	}
	
	
	
	
	
	
}
