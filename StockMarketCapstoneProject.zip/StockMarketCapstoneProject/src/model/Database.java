package model;

import java.util.HashMap;

public class Database //used to store player IDs, current stock data owned by players, and player account info

//this is a dummy implementation to test other methods until the actual database is implemented 

{
	HashMap<String,Player> playerMap = new HashMap<String,Player>();
	
	
	public boolean addPlayer(Player player)
	{
		//add the player to the hashmap
		
		if(playerMap.containsKey(player.getID()))
		{
			System.out.println("ERROR player ID already exists");
			return false;
			
		}
		else
		{
			playerMap.put(player.getID(),player);
			return true;
		}
		
	}
	
	public boolean authPlayer()
	{
		return false;
	}

	public Player findPlayer(String playerID) //find the corresponding player within the map and return them
	{
		Player player = playerMap.get(playerID);
		
		
		return player;
	}

	public HashMap<String, Player> getPlayerMap() {
		return playerMap;
	}

	public void setPlayerMap(HashMap<String, Player> playerMap) {
		this.playerMap = playerMap;
	}

	public boolean checkPlayerID(String playerID, String userName) 
	{
		
		return true;
	}
	
	
	
}
