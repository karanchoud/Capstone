package model;

import java.util.ArrayList;

import yahoofinance.Stock;

public class CPstock 
{
	private Stock stock;
	int quantity;
	
	public CPstock()
	{
		
	}
	
	public CPstock(Stock stock, int quantity)
	{
		this.stock = stock;
		this.quantity = quantity;		
	}
	
	
	public Stock getStock()
	{
		return stock;
	}
	
	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	
	
	
	
}
