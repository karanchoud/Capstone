package model;

public class StockPortFolio 
{

}
