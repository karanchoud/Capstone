package enums;

public enum OrderType 
{
	marketOrder,marketOrderSell,bidOrder,bidOrderSell
}
