package model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.UUID;


public class Player 
{
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	private String ID; 
	private BigDecimal funds; 
	private BigDecimal equityFunds; 
	private BigDecimal totalFunds;
	private ArrayList<CPstock> portfolio;
	private String email;
	private String isAdmin;
	
	public Player(String userName, String password, String firstName, String lastName, String ID, String email) 
	{
		
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
		this.email = email;
		funds = new BigDecimal(10000);
		portfolio = new ArrayList<CPstock>();
		
	}
	//database return constructor
	public Player(String userName, String password, String firstName, String lastName, String ID, BigDecimal funds,ArrayList<CPstock> portfolio, String email, String isAdmin) 
	{	
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
		this.funds = funds;
		this.portfolio = portfolio;
		this.email = email;
		this.isAdmin = isAdmin;
		this.equityFunds = this.calcEquityFunds(this);
		this.totalFunds = this.calcTotalFunds(this);
	}

	public Player()
	{
		userName = "";
		password = "";
		firstName = "";
		lastName = "";
		email = "";
		ID = UUID.randomUUID().toString();
		funds = new BigDecimal(1000000);
		
		portfolio = new ArrayList<CPstock>();
	}

	//getters and setters
	public String getFirstName() 
	{
		return firstName;
	}


	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}


	public String getLastName() 
	{
		return lastName;
	}


	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}


	public String getID() 
	{
		return ID;
	}


	public void setID(String iD) 
	{
		ID = iD;
	}


	public ArrayList<CPstock> getPortfolio() 
	{
		return portfolio;
	}


	public void setPortfolio(ArrayList<CPstock> portfolio) 
	{
		this.portfolio = portfolio;
	}

	public void setFunds(BigDecimal funds) 
	{
		this.funds = funds;	
	}

	public BigDecimal getFunds() 
	{	
		return funds;
	}
	
	public BigDecimal getFundsRounded()
	{
		BigDecimal rounded = funds;
		rounded = rounded.setScale(2, RoundingMode.HALF_EVEN);
		return rounded;
	}
	
	public String getUserName() 
	{
		return userName;
	}

	public void setUserName(String userName) 
	{
		this.userName = userName;
	}

	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}

	public BigDecimal getEquityFunds() 
	{
		return equityFunds;
	}

	public void setEquityFunds(BigDecimal equityFunds) 
	{
		this.equityFunds = equityFunds;
	}

	public BigDecimal getTotalFunds() 
	{
		return totalFunds;
	}

	public void setTotalFunds(BigDecimal totalFunds) 
	{
		this.totalFunds = totalFunds;
	}

	public String getEmail() 
	{
		return email;
	}

	public void setEmail(String email) 
	{
		this.email = email;
	}
	
	public void setAdmin(String isAdmin)
	{
		this.isAdmin = isAdmin;
	}
	
	public String getAdmin()
	{
		return isAdmin;
	}
	
	/**
	 * Returns the amount of money a player has in stock
	 * @param player
	 * @return
	 */
	private BigDecimal calcEquityFunds(Player player) //calculates the players equity funds after purchase
	{
		BigDecimal equityFunds = new BigDecimal(0);
		
		for(CPstock stock: player.getPortfolio())
		{
			equityFunds = equityFunds.add(stock.getStock().getQuote().getAsk().multiply(new BigDecimal(stock.getQuantity()))); //current ask price * quantity of stock
		}
		
		return equityFunds;
	}
	/**
	 * returns the total amount of money a player has on the stock market in actual money and amount invested into stock
	 * @param player
	 */
	private BigDecimal calcTotalFunds(Player player) //calculates the players total amount of money based on current stock investments and money
	{
		BigDecimal totalFunds = new BigDecimal(0);
		
		totalFunds = player.getFunds().add(player.getEquityFunds());
		
		return totalFunds;
	}
	
	
}
