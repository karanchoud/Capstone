package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import enums.ErrorType;
import model.Database;
import model.Player;
import model.Validation;

/**
 * Loads Player information from the database and sends it to the user
 * 
 * On Post requests handles password change and deletion of account
 */
@SuppressWarnings("serial")
public class PlayerInformationServlet extends HttpServlet
{
	private Database database = Database.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String userName = request.getParameter("username");
		HttpSession session = request.getSession();
				
		if(Validation.redirectedToLogin(request, response, session))
		{
			return;
		}
		
		
		userName = (String) session.getAttribute("username");

		Player player = database.getPlayer(userName);

		if (player != null) 
		{
			request.setAttribute("playerInfo", player);

			//RequestDispatcher dispatcher = request.getRequestDispatcher("playerInfo.jsp");
			RequestDispatcher dispatcher = request.getRequestDispatcher("playerInformation.jsp");
			dispatcher.forward(request, response);
		} 
		else // this should never happen as the user name is supplied from the user's session variable
		{
			System.out.println("ERROR: player username does not exist. user not logged in?");
			
			session.setAttribute("errorMsg", ErrorType.InvalidPlayer);
			response.sendRedirect("login.jsp");
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{
		HttpSession session = request.getSession();
		
		String userName = (String) session.getAttribute("username");
		
		String playerInfoRequest  = request.getParameter("passwordChangeRequest");
		
		if(playerInfoRequest.equals("passwordChangeRequest"))
		{
			changePlayerPassword(request);
		}
		
		if(playerInfoRequest.equals("DELETEPLAYER"))
		{
			System.out.println("DELETING PLAYER: " + userName);
			database.RemovePlayer(userName);
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("playerInformation.jsp");
		dispatcher.forward(request, response);
		
		
	}
	
	public boolean changePlayerPassword(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		
		String userName = (String) session.getAttribute("username");
	
		String oldPass = request.getParameter("oldPass");
		String newPass = request.getParameter("newPass");
		String confirmPass = request.getParameter("confirmPass");
		
		Player player = database.getPlayer(userName);
		
		if(player != null)
		{
			if(oldPass.equals(player.getPassword()) && newPass.equals(confirmPass))
			{
				System.out.println("CHANGING PASSWORD FOR USER: " + userName);
				
				database.ResetPassword(userName, newPass);
				return true;
				
			}
			else
			{
				System.out.println("passwords do not match! line 110 playerInformation servlet");
				session.setAttribute("errorMsg", ErrorType.InvalidPass);
				
				return false;
			}
			
		}
		else
		{
			System.out.println("player was null inside changePlayerPassword()....");
			session.setAttribute("errorMsg", ErrorType.InvalidPlayer);
			return false;
		}		
	}
}
