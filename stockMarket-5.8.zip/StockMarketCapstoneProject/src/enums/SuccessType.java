package enums;

public enum SuccessType {
buySuccess,
sellSuccess,
bidSuccess,
amendSuccess,
amendDelete,
noMsg,
}
