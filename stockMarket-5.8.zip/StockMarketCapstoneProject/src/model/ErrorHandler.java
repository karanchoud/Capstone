package model;

import java.io.IOException;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;

import enums.ErrorType;
import enums.SuccessType;
/**
 * Class used to check for and print errors to the user,
 * Errors themselves are passed by each of the Servlets using the ErrorType enum
 * 
 */
public class ErrorHandler 
{
	private HttpSession session;
	private JspWriter out;
	
	public ErrorHandler(HttpSession session, JspWriter out)
	{
		this.session = session;
		this.out = out;
	}
	
	public void checkMessages()
	{
		try 
		{
			ErrorType error = (ErrorType) session.getAttribute("errorMsg");
			
			if(error == null)
			{
				error = ErrorType.noErrors;
			}
			
			if(error.equals(ErrorType.noErrors)) //if there's no errors check for success messages to print
			{
				checkSuccessMsg();
			}
			else
			{
				checkForErrors();
			}	
		} 
		catch (IOException e) 
		{	
			e.printStackTrace();
			System.out.println("checkMessages() has failed!");
		}
	}
	
	
	/**
	 * Checks for any errors that have been detected and prints them to the .jsp pages
	 * @throws IOException
	 */
	public void checkForErrors() throws IOException
	{
		ErrorType error = (ErrorType) session.getAttribute("errorMsg");
		
		if(error == null)
		{
			error = ErrorType.noErrors;
		}
		
		
		switch(error)
		{

		case noErrors:
				System.out.println("CASE: NO ERRORS");				
				
			break;

		case notLoggedIn:
			System.out.println("CASE: notLoggedIn");
			
			out.println("you need to login first");
			
			this.clearErrorMsg();

			break;

		case InvalidPass:
			System.out.println("CASE: InvalidPass");
			
			out.println("Invalid username or password!");
			this.clearErrorMsg();
			
			break;

		case InvalidQuantity:
			System.out.println("CASE: InvalidQuantity");
			
			out.println("Invalid Quantity entered!");
			this.clearErrorMsg();

			break;
		
		case InvalidPrice:
			System.out.println("CASE: InvalidPrice");
			
			out.println("Invalid Price entered");
			this.clearErrorMsg();

			break;
		
		case NotEnoughFunds:
			System.out.println("CASE: NotEnoughFunds");
			
			out.println("you dont have enough funds for this transaction");
			
			this.clearErrorMsg();

			break;

		case InvalidPlayer:
			System.out.println("CASE: InvalidPlayer");
			
			out.println("Player could not be found or is invalid");
			this.clearErrorMsg();

			break;
		case InvalidMarketOrder:
			System.out.println("CASE: Invalid Market Order");
			
			out.println("Market Order was Invalid please check Price and quantity are correct");
			this.clearErrorMsg();
			break;
			
		case InvalidBidOrder:
			System.out.println("CASE: Invalid Bid Order");
			
			out.println("Bid Order was Invalid please check Price and quantity are correct");
			this.clearErrorMsg();
			break;
			
		case InvalidAmendOrder:
			System.out.println("CASE: Invalid Amend Order");
			
			out.println("Bid Order was Invalid please check Price and quantity are correct");
			this.clearErrorMsg();
			
			break;
			
		case EmptyField:
			System.out.println("CASE: EmptyField");
			out.println("a field was left empty in the form please fill in all fields");
			
			this.clearErrorMsg();
			break;
			
		case UsernameTaken:
			System.out.println("CASE: UsernameTaken");
			out.println("username is unavailable");
			
			this.clearErrorMsg();
		break;
		
		case InvalidStock:
			System.out.println("CASE: InvalidStock");
			out.println("Stock form was empty or invalid");
			
			this.clearErrorMsg();
			break;
			
		case InvalidPasswordType:			
			System.out.println("CASE: InvalidPasswordType");
			out.println("Password must be at least 6 characters in length and contain atleast 1 Capital and 1 digit");
			
			this.clearErrorMsg();
			

		default:
			System.out.println("default case inside error handler something went wrong this should never happen");
			
			this.clearErrorMsg();
			break;
	
		}
	}
	
	/**
	 * Prints Confirmations to the user informing them if their request was successful when buying/selling etc
	 * @throws IOException
	 */
	public void checkSuccessMsg() throws IOException
	{
		SuccessType msg = (SuccessType) session.getAttribute("successMsg");
		
		if(msg == null)
		{
			msg = SuccessType.noMsg;
		}
		
		switch(msg)
		{
		case amendDelete:
			System.out.println("CASE: amendDelete");
			out.println("Your amend request was deleted");
			
			this.clearSuccessMsg();
			break;
			
		case amendSuccess:		
			System.out.println("CASE: amendSuccess");
			out.println("Your amend Order request was successful");
			
			this.clearSuccessMsg();
			break;
			
		case buySuccess:
			System.out.println("CASE: buySuccess");
			out.println("Purchase was successful");
			
			this.clearSuccessMsg();
			break;
			
		case noMsg:
			System.out.println("CASE: noMsg, no messages shown to the user");
			
			this.clearSuccessMsg();
			break;
			
		case sellSuccess:
			System.out.println("CASE: sellSuccess");
			out.println("Your stock was sold Successfully");
			
			this.clearSuccessMsg();
			break;
		case bidSuccess:
			System.out.println("CASE: bidSuccess");
			out.println("Your Bid Order has been added to the Order Book");
			
			this.clearSuccessMsg();
			break;
		default:
			System.out.println("CASE: default case something has gone wrong");
			
			this.clearSuccessMsg();
			break;
		
		}
				
	}
			
	
	/**
	 * Checks if the user has logged in should only be used for jsp side checks
	 * Validation has a static back end version
	 * @see Validation
	 * @return false if the user is not logged in
	 */
	public boolean checkForLogin()
	{
		if(session.getAttribute("username") != null)
		{
			
			String userName = (String) session.getAttribute("username");
			
			System.out.println("Logged in as:" + userName);
			return true;
		}
		else
		{
			System.out.println("No user logged in");
			return false;
		}
	}
	/**
	 * Sets the ErrorMsg variable back to noErrors after an error message has been printed
	 */
	private void clearErrorMsg()
	{
		session.setAttribute("errorMsg",ErrorType.noErrors);
	}
	/**
	 * sets the SuccessMsg variable back to printing no messages after a message has been printed to the user
	 */
	private void clearSuccessMsg()
	{
		session.setAttribute("successMsg",SuccessType.noMsg);
	}
	
	
	
	
}


