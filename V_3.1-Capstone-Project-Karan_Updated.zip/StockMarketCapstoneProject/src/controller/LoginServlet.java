package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Database;
import model.FAKEDatabase;
import model.Player;


public class LoginServlet extends HttpServlet
{
	
	private FAKEDatabase Fdatabase = FAKEDatabase.getInstance();
	
	private Database database = Database.getInstance();
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	 {
		 //Fdatabase.addPlayer(new Player());
		 
		 PrintWriter out=response.getWriter();
		 
		 if(request.getParameter("loginForm") != null)
			{
				System.out.println("login form is not null!");
				
				String username = request.getParameter("username");
				
				String password = request.getParameter("password");
				
				Player player = database.getPlayer(username);
				
				
				if(player != null && player.getPassword().equals(password)) //if the passwords match log the player in
				{
					HttpSession session = request.getSession();
					
					session.setAttribute("username", username);
					session.setAttribute("currentInputQuantity", 10);
					session.setAttribute("currentStockEntered", "MMJ.AX");
					//out.println("welcome: " + session.getAttribute("username"));
					
					RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp"); //return all info back to the client
					dispatcher.forward(request,response);
				}
				else
				{
					System.out.println("player object was null or password invalid");
					
					RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp"); //return all info back to the client
					dispatcher.forward(request,response);
				}
				
				
				/*
				if(Fdatabase.retrievePlayer(username).getPassword().equals(password))
				{
					HttpSession session = request.getSession();
					
					session.setAttribute("username", username);
					
					
					out.println("welcome" + username);
					
					RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp"); //return all info back to the client
					dispatcher.forward(req,resp);
				}
				else
				{
					//invalid password
				}
				*/
				
			}
	 }
}
