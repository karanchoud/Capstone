/**
 * 
 */
package model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import java.util.Random;

/**
 * @author Dan
 *
 */
public class Leaderboard 
{
	private ArrayList<Player> playerLeaderBoard;

	public Leaderboard() 
	{
		this.playerLeaderBoard = new ArrayList<Player>();
	}
	/**
	 * Prints out the top the leader board   
	 * @param playerNum - Specifies how many players to list starting from rank 1 if playerNum = 10 it will show the top 10 players
	 */
	public void ShowTopPlayers(int playerNum)
	{
		sortLeaderBoard();
		
		for(int i = 0; i < playerNum; i++)
		{
			System.out.println(playerLeaderBoard.get(i).getUserName() + " " + "totalFunds: $" + playerLeaderBoard.get(i).getTotalFunds());
		}
		//TODO list the top players on the leaderBoard
		//size of the list is from user input e.g playerNum = 10; list the top 10 players
	}
	
	public void ShowTopPlayers()
	{
		sortLeaderBoard();
		
		for(Player player: playerLeaderBoard)
		{
			System.out.println(player.getUserName() +" :$" + player.getTotalFunds());
		}
		
	
		
		//returns the entire leaderBoard
	}
	/**
	 * Adds a player to the Leader board and sorts the board again
	 * @param player
	 */
	public void addPlayerToLeaderBoard(Player player)
	{
		playerLeaderBoard.add(player);
		
		this.sortLeaderBoard();
	}
	
	public void removePlayerFromLeaderBoard(String playerID)
	{
		for(Player player: playerLeaderBoard)
		{
			if(player.getID().equals(playerID))
			{
				playerLeaderBoard.remove(player);
				
				System.out.println("Removed player: " + player.getUserName() + "ID: " + player.getID());
			}
			else
			{
				System.out.println("ERROR: player not found on leaderboard....");
			}
		}
		
		
		
		
	}
	
	
	private void sortLeaderBoard()
	{
		//sorts the leader board
		Collections.sort(playerLeaderBoard, new Comparator<Player>()
		{
			@Override
			public int compare(Player player1, Player player2) //overrides the compare method to compare LPlayer objects
			{
				//return player1.getTotalFunds().intValue() - player2.getTotalFunds().intValue(); //acending order
				
				if(player1.getTotalFunds().doubleValue() > player2.getTotalFunds().doubleValue()) //if player1 has more funds than player2
				{
					return -1;
				}
				
				if(player1.getTotalFunds().doubleValue() < player2.getTotalFunds().doubleValue()) //if player1 has less funds than player2
				{
					return 1;
				}
				else //the values are even
				{
					return 0;
				}				
			}
		});
		
	}
	
	public void generateTestPlayers(int playerNum) //generates a set of random players specified by playerNum with random amount of funds
	{
		for( int i = 0; i < playerNum; i ++)
		{
			Random rand = new Random();
			int randFunds = rand.nextInt(50000);
			Player player = new Player("username" + Integer.toString(i),"password","firstName" + Integer.toString(i), "lastName" + Integer.toString(i), "IDNUM" + Integer.toString(i),"email");
			
			player.setFunds(new BigDecimal(randFunds));
			
			player.setTotalFunds(new BigDecimal(randFunds));
			
			this.addPlayerToLeaderBoard(player);
			
			this.sortLeaderBoard();
		}
	}
		
	public ArrayList<Player> getPlayerLeaderBoard() 
	{
		return playerLeaderBoard;
	}

}
