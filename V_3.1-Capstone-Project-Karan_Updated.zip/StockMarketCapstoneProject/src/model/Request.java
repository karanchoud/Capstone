package model;

import java.io.IOException;
import java.math.BigDecimal;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

public class Request 
{
	private BigDecimal price;
	private String username;
	private String stockSymbol;
	private int quantity;
	private boolean completed; //used to check if the request is fully completed
	private boolean modified; //used to determine if a request was partially completed and needs to be updated on the database
	
	public Request(String username, String stockSymbol, int quantity, BigDecimal price)
	{
		this.username = username;
		this.stockSymbol = stockSymbol;
		this.quantity = quantity;
		this.price = price;
		completed = false;
		modified = false;
	}
	
	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	
	public String getUsername()
	{
		return username;
	}

	public void setUsername(String user) 
	{
		username = user;
	}
	
	public BigDecimal getPrice()
	{
		return price;
	}

	public void setPrice(BigDecimal price) 
	{
		this.price = price;
	}
	
	public String getSymbol()
	{
		return stockSymbol;
	}
	
	public void setSymbol(String newSymbol)
	{
		stockSymbol = newSymbol;
	}
	
	public Stock returnStock()
	{
		
		Stock stock = null;
		try {
			 stock = YahooFinance.get(stockSymbol);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return stock;
	}

	public boolean isCompleted()  //checks if the request has been completed ready for deletion
	{
		return completed;
	}

	public void setCompleted(boolean completed) 
	{
		this.completed = completed;
	}
	
	public boolean wasModified()
	{
		return modified;
	}
	
	public void setModified(boolean modified)
	{
		this.modified = modified;
	}
	
	
	
	
	
}
