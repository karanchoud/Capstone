package model;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class ProfitLoss {

	private BigDecimal percentChange;
	private BigDecimal valueChange;
	private int posNegFlag; 
	public ProfitLoss(BigDecimal valueChange, BigDecimal percentChange)
	{
		this.percentChange = percentChange;
		this.valueChange = valueChange;
		posNegFlag = 0;
	}
	
	public BigDecimal getPercentChange()
	{
		BigDecimal roundedPercent = percentChange.setScale(2, RoundingMode.HALF_EVEN);
		return roundedPercent;
	}
	
	public BigDecimal getValueChange()
	{
		BigDecimal roundedValue = valueChange.setScale(2, RoundingMode.HALF_EVEN);
		return roundedValue;
	}
	
	public void setPercentChange(BigDecimal percentChange)
	{
		this.percentChange = percentChange;
	}
	
	public void setValueChange(BigDecimal valueChange)
	{
		this.valueChange = valueChange;
	}
	
	public int getPosNeg()
	{
		return posNegFlag;
	}
	
	public void setPosNeg(int posNeg)
	{
		posNegFlag = posNeg;
	}
	
}
