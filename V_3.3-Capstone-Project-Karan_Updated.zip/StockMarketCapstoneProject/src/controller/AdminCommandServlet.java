package controller;

public class AdminCommandServlet 
{
	
}
