package controller;

import java.io.IOException;

import java.math.BigDecimal;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import enums.ErrorType;
import enums.OrderType;

import model.ShareMarket;
import model.Validation;
import yahoofinance.Stock;
/**
 * Servlet to handle the trading page in the application, Listening for all types of buying and selling requests
 * done by the Player
 */
@SuppressWarnings("serial")
public class StockOrderServlet extends HttpServlet 
{
	//private Database database = Database.getInstance();
	
	private ShareMarket shareMarket = new ShareMarket();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{
		
		HttpSession session = request.getSession();
		
		if(Validation.redirectedToLogin(request, response, session))
		{
			return;
		}
		
		 RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp"); //return all info back to the client
		 dispatcher.forward(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{
		
		HttpSession session = request.getSession();
		
		if(Validation.redirectedToLogin(request, response, session))
		{
			return;
		}
			
		if(handleSearchStockPass(request, response))
		{
			
		}
		else
		{
			handlePlayerOrder(request, response, session);
		}
	}
	/**
	 * Determines what Type of trade request the player sent
	 * 
	 * @param request
	 * @param response
	 * @return
	 * 
	 */
	public OrderType checkOrderType(HttpServletRequest request, HttpServletResponse response) 
	{
		if (request.getParameter("price").equals("market") && request.getParameter("OrderType").equals("buy")) 
		{
			return OrderType.marketOrder;
		}

		if (request.getParameter("price").equals("market") && request.getParameter("OrderType").equals("sell")) 
		{
			return OrderType.marketOrderSell;
		}

		if (request.getParameter("price").equals("limit") && request.getParameter("OrderType").equals("buy")) 
		{
			return OrderType.bidOrder;
		}

		if (request.getParameter("price").equals("limit") && request.getParameter("OrderType").equals("sell")) 
		{
			return OrderType.bidOrderSell;
		}

		return null;
	}
	
	
	public void handlePlayerOrder(HttpServletRequest request, HttpServletResponse response,HttpSession session)
	{
		OrderType requestType = checkOrderType(request, response); //returns the type of Order being placed (MarketOrder, MarketOrderSell, BidOrder or bidOrderSell)

		// get the form parameters
		String userName = (String) session.getAttribute("username");
		String stockSymbol = request.getParameter("stockSymbol");
		BigDecimal stockPrice;
		int quantity;

		String quantitySTR = request.getParameter("quantity");
		String StockPriceSTR = request.getParameter("limitValue");
		stockSymbol = stockSymbol.toUpperCase();
		if (!stockSymbol.endsWith(".AX")) 
		{
			stockSymbol = stockSymbol + ".AX";
		}
		
		switch (requestType) 
		{
		case marketOrder:
			
			//if(validMarketInput(stockSymbol, quantitySTR))
			if(Validation.validMarketInput(stockSymbol, quantitySTR))					
			{
				System.out.println("VALID MARKET ORDER");
				System.out.println("value of quantity: " + quantitySTR);
				quantity = Integer.parseInt(quantitySTR);
				stockPrice = shareMarket.getSingleStock(stockSymbol).getQuote().getAsk();
				shareMarket.marketOrder(userName, stockSymbol, stockPrice, quantity);
			}
			else
			{
				//session.setAttribute("errorMsg", "Your Stock or quantity was entered in-correctly, please enter valid stock and appropriate quantity");
				session.setAttribute("errorMsg", ErrorType.InvalidMarketOrder);
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("buy.jsp"); 
				try {
					dispatcher.forward(request, response);
				} catch (ServletException | IOException e) {
					
					e.printStackTrace();
				}
				return;
			}
			break;
		case marketOrderSell:
			
			//if(validMarketInput(stockSymbol, quantitySTR))
			if(Validation.validMarketInput(stockSymbol, quantitySTR))	
			{
				System.out.println("VALID MARKET ORDER SELL");
				quantity = Integer.parseInt(quantitySTR);
				stockPrice = shareMarket.getSingleStock(stockSymbol).getQuote().getAsk();
				shareMarket.marketOrderSell(userName, stockSymbol, stockPrice, quantity);
			}
			else
			{
				//session.setAttribute("errorMsg", "Your Stock or quantity was entered in-correctly, please enter valid stock and appropriate quantity");
				
				session.setAttribute("errorMsg", ErrorType.InvalidMarketOrder);
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("sell.jsp"); 
				try {
					dispatcher.forward(request, response);
				} catch (ServletException | IOException e) {
					
					e.printStackTrace();
				}
				return;
			}
			break;
		case bidOrder:
			
			//if(validInput(stockSymbol, StockPriceSTR, quantitySTR))
			if(Validation.validInput(stockSymbol, StockPriceSTR, quantitySTR))	
			{
				System.out.println("VALID BID ORDER");
				quantity = Integer.parseInt(quantitySTR);
				stockPrice = new BigDecimal(StockPriceSTR);
				shareMarket.bidOrder(userName, stockSymbol, stockPrice, quantity);
			}
			else
			{
				//session.setAttribute("errorMsg", "Your Stock, quantity or buying threshold was entered in-correctly, please enter valid stock and appropriate quantity and buying threshold");
				session.setAttribute("errorMsg", ErrorType.InvalidBidOrder);
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("buyLimit.jsp"); 
				try {
					dispatcher.forward(request, response);
				} catch (ServletException | IOException e) {
					
					e.printStackTrace();
				}
				return;
			}
			break;
		case bidOrderSell:
			
			//if(validInput(stockSymbol, StockPriceSTR, quantitySTR))
			if(Validation.validInput(stockSymbol, StockPriceSTR, quantitySTR))	
			{
				System.out.println("VALID BID ORDER SELL");
				quantity = Integer.parseInt(quantitySTR);
				stockPrice = new BigDecimal(StockPriceSTR);
				shareMarket.bidOrderSell(userName, stockSymbol, stockPrice,quantity);
			}
			else
			{
				//session.setAttribute("errorMsg", "Your Stock, quantity or buying threshold was entered in-correctly, please enter valid stock and appropriate quantity and buying threshold");
				
				session.setAttribute("errorMsg", ErrorType.InvalidBidOrder);
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("sellLimit.jsp"); 
				try {
					dispatcher.forward(request, response);
				} catch (ServletException | IOException e) {
					
					e.printStackTrace();
				}
				return;
			}
			break;
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp"); 
		try {
			dispatcher.forward(request, response);
		} catch (ServletException | IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
	public boolean handleSearchStockPass(HttpServletRequest request, HttpServletResponse response)
	{
		if(request.getParameter("buyLimitBtn") != null)
		{
			System.out.println("buy limit btn was pressed!");
			request.setAttribute("stockCode", request.getParameter("stockSymbol"));
			RequestDispatcher dispatcher = request.getRequestDispatcher("buyLimit.jsp"); 
			try 
			{
				dispatcher.forward(request, response);
			} catch (ServletException | IOException e) 
			{	
				e.printStackTrace();
			}
			return true;
		}

		if(request.getParameter("buyMarketBtn") != null)
		{
			System.out.println("buy market btn was pressed!");
			request.setAttribute("stockCode", request.getParameter("stockSymbol"));
			RequestDispatcher dispatcher = request.getRequestDispatcher("buy.jsp"); 
			try 
			{
				dispatcher.forward(request, response);
			} catch (ServletException | IOException e) 
			{	
				e.printStackTrace();
			}
			return true;
		}
		if(request.getParameter("sellLimitBtn") != null)
		{
			System.out.println("sell limit btn was pressed!");
			request.setAttribute("stockCode", request.getParameter("stockSymbol"));
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("sellLimit.jsp"); 
			try 
			{
				dispatcher.forward(request, response);
			} catch (ServletException | IOException e) 
			{	
				e.printStackTrace();
			}
			
			return true;
		}
		if(request.getParameter("sellMarketBtn") != null)
		{
			System.out.println("sell market btn was pressed!");
			request.setAttribute("stockCode", request.getParameter("stockSymbol"));
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("sell.jsp"); 
			
			try 
			{
				dispatcher.forward(request, response);
			} catch (ServletException | IOException e) 
			{	
				e.printStackTrace();
			}
			return true;
		}
		
		return false;
	}
}
