package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import enums.ErrorType;
import model.Database;
import model.FAKEDatabase;
import model.Player;
/**
 * Handles new Player Registration and directs users to the login page
 */
public class RegisterServlet extends HttpServlet
{
	private FAKEDatabase Fdatabase = FAKEDatabase.getInstance();
	
	private Database database = Database.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	 {
		if(request.getParameter("registerForm") != null)
		{
			HttpSession session = request.getSession();
			System.out.println("handled by register servlet!");
			
			String firstName = request.getParameter("name");
			
			String lastName = request.getParameter("lastname");
			
			String userName = request.getParameter("username");
			
			String password = request.getParameter("password");
			
			String email = request.getParameter("email");
			
			System.out.println(firstName);		
			System.out.println(lastName);
			System.out.println(userName);
			System.out.println(password);
			
			//Fdatabase.addPlayer(userName,password,firstName,lastName);
			
			//database.addPlayer(userName,password,firstName,lastName,email);
			int result = database.addPlayer(userName,password,firstName,lastName,email);
			if(result==1)
			{
				System.out.println("Player: " + userName + " registered to database successfully");
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request,response);
			}
			else
			{
				if(result == 0)
				{
					session.setAttribute("errorMsg", ErrorType.EmptyField);//"A field in the registration form was left empty");
				}
				if(result == -1)
				{
					session.setAttribute("errorMsg", ErrorType.InvalidPass);//"Password must be at least 6 characters in length");
				}
				if(result == -2)
				{
					session.setAttribute("errorMsg", ErrorType.InvalidPass);//"Password must contain at least one upper case character and one digit");
				}
				if(result == -3)
				{
					session.setAttribute("errorMsg", ErrorType.UsernameTaken);//"This username has been taken, please try again");
				}
				System.out.println("ERROR: database.addPlayer returned false. new player was not added to database");
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp");
				dispatcher.forward(request,response);
			}
			
			//response.sendRedirect("login.jsp");		
			
			
		}
		else
		{
			System.out.println("ERROR: RegisterServlet doPost: form was null");
		}
			
	}
}
