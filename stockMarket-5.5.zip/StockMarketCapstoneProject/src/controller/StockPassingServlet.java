package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Validation;
/**
 * Allows the stock symbol from a previous page to be passed to the next pages form.
 * 
 */
public class StockPassingServlet extends HttpServlet
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session = request.getSession();

		if (Validation.redirectedToLogin(request, response, session)) 
		{
			return;
		} 
		else 
		{
			this.HandleSearchStockPass(request, response);
		}

	}
	 
	 
	 public void HandleSearchStockPass(HttpServletRequest request, HttpServletResponse response)
		{
			if(request.getParameter("buyLimitBtn") != null)
			{
				System.out.println("buy limit btn was pressed!");
				request.setAttribute("stockCode", request.getParameter("stockSymbol"));
				RequestDispatcher dispatcher = request.getRequestDispatcher("buyLimit.jsp"); 
				try 
				{
					dispatcher.forward(request, response);
				} catch (ServletException | IOException e) 
				{	
					e.printStackTrace();
				}
				return;
			}

			if(request.getParameter("buyMarketBtn") != null)
			{
				System.out.println("buy market btn was pressed!");
				request.setAttribute("stockCode", request.getParameter("stockSymbol"));
				RequestDispatcher dispatcher = request.getRequestDispatcher("buy.jsp"); 
				try 
				{
					dispatcher.forward(request, response);
				} catch (ServletException | IOException e) 
				{	
					e.printStackTrace();
				}
				return;
			}
			if(request.getParameter("sellLimitBtn") != null)
			{
				System.out.println("sell limit btn was pressed!");
				request.setAttribute("stockCode", request.getParameter("stockSymbol"));
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("sellLimit.jsp"); 
				try 
				{
					dispatcher.forward(request, response);
				} catch (ServletException | IOException e) 
				{	
					e.printStackTrace();
				}
				
				return;
			}
			if(request.getParameter("sellMarketBtn") != null)
			{
				System.out.println("sell market btn was pressed!");
				request.setAttribute("stockCode", request.getParameter("stockSymbol"));
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("sell.jsp"); 
				
				try 
				{
					dispatcher.forward(request, response);
				} catch (ServletException | IOException e) 
				{	
					e.printStackTrace();
				}
				return;
			}
		}
}
