package model;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Runs the OrderBook checkOrders method to process all current trading requests in the stock market.
 */
public class OrderBookScheduler implements ServletContextListener
{
	private ScheduledExecutorService scheduler;
	
	private static final int TIME_INTERVAL = 1; //the amount of minutes between running the OrderBook again

	@Override
	public void contextInitialized(ServletContextEvent event) 
	{
		OrderBook orderBook = new OrderBook();
		
		scheduler = Executors.newSingleThreadScheduledExecutor();
		
		scheduler.scheduleAtFixedRate(orderBook,0,TIME_INTERVAL,TimeUnit.MINUTES);
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent event) 
	{
		System.out.println("shutting down orderBook()");
		
		scheduler.shutdownNow();		
	}

	
}
