package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import app.ServletMain;
import model.CPstock;
import model.Player;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

public class MarketOrderSellTest 
{
	
	
	private Player testPlayer;
	private ServletMain server;
	private Stock stock;
	private BigDecimal stockPrice;
	private int quantity = 1;
	
	BigDecimal startingFunds = new BigDecimal(10000);
	
	
	
	private BigDecimal expectedRemainingFunds;
	
	private CPstock expectedStock; //the expected stock in the first round of buying
	
	private CPstock expectedStock2; //the stock values of the second stock bought with a different symbol
	
	private Stock stock2; //stores the stock data from the third marketOrder
	
	private BigDecimal stockPrice2;
	

	@Before
	public void setUp() throws Exception 
	{
		testPlayer = new Player("username", "password", "firstName", "lastName","testID");
		
		server = new ServletMain();

		stock = YahooFinance.get("INTC");
		
		stockPrice = stock.getQuote().getAsk();
		
		expectedRemainingFunds = testPlayer.getFunds().add(stockPrice);
				
		server.getDatabase().addPlayer(testPlayer);
				
	}
	
	
	@Test
	public void test() 
	{
		assertTrue(server.getDatabase().getPlayerMap().size() == 1); //confirm theres a test player in the data base
		
		server.marketOrder(testPlayer.getID(), "INTC", stockPrice, quantity); //buy a stock
				
		assertTrue(testPlayer.getPortfolio().size() == 1); //confirm the stock exists in the player's port folio
		
		assertTrue(testPlayer.getFunds().doubleValue() < startingFunds.doubleValue()); //confirm funds updated
		
		server.marketOrderSell(testPlayer.getID(), "INTC", stockPrice, quantity); //sell  all the stock the player owns
		
		assertTrue(testPlayer.getPortfolio().size() == 0); //confirm the stock is gone
		
		assertTrue(testPlayer.getFunds().doubleValue() == startingFunds.doubleValue()); //confirm the funds updated
		
		
		server.marketOrder(testPlayer.getID(), "INTC", stockPrice, 2); //test the other case where your not selling all the stock you own
		
		server.marketOrderSell(testPlayer.getID(), "INTC", stockPrice, 1); //only sell 1 of the 2 stock you own
		
		assertTrue(testPlayer.getPortfolio().size() == 1); //confirm not all stock is gone
		
		assertTrue(testPlayer.getFunds().doubleValue() < startingFunds.doubleValue()); //confirm funds updated
		
		
		
		
		
			
	}

}
