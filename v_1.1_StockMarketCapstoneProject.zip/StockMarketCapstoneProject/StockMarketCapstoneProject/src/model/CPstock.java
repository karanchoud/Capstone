package model;

import java.util.ArrayList;

import yahoofinance.Stock;

public class CPstock 
{
	private Stock stock;
	private String stockSymbol;
	private int quantity;
	
	public CPstock(String stockSymbol, int quantity)
	{
		this.stockSymbol = stockSymbol;
		this.quantity = quantity;
	}
	
	public CPstock(Stock stock, int quantity)
	{
		this.stock = stock;
		this.quantity = quantity;		
	}
	
	
	public Stock getStock()
	{
		return stock;
	}
	
	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	
	
	
	
}
