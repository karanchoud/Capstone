package model;

import java.math.BigDecimal;
import java.util.ArrayList;


public class Player 
{
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	private String ID;
	private String email;
	private double funds;
	private BigDecimal equityFunds; //the amount of money invested in stock
	private BigDecimal totalFunds;
	private ArrayList<CPstock> portfolio;
	
	//TODO calculate the total funds via actual funds aswell as equityfunds
	
	public Player(String userName, String password, String firstName, String lastName, String ID, String email, double funds) 
	{
		
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
		this.email = email;
		this.funds = funds;
		portfolio = new ArrayList<CPstock>();
	}

	/*public Player(String firstName, String lastName,String ID,BigDecimal funds,ArrayList<CPstock> portfolio) 
	{
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
		this.funds = funds;
		this.portfolio = portfolio;
	}
	*/
	public void buyStock(String stockSSymbol, double price, int stockCount)
	{
		
	}
	
	public void sellStock()
	{
		
	}
	
	public void listCurrentStock()
	{
		
	}
	
	public void ammendOrder() //change 
	{
		
	}
	
	
	
	
	
	
	
	//getters and setters
	public String getFirstName() 
	{
		return firstName;
	}


	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}


	public String getLastName() 
	{
		return lastName;
	}


	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}


	public String getID() 
	{
		return ID;
	}


	public void setID(String iD) 
	{
		ID = iD;
	}


	public ArrayList<CPstock> getPortfolio() 
	{
		return portfolio;
	}


	public void setPortfolio(ArrayList<CPstock> portfolio) 
	{
		this.portfolio = portfolio;
	}

	public void setFunds(double funds) 
	{
		this.funds = funds;
		// TODO Auto-generated method stub
		
	}

	public double getFunds() {
		// TODO Auto-generated method stub
		return funds;
	}
	
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public BigDecimal getEquityFunds() {
		return equityFunds;
	}

	public void setEquityFunds(BigDecimal equityFunds) {
		this.equityFunds = equityFunds;
	}

	public BigDecimal getTotalFunds() {
		return totalFunds;
	}

	public void setTotalFunds(BigDecimal totalFunds) {
		this.totalFunds = totalFunds;
	}

	
	
}
