package unitTests;

import static org.junit.Assert.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

public class BuyBidTest
{	
	private RegisterServlet server;
	Player player;
	
	Stock stock;
	
	String user, user2, user3, correctPass, password, first, last, email;
	String invalidStockCode, stockCode, duplicateStockCode, unownedStockCode;
	BigDecimal stockPrice, staticStockPrice;
	BigDecimal expectedFunds;
	int quantity, negativeQuantity, zeroQuantity;
	ShareMarket sm;
	ArrayList<CPstock> portfolio;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "ruff";
		invalidStockCode = "notastockcode";
		stockCode = "MMJ.AX";
		duplicateStockCode = "MMJ.AX";
		unownedStockCode = "JBH.AX";
		user2 = "testPlayer2";
		user3 = "testPlayer3";
		password = "Password1";
		first = "Adrian";
		last = "Riscica";
		email = "s3383708@student.rmit.edu.au";
		db = Database.getInstance();
		sm = new ShareMarket();
		stockPrice = new BigDecimal(0.50);
		staticStockPrice = new BigDecimal(1);
		quantity = 1000;
		negativeQuantity = -1000;
		zeroQuantity = 0;
		
	}
	@Test
	public void TestIncorrectStockInput() 
	{
		
		//player = db.getPlayer(user);
		
		boolean result = sm.bidOrder(user, invalidStockCode, stockPrice, quantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestIncorrectQuantityNegativeInput() 
	{
		
		
		
		boolean result = sm.bidOrder(user, stockCode, stockPrice, negativeQuantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestIncorrectQuantityZeroInput() 
	{
		
		
		
		boolean result = sm.bidOrder(user, stockCode, stockPrice, zeroQuantity);
		assertEquals(false, result);
	}
	
	@Test
	public void TestStockBuyRequestDuplicity() 
	{
		boolean result = sm.bidOrder(user, duplicateStockCode, stockPrice, quantity);
		assertEquals(false, result);
	}
	
	@Test
	public void checkFundsNotEnough() throws IOException 
	{
		stockPrice = YahooFinance.get(stockCode).getQuote().getAsk();
		//this user only has 10 dollars in account, will attempt to make a buy which costs more than that

		boolean result = sm.bidOrder(user2, unownedStockCode, stockPrice, quantity);
		assertEquals(false, result);
	}
	
	@Test
	public void checkFundsEnough() throws IOException 
	{
		stockPrice = YahooFinance.get(stockCode).getQuote().getAsk();
		//this user only has 10 dollars in account, will attempt to make a buy which costs more than that

		boolean result = sm.bidOrder(user3, stockCode, stockPrice, quantity);
		assertEquals(true, result);
	}

}
