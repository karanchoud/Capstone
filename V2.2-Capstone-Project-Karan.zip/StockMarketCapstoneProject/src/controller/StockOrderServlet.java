package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import enums.OrderType;
import model.Database;
import model.ShareMarket;
import yahoofinance.Stock;
/**
 * Servlet to handle the trading page in the application, Listening for all types of buying and selling requests
 * done by the Player
 * @author Dan, s3388091
 *
 */
@SuppressWarnings("serial")
public class StockOrderServlet extends HttpServlet 
{
	private Database database = Database.getInstance();

	private ShareMarket shareMarket = new ShareMarket();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();

		if (session.getAttribute("username") == null) // check if the user is logged in												
		{
			System.out.println("not logged in Please login first!");
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp"); 
			dispatcher.forward(request, response);
		}
		else 
		{
			OrderType requestType = checkOrderType(request, response); //returns the type of Order being placed (MarketOrder, MarketOrderSell, BidOrder or bidOrderSell)

			// get the form parameters
			String userName = (String) session.getAttribute("username");
			String stockSymbol = request.getParameter("code");
			BigDecimal stockPrice;
			int quantity;

			String quantitySTR = request.getParameter("quantity");
			String StockPriceSTR = request.getParameter("limitValue");

			if (!stockSymbol.endsWith(".AX")) 
			{
				stockSymbol = stockSymbol + ".AX";
			}

			switch (requestType) 
			{
			case marketOrder:
				
				if(validMarketInput(stockSymbol, quantitySTR)) 
				{
					quantity = Integer.parseInt(quantitySTR);
					stockPrice = shareMarket.getSingleStock(stockSymbol).getQuote().getAsk();
					shareMarket.marketOrder(userName, stockSymbol, stockPrice, quantity);
				}
				break;
			case marketOrderSell:
				
				if(validMarketInput(stockSymbol, quantitySTR)) 
				{
					quantity = Integer.parseInt(quantitySTR);
					stockPrice = shareMarket.getSingleStock(stockSymbol).getQuote().getAsk();
					shareMarket.marketOrderSell(userName, stockSymbol, stockPrice, quantity);
				}
				break;
			case bidOrder:
				
				if(validInput(stockSymbol, StockPriceSTR, quantitySTR)) 
				{
					quantity = Integer.parseInt(quantitySTR);
					stockPrice = new BigDecimal(StockPriceSTR);
					shareMarket.bidOrder(userName, stockSymbol, stockPrice, quantity);
				}
				break;
			case bidOrderSell:
				
				if(validInput(stockSymbol, StockPriceSTR, quantitySTR)) 
				{
					quantity = Integer.parseInt(quantitySTR);
					stockPrice = new BigDecimal(StockPriceSTR);
					shareMarket.bidOrder(userName, stockSymbol, stockPrice,quantity);
				}
				break;
			}

			RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp"); 
			dispatcher.forward(request, response);
		}	
	}
	/**
	 * Determines what Type of trade request the player sent
	 * 
	 * @param request
	 * @param response
	 * @return
	 * 
	 */
	public OrderType checkOrderType(HttpServletRequest request, HttpServletResponse response) 
	{
		if (request.getParameter("price").equals("market") && request.getParameter("buy").equals("buy")) 
		{
			return OrderType.marketOrder;
		}

		if (request.getParameter("price").equals("market") && request.getParameter("buy").equals("sell")) 
		{
			return OrderType.marketOrderSell;
		}

		if (request.getParameter("price").equals("limit") && request.getParameter("buy").equals("buy")) 
		{
			return OrderType.bidOrder;
		}

		if (request.getParameter("price").equals("limit") && request.getParameter("buy").equals("sell")) 
		{
			return OrderType.bidOrderSell;
		}

		return null;
	}

	/**
	 * Returns True if all the form data sent by the player is valid and can be
	 * used to call a share market method
	 * 
	 * @param stockSymbol
	 * @param stockPriceSTR
	 * @param quantitySTR
	 * @return
	 * 
	 * True if Input is valid for a bidOrder or bidOrderSell
	 */
	public boolean validInput(String stockSymbol, String stockPriceSTR, String quantitySTR) 
	{
		return (stockIsValid(stockSymbol) && priceIsValid(stockPriceSTR) && quantityIsValid(quantitySTR));
	}
	
	/**
	 * Same as validInput except does not check for a price as MarketOrders do not use a price specified by the user
	 * 
	 * @param stockSymbol
	 * @param quantitySTR
	 * @return
	 * True if the input is valid for a arkerOrder or MarketOrderSell
	 */
	public boolean validMarketInput(String stockSymbol, String quantitySTR) 
	{
		return (stockIsValid(stockSymbol) && quantityIsValid(quantitySTR));
	}

	/**
	 * returns true if the quantity is a valid number
	 * 
	 * @param quantitySTR
	 * @return
	 */
	private boolean quantityIsValid(String quantitySTR) 
	{
		for (int i = 0; i < quantitySTR.length(); i++) 
		{
			if (Character.isDigit(quantitySTR.charAt(i))) 
			{
				continue;
			} 
			else 
			{
				System.out.println("quantitiy is not valid!");
				return false;
			}
		}

		System.out.println("quantity is valid");
		return true;
	}

	/**
	 * returns true if the price is valid
	 * 
	 * @param stockPriceSTR
	 * @return
	 */
	private boolean priceIsValid(String stockPriceSTR) 
	{
		try 
		{
			BigDecimal stockPrice = new BigDecimal(
					stockPriceSTR/* .replaceAll(",", "") */);
		} 
		catch (NumberFormatException e) 
		{
			e.printStackTrace();
			System.out.println("price invalid couldnt be converted to Big Decimal");
			return false;
		}

		System.out.println("price is valid");
		return true;
	}

	/**
	 * Returns true if the stock symbol passed is a valid AX stock
	 * 
	 * @param stockSymbol
	 * @return
	 */
	private boolean stockIsValid(String stockSymbol) 
	{
		Stock stock = shareMarket.getSingleStock(stockSymbol);

		if (stock != null && stock.getQuote().getAsk() != null) 
		{
			System.out.println("stock is valid");

			return true;
		} 
		else 
		{
			System.out.println("Stock is not valid!");
			return false;
		}
	}
}
