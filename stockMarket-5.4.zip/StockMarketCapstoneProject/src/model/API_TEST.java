package model;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;
import java.util.Map.Entry;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.histquotes.Interval;

//API interface down loaded from http://financequotes-api.com/


public class API_TEST 
{
	
	public static void main(String args[]) throws IOException
	{
		Stock stock = null;
		
		testStockRequest();
		
		testStockRequestHistory();
		
		 /*Stock tesla = YahooFinance.get("GOOGL", true);
		 tesla.print();
         System.out.println(tesla.getHistory());
		*/
		/*
		Calendar from = Calendar.getInstance();
		from.add(Calendar.YEAR, -1);
		
		Calendar to = Calendar.getInstance();
		
		
		
		
		stock = YahooFinance.get("GOOGL",from,to,Interval.DAILY);
		stock.print();
		
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		
		String date = format1.format(stock.getHistory().get(0).getDate().getTime());
		
		double highPrice = stock.getHistory().get(0).getHigh().intValue();
			
		System.out.println(date);
		
		System.out.println(highPrice);
		
		//System.out.println(format1.format(stock.getHistory().get(0).getDate().getTime()));
		
		/*System.out.println(stock.getQuote().getAsk());
		
		System.out.println(stock.getHistory().get(0).getDate().get(Calendar.YEAR));
		
		System.out.println(stock.getHistory().get(0).getDate().get(Calendar.DAY_OF_MONTH));
		
		System.out.println(stock.getHistory().get(0).getDate().get(Calendar.MONTH));
		*/
		
		
		/*
		Calendar from = Calendar.getInstance();
		from.add(Calendar.YEAR, -1);
		
		Calendar to = Calendar.getInstance();
		
		stock = YahooFinance.get("JBH.AX",from,to,Interval.WEEKLY);
		stock.print();
		System.out.println(stock.getHistory());
		*/
		/*String[] stockSymbols = {"INTC", "BABA", "TSLA", "AIR.PA", "YHOO"};
		
		Map<String,Stock> stockMap; //map to store stock info
		
		stockMap = YahooFinance.get(stockSymbols); //API request for stock info
		
		printStockmap(stockMap); //print stock map
		*/
		
		
		
			
	}
	
	public static void printStockmap(Map<String,Stock> stockMap) //prints all stock info from a map
	{
		for(Entry<String,Stock> mapEntry : stockMap.entrySet()) //loop through each entry in the map
		{
			//String currentKey = mapEntry.getKey();
			//System.out.println(currentKey);
			Stock currentStock = mapEntry.getValue(); //assigns the map key's value to a stock object
						
			currentStock.print(); //print the current stock's info
		}
	}
	
	public static void testStockRequest()
	{
		Stock stock = null;
		try 
		{
			stock = YahooFinance.get("GOOGL");	
			stock.print();
			
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}
	
	public static void testStockRequestHistory()
	{
		Calendar from = Calendar.getInstance();
		from.add(Calendar.YEAR, -1);
		
		Calendar to = Calendar.getInstance();
		
		
		
		
		Stock stock;
		try {
			stock = YahooFinance.get("GOOGL",from,to,Interval.DAILY);
			
			stock.print();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
		
	
	
	
}
