package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Database;
import model.Player;


@SuppressWarnings("serial")
public class PlayerInformationServlet extends HttpServlet
{
	private Database database = Database.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String userName = request.getParameter("username");

		Player player = database.getPlayer(userName);

		if (player != null) 
		{
			request.setAttribute("playerInfo", player);

			RequestDispatcher dispatcher = request.getRequestDispatcher("playerinformation.jsp");
			dispatcher.forward(request, response);
		} 
		else // this should never happen as the user name is supplied from the user's session variable
		{
			System.out.println("ERROR: player username does not exist");
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{
		//doGet(request, response);
		
		String playerInfoRequest = "";
		playerInfoRequest = request.getParameter("playerInfoRequest");
		
		String userName = request.getParameter("username");
		
		
		if(playerInfoRequest.equals("DELETE"))
		{
			System.out.println("DELETING PLAYER: " + userName);
			database.RemovePlayer(userName);
		}
		
		if(playerInfoRequest.equals("CHANGEPASS"))
		{
			System.out.println("changing password for username: " + userName);
			
			//TODO call database method here
			
		}
		else
		{
			System.out.println("request was invalid or empty");	
			RequestDispatcher dispatcher = request.getRequestDispatcher("playerinformation.jsp");
			dispatcher.forward(request, response);
		}
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
		
		
	}
}
