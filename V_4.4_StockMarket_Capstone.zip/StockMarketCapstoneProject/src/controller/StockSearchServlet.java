package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.ShareMarket;
import yahoofinance.Stock;

@SuppressWarnings("serial")
public class StockSearchServlet extends HttpServlet
{
	ShareMarket shareMarket = new ShareMarket();
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		String stockSymbol = request.getParameter("stockSymbol");
		
		stockSymbol = stockSymbol.toUpperCase();
		HttpSession session = request.getSession(true);
		
		if (!stockSymbol.endsWith(".AX")) 
		{
			stockSymbol = stockSymbol + ".AX";
		}
		
		if(stockIsValid(stockSymbol))
		{
			Stock stock = shareMarket.getSingleStock(stockSymbol);
			
			request.setAttribute("stockRequest", stock);
			session.setAttribute("stockRequest", stock);
			
			session.setAttribute("stockID", stockSymbol);
			session.setAttribute("stockValue", stock.getQuote().getAsk());
			RequestDispatcher dispatcher = request.getRequestDispatcher("searchStock.jsp");
			dispatcher.forward(request, response);	
		}
		else
		{
			System.out.println("ERROR: invalid stock cannot return stock information!");
			RequestDispatcher dispatcher = request.getRequestDispatcher("searchStock.jsp");
			dispatcher.forward(request, response);
			return;
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		HttpSession session = request.getSession(true);
		System.out.println("in here");
		if(request.getParameter("buy") != null && request.getParameter("buy").equals("buy"))
		{
			if (session.getAttribute("username") == null) // check if the user is logged in												
			{
				System.out.println("not logged in Please login first!");
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("loginAlt.jsp"); 
				dispatcher.forward(request, response);
			}
			else 
			{
			System.out.println("buy stock button was pressed!");
			request.setAttribute("stockCode", session.getAttribute("stockID"));
			request.setAttribute("stockValue", session.getAttribute("stockValue"));
			System.out.println(request.getAttribute("stockValue"));
			RequestDispatcher dispatcher = request.getRequestDispatcher("buy.jsp");
			dispatcher.forward(request, response);
			return;
			}
		}
		if(request.getParameter("sell") != null && request.getParameter("sell").equals("sell"))
		{
			if (session.getAttribute("username") == null) // check if the user is logged in												
			{
				System.out.println("not logged in Please login first!");
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("loginAlt.jsp"); 
				dispatcher.forward(request, response);
			}
			else 
			{
			System.out.println("sell stock button was pressed!");
			request.setAttribute("stockCode", session.getAttribute("stockID"));
			request.setAttribute("stockValue", session.getAttribute("stockValue"));
			System.out.println(request.getAttribute("stockValue"));
			RequestDispatcher dispatcher = request.getRequestDispatcher("sell.jsp");
			dispatcher.forward(request, response);
			return;
			}
		}
		doGet(request,response);
	}
	
	
	
	private boolean stockIsValid(String stockSymbol) 
	{
		Stock stock = shareMarket.getSingleStock(stockSymbol);

		if (stock != null && stock.getQuote().getAsk() != null) //if the stock has an ask price quote and is not null its a valid .AX stock
		{
			System.out.println("stock is valid");
			
			return true;
		} 
		else 
		{
			System.out.println("Stock is not valid!");
			return false;
		}
	}

}
