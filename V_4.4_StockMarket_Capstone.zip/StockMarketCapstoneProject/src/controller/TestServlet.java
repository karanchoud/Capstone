package controller;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import enums.OrderType;
import enums.adminType;
import model.Admin;
import model.Database;
import model.Player;




@SuppressWarnings("serial")
public class TestServlet extends HttpServlet
{
	Database database = Database.getInstance();
	String fundsStr;
	Player player;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		
		 HttpSession session = request.getSession();
		 
		 database.ResetPassword("ruff", "Pass1");
		// adminType order = checkOrderType(request, response);
		 
		 String userName = (String) session.getAttribute("username");
		 //Player adminPlayer = database.getPlayer(userName);
		 //Admin admin = new Admin(adminPlayer.getUserName(), adminPlayer.getPassword(), adminPlayer.getFirstName(), adminPlayer.getLastName(), adminPlayer.getID(), adminPlayer.getFunds(), adminPlayer.getPortfolio(), adminPlayer.getEmail());
	}

	 	 
}
