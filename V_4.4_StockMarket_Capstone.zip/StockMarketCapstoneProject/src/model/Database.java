package model;

import java.io.IOException;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.UUID;



import yahoofinance.Stock;
import yahoofinance.YahooFinance;

//import javax.resource.cci.ResultSet;

public class Database //used to store player IDs, current stock data owned by players, and player account info


{
	
	private boolean connectionSuccess = false; //variable used to eliminate race condition from database
	Connection conn; //connection object used for attempting connections to the external database
	
	private static Database database = new Database(); //static database object initialisation
	
	/**
	 * Returns the instance of the data
	 * @return database instance is returned
	 */
	public static Database getInstance()
	{
		
		return database;
	}
	
	/**
	 * opens a database connection to the external database allows for requests to be made 
	 * @return boolean indicating success in opening a connection or a failure to do so
	 */
	
	public synchronized boolean openConnection()
	{
		connectionSuccess = true; //set database connection is use
		try
		{
		/*attempt to establish a connection to the database using the jdbc database driver. 
		 * many parameters are supplied including database location and name, as well as database username and password for access
		 */
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://166.62.28.123:3306/stockmarketDB", "stockMarketAdmin", "passs");
		

		} catch (SQLException ex) {
		    // handle any error occurances 
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		    //de-set database connection in use
		    connectionSuccess = false;
		    return false;
		} 
		catch (ClassNotFoundException e) {
			//error occurance, jdbc driver is not found/installed
			System.out.println("Where is your MySQL JDBC Driver?");
			e.printStackTrace();
			//de-set database connection in use
			connectionSuccess = false;
			return false;
		}

		System.out.println("connection established!");
		
		
		return true;
	}
	
	/**
	 * will close the connection to the external database for good practice purposes. otherwise, database connection will 
	 * time out after pro-longed periods of not being used
	 * @return a boolean indicating a success in closing the connection or a failure to do so
	 */
	public synchronized boolean closeConnection()
	{
		try
		{
		connectionSuccess = false;
		conn.close();
		return true;
		} catch (SQLException ex) {
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		    connectionSuccess = false;
		    return false;
		} 
		
	}
	
	/**
	 * getter method for race condition variable
	 * @return the race condition variable
	 */
	public synchronized boolean getConnectionSuccess()
	{
		return connectionSuccess;
	}
	
	/**
	 * setter for the race condition variable
	 * @param value - returns the race condition variable which is of type boolean
	 */
	public synchronized void setConnectionSuccess(boolean value)
	{
		connectionSuccess = value;
	}
	
	/**
	 * method to create and add a new player to the external database based on the parameter inputs passed in by the user
	 * @param user - the unique identifier for the user
	 * @param pass - the password to provide security for the users account and match the unique username identifier
	 * @param first - the first name of the user
	 * @param last - the last name of the user
	 * @param email - the e-mail address of the user
	 * @return returns a boolean value indicating a success (true) if the creation and storage of the player was successful
	 * otherwise a failure (false) indicating an issue with saving the player.
	 */
	//String user, String pass, String first, String last, String email
	public boolean addPlayer(String user, String pass, String first, String last, String email)
	{
		
		String isAdmin = "no"; //variable indicating admin status
		//set the race condition variable
		database.openConnection();
		/*
		 * validation checks
		 */
		
		
		boolean upperCaseCheck = false, digitCheck = false; //validation checking flags
		//first check for any nulls in any of the passed parameters
		if(user == "" | user == null | pass == "" | pass == null | first == "" | first == null | last == "" | last == null
				| email == "" | email == null)
		{
			//release database connection if null value detected
			database.closeConnection();
			return false;
		}
		
		//validation to ensure password is at least 6 characters long
		if(pass.length() < 6)
		{
			//release database connection if password less then 6 characters long
			database.closeConnection();
			return false;
		}
		
		//move through password char by char identifying at least one upper case char and at least one digit 
		for(int i=0; i< pass.length(); i++)
		{
			//if uppercase char is found
			if(Character.isUpperCase(pass.charAt(i)))
			{
				//set upper case char found flag to true
				upperCaseCheck = true;
			}
			//if digit is found
			else if(Character.isDigit(pass.charAt(i)))
			{
				//set digit found flag to true
				digitCheck = true;
			}
		
		}
		
		//if both flags were not set to true then the password is not valid
		if(digitCheck != true | upperCaseCheck != true)
		{
			//release database connection
			database.closeConnection();
			return false;
		}
		
		 //password validation is okay, create statement object and begin preparing to add a record to database
		 Statement st;
		 int duplicateUser = 1;  // detect duplicate user flag set to 1
		
			 try {
				 	st = conn.createStatement();
			
				 	//create a random UUID to attach to user (another form of identification)
				 	String id = UUID.randomUUID().toString();
				 	
				 	//create MYSQL Query to retrieve any players with the same username
				 	String searchQuery = "SELECT * FROM Player WHERE username='"+user+"'";
				 	
				 	//execute query
				 	ResultSet rs =  st.executeQuery(searchQuery);
				 	
				 	//if a record is returned then the id entered is already taken
				 	if(rs.next())
				 		{
				 			//set duplicateUser flag to 0
				 			duplicateUser = 0;
				 		}
				 if(duplicateUser == 0)
				 	{
					 	//duplicate found in username, so release the database connection and return a false
					 	database.closeConnection();
					 	return false; 
				 	}
				 
			
				
			//if no record found with inputted username, create query to add a player to the database
			String realQuery = "INSERT INTO Player VALUES('"+id+"', '"+user+"', '"+pass+"', '"+first+"', '"+last+"', '"+email+"', 1000000, '"+isAdmin+"')";
			//execute query
			st.executeUpdate(realQuery);
			
		
			
		} catch (SQLException e) {
			// error occured
			e.printStackTrace();
			
		}
		
		 //release database connection
	     database.closeConnection();
		 return true;
	}
	
	
	/**
	 * method responsible for authenticating a players details at login stage
	 * @param passedInputUser - inputted username
	 * @param passedInputPass - inputted password
	 * @return a boolean indicating the success (true) or fail (false) of the authentication when logging in
	 */
	public boolean authPlayer(String passedInputUser, String passedInputPass)
	{
		//check if database in use
		while(database.getConnectionSuccess() == true);
		//open database connection
		database.openConnection();
		
		
		 Statement st;
		 String dbPass;
		
			 try {
				 	//create the statement object to perform database queries
				 	st = conn.createStatement();
			
				 	//assign input pass and user to new variables
				 	String inputUser = passedInputUser; 
				 	String inputPass = passedInputPass;
				 	
				 	//check for any null and empty inputs 
				 	if(inputUser == null | inputUser == "" | inputPass == null | inputPass == "")
				 	{
				 		//release database connection
				 		database.closeConnection();
				 		return false;
				 	}
				 	
				 	//construct query to identify if username exists in the database
				 	String searchQuery = "SELECT * FROM Player WHERE username='"+inputUser+"'"; // ***playerID needs to change to Username column***
				 	//execute query
				 	ResultSet rs =  st.executeQuery(searchQuery);
				 	
				 	//if a user exists, check for matching passwords between the database record of the users
				 	//password and the password input
				 	if(rs.next())
				 		{
				 			//result found, valid username exists, now check for pass
				 			
				 			dbPass = rs.getString(3); //dbPassword
				 			
				 			//if input password matches database stored password
				 			if(dbPass.equals(inputPass))
				 				{
				 					//password match
				 					//release database connection
				 					database.closeConnection();
				 					return true;
				 				}	 			
				 		}
				 	//passwords do not match
				 	else
				 		{
				 			System.out.println("No user with that username returning false");
				 			//release database connection
				 			database.closeConnection();
				 			return false;
				 		}
			
		} catch (SQLException e) {
			// catch any issues when attempting the database query
			e.printStackTrace();
			
		}
		
		 System.out.println("password didnt match but user does exist, returning false");
		 //release the database connection
		 database.closeConnection();
		 return false;
	}
	
	
	/**
	 * method to retrieve players details
	 * @param inputUser - a username is supplied and the users details are extracted
	 * @return an object of type Player containing all player details including portfolio items
	 */
	public Player getPlayer(String inputUser)
	{
		//if database connection is in use
		while(database.getConnectionSuccess() == true);
		//open database connection
		database.openConnection();
		
		 //declare and init the statement and player object
		 Statement st;
		 Player loadPlayer = null;
		 
		
			 try {
				 	st = conn.createStatement();

				 	//construct a query to retrieve a player from the external database
				 	String getPlayerQuery = "SELECT * FROM Player WHERE username='"+inputUser+"'"; 
				 	//execute query
				 	ResultSet rs =  st.executeQuery(getPlayerQuery);
				 	//if player exists and is returned
				 	if(rs.next())
				 	{
				 		System.out.println("extracting player details");
				 		//extract all player details based on the specific column id's set in the database table design 
				 	 
				 		String id = rs.getString(1); // user UUID
				 		String username = rs.getString(2); //username
				 		String password = rs.getString(3); // password
				 		String firstName = rs.getString(4); //firstname
				 		String lastName = rs.getString(5); //lastname
				 		String email = rs.getString(6); //email address
				 		BigDecimal funds = new BigDecimal(rs.getDouble(7)); //player liquid funds
				 		String isAdmin = rs.getString(8); //adminStatus
				 		
				 		/*init an arraylist to retrieve the portfolio objects held by this player 
				 		 * which are retrieved by another method (getPlayerPortfolio)
				 		 */
				 		
				 		ArrayList<CPstock> portfolio = getPlayerPortfolio(username);
				 		//init the player object feeding all useful parameters to construct the player object
				 		loadPlayer = new Player(username, password, firstName, lastName, id,funds,portfolio,email, isAdmin);
				 		
				 	}
				 //release database connection
				 database.closeConnection();
				 return loadPlayer;
		} catch (SQLException e) {
			//catch any errors in performing database queries
			e.printStackTrace();
			
		}
		
		
		
		//release database connection and return a null object if no player exists (could not be found)
		database.closeConnection();
		return loadPlayer;
	}
	
	
	private ArrayList<CPstock> getPlayerPortfolio(String username)
	{
		ArrayList<CPstock >portfolio = new ArrayList<CPstock>();
		Statement st;
		
		
			 try {
				 	st = conn.createStatement();
			
				 	//here we authenticate 
				 	
				 	
				 	String getPortfolioQuery = "SELECT * FROM Portfolio WHERE username='"+username+"'"; // ***playerID needs to change to Username column***
				 	ResultSet rs =  st.executeQuery(getPortfolioQuery);
				 	
				 	while(rs.next())
				 	{
				 		//extract portfolio record data here and build portfolio arraylist
				 		String recordUsername = rs.getString(2);
				 		String stockSymbol = rs.getString(3);
				 		int stockQuantity = rs.getInt(4);
				 		double investment = rs.getDouble(5);
				 		BigDecimal convertInvestment = new BigDecimal(investment);
				 		
				 		Stock stock = null;
				 		stock = YahooFinance.get(stockSymbol);
				 		
				 		CPstock portfolioItem = new CPstock(stock, stockQuantity, convertInvestment);
				 		System.out.println("quantity: " + portfolioItem.getQuantity());
				 		portfolio.add(portfolioItem);
				 	}
				
				 	if(rs.first() == false)
				 	{
				 		System.out.println("No portfolio objects found");
				 		//portfolio = null; i've commented this out because i want an empty list in the case that theres no objects to rebuild a complete player object
				 		return portfolio;
				 	}
				 	
				 return portfolio;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		} catch (IOException eIO)
			 {
			eIO.printStackTrace();
			
			 }
		
		
		
		return portfolio;
	}
	
	
	public boolean addToPlayerPortfolio(String username, Stock stock, int quantity, BigDecimal baseInvestment)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		
		if(stock.isValid()!=true | quantity <= 0 | baseInvestment.compareTo(BigDecimal.ZERO) <=0)
		{
			database.closeConnection();
			return false;
		}
		
		
		Statement st;	
		 try {
			 	st = conn.createStatement();
		
			 	
			 	String stockSym = stock.getSymbol();
			 	
			 	String getPortfolioQuery = "SELECT * FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'"; // ***playerID needs to change to Username column***
			 	ResultSet rs = st.executeQuery(getPortfolioQuery);
			 	
			 	if(rs.next())
			 	{
			 		//record exists therefore, add quantity to portfolio item
			 		int dbQuantity = rs.getInt(4);
			 		double dbBaseInvest = rs.getDouble(5);
			 		double convertedAccBaseInvestment = baseInvestment.doubleValue() + dbBaseInvest;
			 		
			 		quantity = dbQuantity + quantity;
			 		String amendPortfolioQuery = "UPDATE Portfolio SET stockquantity='"+quantity+"' WHERE username='"+username+"' AND "
			 				+ "stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(amendPortfolioQuery);
			 		amendPortfolioQuery = "UPDATE Portfolio SET baseinvestment='"+convertedAccBaseInvestment+"' WHERE "
			 				+ "username='"+username+"' AND "
			 				+ "stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(amendPortfolioQuery);
			 		database.closeConnection();
			 		return true;
			 	}
			 	else
			 	{
			 		System.out.println("quantity in database: " + quantity);
			 		double convertedBaseInvest = baseInvestment.doubleValue();
			 		String addPortfolioQuery = "INSERT INTO Portfolio(username, stocksymbol, stockquantity, baseinvestment) "
			 				+ "VALUES('"+username+"', '"+stockSym+"', '"+quantity+"', '"+convertedBaseInvest+"')"; 						// ***playerID needs to change to Username column***
			 		st.executeUpdate(addPortfolioQuery);
			 		database.closeConnection();
			 		return true;
			 	}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
		database.closeConnection();
		return false;
	}
	
	
	public boolean removeFromPlayerPortfolio(String username, Stock stock, int quantity)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		if(stock.isValid()!=true | quantity <= 0)
		{
			database.closeConnection();
			return false;
		}
		
		Statement st;
		
		
		 try {
			 	st = conn.createStatement();
			 	System.out.println("in remove portfolio now: " + username + " " + stock.getSymbol() + " " + quantity);
			 	//here we authenticate 
			 	String stockSym = stock.getSymbol();
			 	
			 	String getPortfolioQuery = "SELECT * FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'"; // ***playerID needs to change to Username column***
			 	ResultSet rs = st.executeQuery(getPortfolioQuery);
			 	
			 	if(rs.next())
			 	{
			 		int dbQuantity = rs.getInt(4);
			 		double dbBaseInvestment = rs.getDouble(5);
			 		System.out.println("db base investment: " + dbBaseInvestment);
			 		if(quantity < dbQuantity)
			 		{
			 			double quantityDouble = quantity;
			 			double dbQuantityDouble = dbQuantity;
			 			double sellPercent = (double)(quantityDouble/dbQuantityDouble);
			 			System.out.println("percentage: " + sellPercent);
			 			quantity = dbQuantity - quantity;
			 			
			 			double convertedBaseReduction = dbBaseInvestment * sellPercent;
			 			System.out.println("converted Base Reduction: " + convertedBaseReduction);
			 			System.out.println(dbQuantity);
			 			convertedBaseReduction = (dbBaseInvestment - convertedBaseReduction);
			 			System.out.println("reduction: " + convertedBaseReduction);
			 			String amendQuery = "UPDATE Portfolio SET stockquantity='"+quantity+"' WHERE username='"+username+"' AND "
			 					+ "stocksymbol='"+stockSym+"'";
			 			st.executeUpdate(amendQuery);
			 			amendQuery = "UPDATE Portfolio SET baseinvestment='"+convertedBaseReduction+"' WHERE username='"+username+"' AND "
			 					+ "stocksymbol='"+stockSym+"'";
			 			st.executeUpdate(amendQuery);
			 			database.closeConnection();
			 			return true; // update successful
			 		}
			 		else if(quantity == dbQuantity)
			 		{
			 			//delete record here
			 			System.out.println("printing here");
			 			String deleteQuery = "DELETE FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'";
			 			st.executeUpdate(deleteQuery);
			 			database.closeConnection();
			 			return true;
			 		}
			 		
			 	}
			 	else
			 	{
			 		System.out.println("invalid negative input");
			 		database.closeConnection();
			 		return false; // no record found
			 	}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
	
		database.closeConnection();
		return false;
		
	}
	
	
	public boolean buyUpdate(Player player, String stockSym, int quantity, BigDecimal stockPrice)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		
		if(quantity <= 0 | stockPrice.compareTo(BigDecimal.ZERO) <=0)
		{
			database.closeConnection();
			return false;
		}
		
		
		
		 try {
			 Stock stock = YahooFinance.get(stockSym);
			 if(stock.isValid()!=true)
			 {
				 database.closeConnection();
				 return false;
			 }
			 	st = conn.createStatement();
	
			 	//here we authenticate 
			 	
			 	
			 	//String modifyFundsQuery = "UPDATE Player SET funds='"+player.getFunds()+"' WHERE username='"+player.getUserName()+"'";
			 	//st.executeUpdate(modifyFundsQuery);
			 	
			 	String searchQuery = "SELECT * FROM BuyRequests WHERE username='"+player.getUserName()+"' AND stocksymbol='"+stockSym+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	
			 	
			 	if(rs.next())
			 		{
			 		//if record exists...
			 		System.out.println("modifying buy request record");
			 		String alterQuantityQuery = "UPDATE BuyRequests SET quantity='"+quantity+"' WHERE "
			 				+ "username='"+player.getUserName()+"' AND stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(alterQuantityQuery);
			 		
			 		String alterPurchasePriceQuery = "UPDATE BuyRequests SET purchaseprice='"+stockPrice.doubleValue()+"' WHERE "
			 				+ "username='"+player.getUserName()+"' AND stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(alterPurchasePriceQuery);
			 		database.closeConnection();
			 		return true;
			 		}
			 	//if record does not exist...
			 	String addBuyQuery = "INSERT INTO BuyRequests(username, stocksymbol, quantity, purchaseprice) VALUES('"+player.getUserName()+"', '"+stockSym+"', '"+quantity+"', '"+stockPrice.doubleValue()+"')";
			 	st.executeUpdate(addBuyQuery);
			 	database.closeConnection();
			 	return true;

		 	} catch (SQLException | IOException e) {
		 		// TODO Auto-generated catch block
		 		e.printStackTrace();
		 		System.out.println("hello world");
		 	}
		 database.closeConnection();
		 return false;
	}
	
	public BigDecimal getOldBuyPrice(String username, String stockSymbol)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		
		if(username == "" | username == null)
		{
			database.closeConnection();
			return null;
		}

		Statement st;
		
		try {
			 Stock stock = YahooFinance.get(stockSymbol);
			 if(stock.isValid()!=true)
			 {
				 database.closeConnection();
				 return null;
			 }
			
		 	st = conn.createStatement();
	
		 	
		 	
		 	String searchQuery = "SELECT * FROM BuyRequests WHERE username='"+username+"' AND "
		 			+ "stocksymbol='"+stockSymbol+"'";
		 	
		 	ResultSet rs =  st.executeQuery(searchQuery);
		 	if(rs.next())
		 		{
		 			//found record
		 			Double purchasePrice = rs.getDouble(5);
		 			int quantity = rs.getInt(4);
		 			System.out.println(purchasePrice);
		 			BigDecimal value = new BigDecimal(purchasePrice, MathContext.DECIMAL64);
		 			BigDecimal finalValue = value.multiply(new BigDecimal(quantity));
		 			database.closeConnection();
		 			return finalValue;
		 			
		 		}
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		}
		database.closeConnection();
		return null;
	}
	

	public boolean checkStockDuplicity(String username, String stockSymbol)
 	{
			while(database.getConnectionSuccess() == true);
			database.openConnection();
			
			if(username == "" | username == null)
			{
				database.closeConnection();
				return true;
			}
			
			Statement st;
			
			try {
				 Stock stock = YahooFinance.get(stockSymbol);
				 if(stock.isValid()!=true)
				 {
					 database.closeConnection();
					 return true;
				 }
				
				
			 	st = conn.createStatement();
			 	String searchQuery = "SELECT * FROM BuyRequests WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
			 	
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	if(rs.next())
			 		{
			 			//found record
			 			System.out.println("record found");
			 			database.closeConnection();
			 			return true;
			 		}
		
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("hello world");
			}
		database.closeConnection();
 		return false;
		
 	}

	
	public boolean checkStockDuplicitySell(String username, String stockSymbol)
 	{
		while(database.getConnectionSuccess() == true);
			database.openConnection();
			
			if(username == "" | username == null)
			{
				database.closeConnection();
				return true;
			}
			
			Statement st;
			
			try {
				
				Stock stock = YahooFinance.get(stockSymbol);
				 if(stock.isValid()!=true)
				 {
					 database.closeConnection();
					 return true;
				 }
				
			 	st = conn.createStatement();
			 	String searchQuery = "SELECT * FROM SellRequests WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
			 	
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	if(rs.next())
			 		{
			 			//found record
			 			System.out.println("record found");
			 			database.closeConnection();
			 			return true;
			 		}
		
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
		database.closeConnection();
 		return false;
		
 	}
	
	
	public boolean checkStockQuantity(String username, String stockSymbol, int quantity)
 	{
		while(database.getConnectionSuccess() == true);
			database.openConnection();
			Statement st;
			
			if(username == "" | username == null | quantity <=0)
			{
				database.closeConnection();
				return false;
			}
			
			
			try {
				
				Stock stock = YahooFinance.get(stockSymbol);
				 if(stock.isValid()!=true)
				 {
					 database.closeConnection();
					 return false;
				 }
				
			 	st = conn.createStatement();
		
			 	
			 	
			 	String searchQuery = "SELECT * FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
			 	
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	if(rs.next())
			 		{
			 			//found record
			 			System.out.println("record found");
			 			
			 			if((rs.getInt(4) - quantity) < 0)
			 			{
			 				database.closeConnection();
			 				return false;
			 			}
			 			database.closeConnection();
			 			return true;
			 		}
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("hello world");
			}
		database.closeConnection();
 		return false;
		
 	}
	
	
	public boolean sellUpdate(Player player, String stockSym, int quantity, BigDecimal sellPrice)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		
		if(quantity <= 0 | sellPrice.compareTo(BigDecimal.ZERO) <=0)
		{
			database.closeConnection();
			return false;
		}
		
		 try {
			 Stock stock = YahooFinance.get(stockSym);
			 if(stock.isValid()!=true)
			 {
				 database.closeConnection();
				 return false;
			 }
			 st = conn.createStatement();
		

			 	String searchQuery = "SELECT * FROM SellRequests WHERE username='"+player.getUserName()+"' AND "
			 			+ "stocksymbol='"+stockSym+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	if(rs.next())
			 		{
			 		//if record exists...
			 		System.out.println("modifying sell request record");
			 		String query = "UPDATE SellRequests SET quantity='"+quantity+"' WHERE username='"+player.getUserName()+"' AND "
			 				+ "stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(query);
			 		query = "UPDATE SellRequests SET sellprice='"+sellPrice.doubleValue()+"' WHERE username='"+player.getUserName()+"' AND "
			 				+ "stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(query);
			 		database.closeConnection();
			 		return true;
			 		}
			 	//if record does not exist...
			 	String addSellQuery = "INSERT INTO SellRequests(username, stocksymbol, quantity, sellprice) "
			 			+ "VALUES('"+player.getUserName()+"', '"+stockSym+"', '"+quantity+"', '"+sellPrice.doubleValue()+"')";
			 	st.executeUpdate(addSellQuery);
			 	database.closeConnection();
			 	return true;

		 	} catch (SQLException | IOException e) {
		 		// TODO Auto-generated catch block
		 		e.printStackTrace();
		 		System.out.println("hello world");
		 	}
		 database.closeConnection();
		 return false;
	}
	
	
	public LinkedList<Request> getAllBuyRequests()
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		LinkedList<Request> buyRequestHolder = new LinkedList<Request>();
		
		Statement st;
		
		try {
		 	st = conn.createStatement();
		 	String searchQuery = "SELECT * FROM BuyRequests";
		 	
		 	ResultSet rs =  st.executeQuery(searchQuery);
		 	while(rs.next())
		 		{
		 			//found record
		 			//add to arraylist in here
		 		
		 			String username = rs.getString(2);
		 			String stockSymbol = rs.getString(3);
		 			int quantity = rs.getInt(4);
		 			Double price = rs.getDouble(5);
		 		
		 			BigDecimal convertedPrice = new BigDecimal(price);
		 			
		 			Request newRequest = new Request(username, stockSymbol, quantity, convertedPrice);
		 			buyRequestHolder.add(newRequest);
		 		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		if(buyRequestHolder.size() == 0)
		{
			System.out.println("no buy requests at all");
			database.closeConnection();
			return buyRequestHolder;
		}
		database.closeConnection();
		return buyRequestHolder;
	}
	
	public LinkedList<Request> getAllSellRequests()
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		
		LinkedList<Request> sellRequestHolder = new LinkedList<Request>();
		
		Statement st;
		
		try {
		 	st = conn.createStatement();
		 	String searchQuery = "SELECT * FROM SellRequests";
		 	
		 	ResultSet rs =  st.executeQuery(searchQuery);
		 	while(rs.next())
		 		{
		 			//found record
		 			//add to arraylist in here
		 		
		 			String username = rs.getString(2);
		 			String stockSymbol = rs.getString(3);
		 			int quantity = rs.getInt(4);
		 			Double price = rs.getDouble(5);
		 		
		 			BigDecimal convertedPrice = new BigDecimal(price);
		 			
		 			Request newRequest = new Request(username, stockSymbol, quantity, convertedPrice);
		 			sellRequestHolder.add(newRequest);
		 		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		if(sellRequestHolder.size() == 0)
		{
			System.out.println("no sell requests at all");
			database.closeConnection();
			return sellRequestHolder;
		}
		database.closeConnection();
		return sellRequestHolder;
	}
	
	public ArrayList<Request> getPlayerBuyRequests(String username)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		ArrayList<Request> buyRequests = new ArrayList<Request>();
	
		
		
		
		 try {
			
			
			 	st = conn.createStatement();
	
			 	//here we authenticate 
			 	
			 	
			 	//String modifyFundsQuery = "UPDATE Player SET funds='"+player.getFunds()+"' WHERE username='"+player.getUserName()+"'";
			 	//st.executeUpdate(modifyFundsQuery);
			 	
			 	String searchQuery = "SELECT * FROM BuyRequests WHERE username='"+username+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	
			 	while(rs.next())
			 	{
			 		String dbUsername = rs.getString(2);
			 		String stockSymbol = rs.getString(3);
			 		int dbQuantity = rs.getInt(4);
			 		double dbPrice = rs.getDouble(5);
			 		BigDecimal convertPrice = new BigDecimal(dbPrice);
			 		Request req = new Request(dbUsername, stockSymbol, dbQuantity, convertPrice);
			 		buyRequests.add(req);
			 	}
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
database.closeConnection();
	return buyRequests;
	
	}
	
	
	public ArrayList<Request> getPlayerSellRequests(String username)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		ArrayList<Request> sellRequests = new ArrayList<Request>();
	
		
		
		
		 try {
			
			
			 	st = conn.createStatement();
	
			 	//here we authenticate 
			 	
			 	
			 	//String modifyFundsQuery = "UPDATE Player SET funds='"+player.getFunds()+"' WHERE username='"+player.getUserName()+"'";
			 	//st.executeUpdate(modifyFundsQuery);
			 	
			 	String searchQuery = "SELECT * FROM SellRequests WHERE username='"+username+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	
			 	while(rs.next())
			 	{
			 		String dbUsername = rs.getString(2);
			 		String stockSymbol = rs.getString(3);
			 		int dbQuantity = rs.getInt(4);
			 		double dbPrice = rs.getDouble(5);
			 		BigDecimal convertPrice = new BigDecimal(dbPrice);
			 		Request req = new Request(dbUsername, stockSymbol, dbQuantity, convertPrice);
			 		sellRequests.add(req);
			 	}
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
	database.closeConnection();
	return sellRequests;
	
	}
	
	public boolean deletePlayerBuyRequest(Request req)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
	
		 try {

			 	st = conn.createStatement();
			 	String deleteQuery = "DELETE FROM BuyRequests WHERE username='"+req.getUsername()+"' AND stocksymbol='"+req.getSymbol()+"'";
			 	st.executeUpdate(deleteQuery);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
	
	}
	
	public boolean deletePlayerSellRequest(Request req)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		
		 try {

			 	st = conn.createStatement();
			 	String deleteQuery = "DELETE FROM SellRequests WHERE username='"+req.getUsername()+"' AND stocksymbol='"+req.getSymbol()+"'";
			 	st.executeUpdate(deleteQuery);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
	
	}
	
	public boolean addPlayerFunds(String username, BigDecimal funds)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		
		 try {
			 	st = conn.createStatement();
			 	System.out.println("in add player funds: username - " + username);
			 	String searchQuery = "SELECT * FROM Player WHERE username='"+username+"'";
			 	
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 
			 	if(!rs.next())
			 	{
			 		System.out.println("user does not exist, returning falssee");
			 		return false;
			 	}
			 	
			 	
			 		double dbFunds = rs.getDouble(7);
			 		double newDbFunds = dbFunds + funds.doubleValue();
			 		String modifyQuery = "UPDATE Player SET funds='"+newDbFunds+"' WHERE username='"+username+"'";
				 	st.executeUpdate(modifyQuery);
				 	System.out.println("funds have been added");
			 	
			
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
		
		
		
		
	}
	
	public boolean deductPlayerFunds(String username, BigDecimal funds)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		
		 try {
			 	st = conn.createStatement();
			 	String searchQuery = "SELECT * FROM Player WHERE username='"+username+"'";
			 	
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 
			 	if(rs.next())
			 	{
			 		double dbFunds = rs.getDouble(7);
			 		double newDbFunds = dbFunds - funds.doubleValue();
			 		String modifyQuery = "UPDATE Player SET funds='"+newDbFunds+"' WHERE username='"+username+"'";
				 	st.executeUpdate(modifyQuery);
			 	}
			 	
			 
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
		
		
		
		
	}
	
	public boolean ModifyPlayerFunds(String username, BigDecimal funds)
	{
		
		System.out.println(database.getConnectionSuccess());
		while(database.getConnectionSuccess() == true);
		System.out.println("opening connection");
		database.openConnection();
		
		Statement st;
		
		 try {
			 	st = conn.createStatement();
			 	
			 	String searchQuery = "SELECT * FROM Player WHERE username='"+username+"'";
			 	ResultSet rs = st.executeQuery(searchQuery);
			 	if(!rs.next())
			 	{
			 		System.out.println("user does not exist, returning false");
			 		return false;
			 	}
			 	
			 	
			 		String modifyQuery = "UPDATE Player SET funds='"+funds.doubleValue()+"' WHERE username='"+username+"'";
				 	st.executeUpdate(modifyQuery);
			 	
			 	
			 
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
		
		
		
		
	}
	
	public boolean saveSellHistory(Request req, String date, String time)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		String finalDate = date + " " + time;
		 try {

			 	st = conn.createStatement();
			 	String addHistoryQuery = "INSERT INTO SellHistory(username, stocksymbol, stockquantity, stockprice, selldate) VALUES('"+req.getUsername()+"', '"+req.getSymbol()+"', '"+req.getQuantity()+"', '"+req.getPrice().doubleValue()+"', '"+finalDate+"')";
			 	
			 	st.executeUpdate(addHistoryQuery);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
		 database.closeConnection();
		return true;
	}
	
	public boolean saveBuyHistory(Request req, String date, String time)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		String finalDate = date + " " + time;
		 try {

			 	st = conn.createStatement();
			 	String addHistoryQuery = "INSERT INTO PurchaseHistory(username, stocksymbol, stockquantity, stockprice, purchasedate) VALUES('"+req.getUsername()+"', '"+req.getSymbol()+"', '"+req.getQuantity()+"', '"+req.getPrice().doubleValue()+"', '"+finalDate+"')";
			 	
			 	st.executeUpdate(addHistoryQuery);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
		 database.closeConnection();
		return true;
	}
	
	public ArrayList<History> getPlayerBuyHistory(String username) throws IOException
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		ArrayList<History> buyHistory = new ArrayList<History>();
	
		
		
		
		 try {
			
			
			 	st = conn.createStatement();
	
			 	//here we authenticate 
			 	
			 	
			 	//String modifyFundsQuery = "UPDATE Player SET funds='"+player.getFunds()+"' WHERE username='"+player.getUserName()+"'";
			 	//st.executeUpdate(modifyFundsQuery);
			 	
			 	String searchQuery = "SELECT * FROM PurchaseHistory WHERE username='"+username+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	
			 	while(rs.next())
			 	{
			 		//get stock info
			 		//Stock stock = rs.getString(3);
			 		String stockSymbol = rs.getString(3);
			 		int quantity = rs.getInt(4);
			 		double price = rs.getDouble(5);
			 		BigDecimal convertPrice = new BigDecimal(price);
			 		String dateTime = rs.getString(6);
			 		History history = new History(username, stockSymbol, quantity, convertPrice, dateTime);
			 		
			 		buyHistory.add(history);
			 		
			 	}
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
database.closeConnection();
	return buyHistory;
	
	}
	
	public ArrayList<History> getPlayerSellHistory(String username) throws IOException
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		ArrayList<History> sellHistory = new ArrayList<History>();
	
		
		
		
		 try {
			
			
			 	st = conn.createStatement();
	
			 	//here we authenticate 
			 	
			 	
			 	//String modifyFundsQuery = "UPDATE Player SET funds='"+player.getFunds()+"' WHERE username='"+player.getUserName()+"'";
			 	//st.executeUpdate(modifyFundsQuery);
			 	
			 	String searchQuery = "SELECT * FROM SellHistory WHERE username='"+username+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	
			 	while(rs.next())
			 	{
			 		String stockSymbol = rs.getString(3);
			 		int quantity = rs.getInt(4);
			 		double price = rs.getDouble(5);
			 		BigDecimal convertPrice = new BigDecimal(price);
			 		String dateTime = rs.getString(6);
			 		History history = new History(username, stockSymbol, quantity, convertPrice, dateTime);
			 		sellHistory.add(history);
			 		
			 	}
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
database.closeConnection();
	return sellHistory;
	
	}
	
	public boolean RemovePlayer(String username)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		
		
		
		 try {
			 	st = conn.createStatement();
			 	String searchQuery = "SELECT * FROM Player WHERE username='"+username+"'";
			 	ResultSet rs = st.executeQuery(searchQuery);
			 	if(!rs.next())
			 	{
			 		return false;
			 	}
			 	
			 	
			 	String deleteQuery = "DELETE FROM BuyRequests WHERE username='"+username+"'";
				 	st.executeUpdate(deleteQuery);
				 	deleteQuery = "DELETE FROM Portfolio WHERE username='"+username+"'";
				 	st.executeUpdate(deleteQuery);
				 	deleteQuery = "DELETE FROM PurchaseHistory WHERE username='"+username+"'";
				 	st.executeUpdate(deleteQuery);
				 	deleteQuery = "DELETE FROM SellHistory WHERE username='"+username+"'";
				 	st.executeUpdate(deleteQuery);
				 	deleteQuery = "DELETE FROM SellRequests WHERE username='"+username+"'";
				 	st.executeUpdate(deleteQuery);
				 	deleteQuery = "DELETE FROM Player WHERE username='"+username+"'";
				 	st.executeUpdate(deleteQuery);
				 	
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
		
		
		
		
	}
	
	public boolean ResetPlayer(Player player)
	{
		while(database.getConnectionSuccess() == true)
		{
			System.out.println(database.getConnectionSuccess());
		}
		System.out.println("we here");
	
		
		if(player !=null)
		{
		
			 	if(database.RemovePlayer(player.getUserName()))
			 	{
			 		if(database.addPlayer(player.getUserName(), player.getPassword(), player.getFirstName(), player.getLastName(), player.getEmail()))
			 		{
			 			database.closeConnection();
			 			return true;
			 		}
			 		
			 	}
			 	
		}	 		
			 	
	
	database.closeConnection();
	return false;
		
		
		
		
	}
	
	
	public ArrayList<Player> getAllPlayers()
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		ArrayList<Player> allPlayers = new ArrayList<Player>();
		Player loadPlayer;
		Statement st;
		
		try {
		 	st = conn.createStatement();
		 	String searchQuery = "SELECT * FROM Player";
		 	
		 	ResultSet rs =  st.executeQuery(searchQuery);
		 	while(rs.next())
		 		{
		 		System.out.println("extracting player details");
		 		String id = rs.getString(1);
		 		String username = rs.getString(2);
		 		String password = rs.getString(3);
		 		String firstName = rs.getString(4);
		 		String lastName = rs.getString(5);
		 		String email = rs.getString(6);
		 		BigDecimal funds = new BigDecimal(rs.getDouble(7));
		 		String isAdmin = rs.getString(8);
		 		System.out.println("player name: " + username);
		 		ArrayList<CPstock> portfolio = getPlayerPortfolio(username);
		 		
		 		loadPlayer = new Player(username, password, firstName, lastName, id,funds,portfolio,email, isAdmin);
		 		allPlayers.add(loadPlayer);
		 		//loadPlayer.setPortfolio(database.getPlayerPortfolio(username));
		 		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		if(allPlayers.size() == 0)
		{
			System.out.println("no players at all");
			database.closeConnection();
			return allPlayers;
		}
		database.closeConnection();
		return allPlayers;
	}
	
	public Request getPlayerSellRequest(String username, String stockSymbol)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		//Request req = new Request(username, stockSymbol, 0, new BigDecimal(0));
		//TODO
		
		try {
		 	st = conn.createStatement();
		 	String searchQuery = "SELECT * FROM SellRequests WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
		 	
		 	ResultSet rs =  st.executeQuery(searchQuery);
		 	if(rs.next())
		 		{
		 		//found sell request record
		 		String user = rs.getString(2);
		 		String stockSym = rs.getString(3);
		 		int quantity = rs.getInt(4);
		 		double price = rs.getDouble(5);
		 		BigDecimal convPrice = new BigDecimal(price);
		 		Request req = new Request(user, stockSym, quantity, convPrice);
		 		database.closeConnection();
		 		return req;
		 		} 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		database.closeConnection();
		return null;
	}
	
	public boolean ResetPassword(String username, String newPassword)
	{
		
		System.out.println("we here");
		//database.openConnection();
		System.out.println("what about here");
		//database.setConnectionSuccess(false);
		Player player = database.getPlayer(username);
		Statement st;
		
		if(player !=null)
		{
			String amendPasswordQuery = "UPDATE Player SET password='"+newPassword+"' WHERE username='"+username+"'";
			try {
				while(database.getConnectionSuccess() == true);
				database.openConnection();
				st = conn.createStatement();
				st.executeUpdate(amendPasswordQuery);
				database.closeConnection();
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 		
			 database.closeConnection();
			 return false;
			 		
			 	
		}	 		
			 	
	
	database.closeConnection();
	return false;
		
		
		
		
	}
	
	
	public boolean RemoveBuyRequest(String username, String stockSymbol)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		
		
		
		 try {
			 	st = conn.createStatement();
			 	String searchQuery = "SELECT * FROM BuyRequests WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
			 	ResultSet rs = st.executeQuery(searchQuery);
			 	if(!rs.next())
			 	{
			 		return false;
			 	}
			 	
			 	
			 	String deleteQuery = "DELETE FROM BuyRequests WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
				 	st.executeUpdate(deleteQuery);
				 	
				 	
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
		
		
		
		
	}
	
	public boolean RemoveSellRequest(String username, String stockSymbol)
	{
		while(database.getConnectionSuccess() == true);
		database.openConnection();
		Statement st;
		
		
		
		 try {
			 	st = conn.createStatement();
			 	String searchQuery = "SELECT * FROM SellRequests WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
			 	ResultSet rs = st.executeQuery(searchQuery);
			 	if(!rs.next())
			 	{
			 		return false;
			 	}
			 	
			 	
			 	String deleteQuery = "DELETE FROM SellRequests WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
				 	st.executeUpdate(deleteQuery);
				 	
				 	
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
		
		
		
		
	}
	
}
