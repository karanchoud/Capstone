/**
 * 
 */
package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;

import org.junit.Test;

import model.CPstock;
import model.Player;
import model.ShareMarket;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

/**
 * @author Dan
 *
 */
public class MarketOrderTest 
{
	
	private Player testPlayer;
	private Stock stock;
	private BigDecimal stockPrice;
	private int quantity = 1;
	
	private BigDecimal expectedRemainingFunds;
	
	private CPstock expectedStock; //the expected stock in the first round of buying
	
	private CPstock expectedStock2; //the stock values of the second stock bought with a different symbol
	
	private Stock stock2; //stores the stock data from the third marketOrder
	
	private BigDecimal stockPrice2;
	
	private ShareMarket market;
	
	@Before
	public void setUp() throws Exception 
	{	
		testPlayer = new Player("username", "password", "firstName", "lastName","testID","email");
		//server = new ServletMain();
		market = new ShareMarket();
			
		stock = YahooFinance.get("YHOO");
		
		stock2 = YahooFinance.get("INTC");
		
		stockPrice = stock.getQuote().getAsk();
		
		stockPrice2 = stock2.getQuote().getAsk();
		
		expectedRemainingFunds = testPlayer.getFunds().subtract(stockPrice).subtract(market.getPurchaseBrokerFee(stockPrice));
		
		expectedStock = new CPstock(stock,1);
		
		expectedStock2 = new CPstock(stock2,1);
				
		//server.getDatabase().addPlayer(testPlayer);
		market.getTESTDatabase().addPlayer(testPlayer);		
	}
	
	@Test
	public void testFirstPurchaseExists()
	{
		market.marketOrder(testPlayer.getUserName(), "YHOO", stockPrice, quantity);
		
		assertTrue("player should have 1 stock in their portfolio",testPlayer.getPortfolio().size() == 1);
		
		cleanup();
	}
	
	@Test
	public void testFundsUpdated()
	{
		market.marketOrder(testPlayer.getUserName(), "YHOO", stockPrice, quantity);
		
		assertEquals(expectedRemainingFunds,testPlayer.getFunds());
		
		cleanup();
	}
	
	@Test
	public void testPurhasedStockValues()
	{
		market.marketOrder(testPlayer.getUserName(), "YHOO", stockPrice, quantity);
		
		assertEquals(expectedStock.getStock().getQuote().getAsk(), testPlayer.getPortfolio().get(0).getStock().getQuote().getAsk());
		
		assertEquals(expectedStock.getStock().getName(), testPlayer.getPortfolio().get(0).getStock().getName());
		
		assertEquals(expectedStock.getQuantity(),testPlayer.getPortfolio().get(0).getQuantity());
		
		cleanup();
		
	}
	@Test
	public void testSecondPurchaseSameSymbol()
	{
		market.marketOrder(testPlayer.getUserName(), "YHOO", stockPrice, quantity);
		
		market.marketOrder(testPlayer.getUserName(), "YHOO", stockPrice, quantity); //purchase a second stock with the same symbol
		
		assertEquals(expectedStock.getQuantity() + 1,testPlayer.getPortfolio().get(0).getQuantity());
		
		cleanup();
	}
	@Test
	public void testPurchaseTwoDifferentSymbol()
	{
		market.marketOrder(testPlayer.getUserName(), "YHOO", stockPrice, quantity);
		
		market.marketOrder(testPlayer.getUserName(), "INTC", stockPrice2, quantity); //purchase a third stock with a different symbol
		
		assertEquals(expectedStock2.getQuantity(),testPlayer.getPortfolio().get(1).getQuantity());
		
		assertEquals(expectedStock2.getStock().getSymbol(),testPlayer.getPortfolio().get(1).getStock().getSymbol());
		
		cleanup();
	}
	
	
	
	public void cleanup() //removes the testing player to ready to be recreated and added to the database for the next test
	{
		market.getTESTDatabase().removePlayer(testPlayer);
	}
	
}





















