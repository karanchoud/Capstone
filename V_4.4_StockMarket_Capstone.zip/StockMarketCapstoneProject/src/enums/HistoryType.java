package enums;

public enum HistoryType {
	buyHistory,sellHistory
}
