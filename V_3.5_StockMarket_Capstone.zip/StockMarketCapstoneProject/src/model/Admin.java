package model;

import java.math.BigDecimal;

import yahoofinance.Stock;

public class Admin extends Player 
{
	private Database dataBase = Database.getInstance();
	
	private ShareMarket shareMarket = new ShareMarket();
	
	public Admin()
	{
		
		
	}
	
	public boolean amendFunds(String userName, BigDecimal funds)
	{
		boolean flag = false;
		Player currentPlayer = dataBase.getPlayer(userName);
		if(currentPlayer !=null)
		{
		flag = dataBase.addPlayerFunds(currentPlayer.getUserName(), funds);
		currentPlayer.setFunds(funds);
		}
		return flag;
	}
	
	public void removePlayer(String userName)
	{
		//dataBase.removePlayer(String userName);
	}
	
	public void removePlayerStock(String userName, String stockSymbol, int quantity)
	{
		Player currentPlayer = Database.getInstance().getPlayer(userName);
		
		Stock stock = shareMarket.getSingleStock(stockSymbol);
		
		shareMarket.removeStock(currentPlayer, stock, quantity,new BigDecimal(0));
	}
	
	public void addPlayerStock(String userName, String stockSymbol, int quantity)
	{
		Player currentPlayer = Database.getInstance().getPlayer(userName);
		
		Stock stock = shareMarket.getSingleStock(stockSymbol);
		
		shareMarket.addStock(currentPlayer, stock, quantity,new BigDecimal(0));
	}
	
	public boolean resetPlayer(String userName)
	{
		Player resettingPlayer = dataBase.getPlayer(userName);
		boolean flag = dataBase.ResetPlayer(resettingPlayer);
		return flag;
	}
	
}
