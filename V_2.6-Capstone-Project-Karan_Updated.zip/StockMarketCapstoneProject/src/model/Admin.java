package model;

import java.math.BigDecimal;

import yahoofinance.Stock;

public class Admin extends Player 
{
	private Database dataBase = Database.getInstance();
	
	private ShareMarket shareMarket = new ShareMarket();
	
	public Admin()
	{
		super();
	}
	
	public void ammendFunds(String userName, BigDecimal funds)
	{
		Player currentPlayer = dataBase.getPlayer(userName);
		
		currentPlayer.setFunds(funds);
	}
	
	public void removePlayer(String userName)
	{
		//dataBase.removePlayer(String userName);
	}
	
	public void removePlayerStock(String userName, String stockSymbol, int quantity)
	{
		Player currentPlayer = Database.getInstance().getPlayer(userName);
		
		Stock stock = shareMarket.getSingleStock(stockSymbol);
		
		shareMarket.removeStock(currentPlayer, stock, quantity,new BigDecimal(0));
	}
	
	public void addPlayerStock(String userName, String stockSymbol, int quantity)
	{
		Player currentPlayer = Database.getInstance().getPlayer(userName);
		
		Stock stock = shareMarket.getSingleStock(stockSymbol);
		
		shareMarket.addStock(currentPlayer, stock, quantity,new BigDecimal(0));
	}
	
}
