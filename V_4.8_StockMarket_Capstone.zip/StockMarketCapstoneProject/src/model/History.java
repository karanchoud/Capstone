package model;

import java.math.BigDecimal;
import java.math.RoundingMode;

import yahoofinance.Stock;


/** This class is responsible for modeling objects for past buy and sell transactions. objects hold all relevant data
 * regarding a single purchase or sale made by a player (market buy/sell and bid buy/sell (with players) **/

public class History 
{
	private String username, stockSymbol, dateTime;
	//private Stock stock;
	private int quantity;
	private BigDecimal stockPrice;
	
	/** Constructor **/
	public History(String username, String stockSymbol, int quantity, BigDecimal stockPrice, String dateTime)
	{
		this.username = username;
		this.stockSymbol = stockSymbol;
		this.quantity = quantity;
		this.stockPrice = stockPrice;
		this.dateTime = dateTime;
	}
		
	/** getter - gets the quantity bought/sold of the history object
	 * @return int - quantity */
	public int getQuantity()
	{
		return quantity;
	}

	/** setter - sets the quantity bought/sold of the history object */
	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}

	/** getter - gets the stock price bought/sold of the history object
	 * @return BigDecimal - stock price */
	public BigDecimal getstockPrice() 
	{
		return stockPrice;
	}
	
	/** getter - gets the stock price rounded down to two decimal places
	 * @return BigDecimal - quantity */
	public BigDecimal getstockPriceRounded() 
	{
		BigDecimal stockPriceRounded = stockPrice.setScale(2, RoundingMode.HALF_EVEN);
		return stockPriceRounded;
	}
	
	/** setter - sets the stock price bought/sold of the history object */
	public void setStockPrice(BigDecimal stockPrice)
	{
		this.stockPrice = stockPrice;
	}

	/** getter - gets the stock symbol of the specific buy/sell history object
	 * @return - String stock symbol code */
	public String getStockSymbol()
	{
		return stockSymbol;
	}
	
	/** setter - sets the stock symbol of the specific buy/sell history object */
	public void setStockSymbol(String stockSymbol)
	{
		this.stockSymbol = stockSymbol;
	}
	
	/** getter - gets the username of the buyer/seller of the specific buy/sell history object */
	public String getUsername()
	{
		return username;
	}
	
	/** getter - gets the timestamp of the specific buy/sell history object */
	public String getDateTime()
	{
		return dateTime;
	}
	
	/** setter - sets the stock symbol of the specific buy/sell history object */
	public void setDateTime(String dateTime)
	{
		this.dateTime = dateTime;
	}
}
