package model;

import java.io.IOException;
import java.math.BigDecimal;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

/** This class is responsible for holding information regarding a players request to buy or trade with another player
 * a request object is a buy or sell request for stock at a certain price of the players choosing. stocks will be modified
 * and completed based on matches in the algorithm which yields an exchange between players. at this point, requests are
 * matched based upon the stock symbol and prices. sometimes quantities are not exact and therefore, modifications occur
 * resulting in the request still having outstanding number of quantity. if the entirety of quantity in the request is
 * reduced to 0, then the request is considered completed. **/

/**
@author Adrian, s3383708
**/

public class Request 
{
	private BigDecimal price;
	private String username;
	private String stockSymbol;
	private int quantity;
	private boolean completed; //used to check if the request is fully completed
	private boolean modified; //used to determine if a request was partially completed and needs to be updated on the database
	
	/** Constructor: Sets all variables based on the parameters passed when object is created **/
	public Request(String username, String stockSymbol, int quantity, BigDecimal price)
	{
		this.username = username;
		this.stockSymbol = stockSymbol;
		this.quantity = quantity;
		this.price = price;
		completed = false;
		modified = false;
	}
	
	/**
	 * Returns the stock from the symbol in the request
	 * @return
	 */
	public Stock returnStock()
	{
		
		Stock stock = null;
		try 
		{
			 stock = YahooFinance.get(stockSymbol);
		} 
		catch (IOException e) 
		{
			
			e.printStackTrace();
		}
		
		
		return stock;
	}
	/**
	 * @return
	 * True if the request has been completed
	 */
	public boolean isCompleted()  //checks if the request has been completed ready for deletion
	{
		return completed;
	}

	/**
	 * Setter - sets if stock request is completed 
	 * @return
	 */
	public void setCompleted(boolean completed) 
	{
		this.completed = completed;
	}
	
	/**
	 * checks to see if request has been modified
	 * @return
	 */
	public boolean wasModified()
	{
		return modified;
	}
	
	/**
	 * set the request modified variable with this
	 * @return
	 */
	public void setModified(boolean modified)
	{
		this.modified = modified;
	}
	
	/**
	 * obtain the quantity outstanding on this request
	 * @return
	 */
	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	
	public String getUsername()
	{
		return username;
	}

	public void setUsername(String user) 
	{
		username = user;
	}
	
	public BigDecimal getPrice()
	{
		return price;
	}

	public void setPrice(BigDecimal price) 
	{
		this.price = price;
	}
	
	public String getSymbol()
	{
		return stockSymbol;
	}
	
	public void setSymbol(String newSymbol)
	{
		stockSymbol = newSymbol;
	}
	
	
	
	
	
	
	
}
