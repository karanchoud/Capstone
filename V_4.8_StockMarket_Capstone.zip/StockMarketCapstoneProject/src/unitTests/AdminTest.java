package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;

public class AdminTest
{	
	private RegisterServlet server;
	Player player;
	
	Stock stock;
	
	String user, user2, correctPass, password, first, last, email;
	BigDecimal addedFunds;
	Admin admin;
	double expectedFunds;
	ArrayList<CPstock> portfolio;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "testPlayer";
		user2 = "idontexist";
		password = "Password1";
		first = "Adrian";
		last = "Riscica";
		email = "s3383708@student.rmit.edu.au";
		db = Database.getInstance();
		//Player player;
		expectedFunds = 1000000;
		db.addPlayer(user, password, first, last, email);
		addedFunds = new BigDecimal(500);
		admin = new Admin();
	}

	
	
	@Test
	public void TestResetPlayerValidPlayer() 
	{
		
		player = db.getPlayer(user);
		if(player !=null)
		{
		admin.resetPlayer(user);
		//db.ResetPlayer(player);
		BigDecimal expectedFundsBD = new BigDecimal(expectedFunds);
		int result = expectedFundsBD.compareTo(db.getPlayer(user).getFunds());
		assertEquals(0, result); //0 indicates match (ie same value)
		}
		
	}
	
	@Test
	public void TestResetPlayerinValidPlayer() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		
		//assertEquals(true, db.getPlayer(user));
		player = db.getPlayer(user2);
		Admin admin = new Admin();
		boolean result = admin.resetPlayer(user2);
		//boolean result = db.ResetPlayer(player);
		assertEquals(false, result);
		
		
	}
	
	/*@Test
	public void TestRemoveinValidPlayer() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!
		
		//assertEquals(true, db.getPlayer(user));
		assertEquals(false, db.RemovePlayer(user2));
	}*/
		
	@Test
	public void TestFundInjectioninValidPlayer() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		
		//assertEquals(true, db.getPlayer(user));
		Admin admin = new Admin();
		//assertEquals(true, db.getPlayer(user));
		boolean result = admin.amendFunds(user2, new BigDecimal(50000));
		assertEquals(false, result);
		//assertEquals(false, db.addPlayerFunds(user2, new BigDecimal(50000)));
	}
	
	@Test
	public void TestFundInjectionValidPlayer() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		Admin admin = new Admin();
		//assertEquals(true, db.getPlayer(user));
		boolean result = admin.amendFunds(user, new BigDecimal(50000));
		assertEquals(true, result);
		//assertEquals(true, db.addPlayerFunds(user, new BigDecimal(50000)));
	}
	
	/*@Test
	public void TestRemovePlayerValidPlayer() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!
		
		//assertEquals(true, db.getPlayer(user));
		
		db.RemovePlayer(user);
		player = db.getPlayer(user);
		assertEquals(player, null);
		
		
		
	}*/
	
	@Test
	public void TestModifyFundsValidPlayer() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		
		//assertEquals(true, db.getPlayer(user));
		
		db.ModifyPlayerFunds(user, new BigDecimal(50000));
		player = db.getPlayer(user);
		assertEquals(player.getFunds(), new BigDecimal(50000));
		
		
		
	}


	
}
