package model;

import java.util.ArrayList;

import yahoofinance.Stock;

public class GraphBuilder 
{
	private ArrayList<Stock> chartData = new ArrayList<Stock>();
}
