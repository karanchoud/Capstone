package model;

import java.io.IOException;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.UUID;

import org.apache.http.cookie.SM;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

//import javax.resource.cci.ResultSet;

public class Database //used to store player IDs, current stock data owned by players, and player account info


{

	private boolean connectionSuccess = false;
	Connection conn;
	HashMap<String,Player> playerMap = new HashMap<String,Player>();
	
	private static Database database = new Database();
	private ArrayList buyRequestHolder;
	
	public static Database getInstance()
	{
		
		return database;
	}
	
	public Database()
	{
		
		/*try
		{
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://166.62.28.123:3306/stockmarketDB", "stockMarketAdmin", "passs");
		

		} catch (SQLException ex) {
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		    connectionSuccess = false;
		    return;
		} 
		catch (ClassNotFoundException e) {
			System.out.println("Where is your MySQL JDBC Driver?");
			e.printStackTrace();
			connectionSuccess = false;
			return;
		}

		System.out.println("connection established!");
		
		connectionSuccess = true;*/
	}
	
	public boolean openConnection()
	{
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://166.62.28.123:3306/stockmarketDB", "stockMarketAdmin", "passs");
		

		} catch (SQLException ex) {
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		    connectionSuccess = false;
		    return false;
		} 
		catch (ClassNotFoundException e) {
			System.out.println("Where is your MySQL JDBC Driver?");
			e.printStackTrace();
			connectionSuccess = false;
			return false;
		}

		System.out.println("connection established!");
		
		connectionSuccess = true;
		return true;
	}
	
	public boolean closeConnection()
	{
		try
		{
		conn.close();
		return true;
		} catch (SQLException ex) {
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		    connectionSuccess = false;
		    return false;
		} 
		
	}
	
	public boolean getConnectionSuccess()
	{
		return connectionSuccess;
	}
	
	//String user, String pass, String first, String last, String email
	public boolean addPlayer(String user, String pass, String first, String last, String email)
	{
		database.openConnection();
		/*
		 * validation checks
		 */
		boolean upperCaseCheck = false, digitCheck = false;
		if(user == "" | user == null | pass == "" | pass == null | first == "" | first == null | last == "" | last == null
				| email == "" | email == null)
		{
			System.out.println("found a null value somewhere");
			database.closeConnection();
			return false;
		}
		
		if(pass.length() < 6)
		{
			System.out.println("found pass less than 6 chars");
			database.closeConnection();
			return false;
		}
		
		for(int i=0; i< pass.length(); i++)
		{
			if(Character.isUpperCase(pass.charAt(i)))
			{
				upperCaseCheck = true;
			}
			else if(Character.isDigit(pass.charAt(i)))
			{
				digitCheck = true;
			}
		
		}
		
		if(digitCheck != true | upperCaseCheck != true)
		{
			System.out.println("missing capital or digit");
			database.closeConnection();
			return false;
		}
		
		 Statement st;
		 int valid = 1;
		
			 try {
				 	st = conn.createStatement();
			
				 	//here we authenticate 
				 	String id = UUID.randomUUID().toString();
				 	//String id = "myid";
				 	String searchQuery = "SELECT * FROM Player WHERE username='"+user+"'";
				 	
				 	ResultSet rs =  st.executeQuery(searchQuery);
				 	if(rs.next())
				 		{
				 			valid = 0;
				 		}
				 if(valid == 0)
				 	{
				//duplicate found reset while loop and try again
					 	//valid = 1;
					 	System.out.println("Duplicate Found!");
					 	database.closeConnection();
					 	return false; 
				 	//	continue;
				 	}
				 
				//valid = 2;
				
			//String query = "INSERT INTO test VALUES(1006, 'Karan', 'Choudhary')";
			String realQuery = "INSERT INTO Player VALUES('"+id+"', '"+user+"', '"+pass+"', '"+first+"', '"+last+"', '"+email+"', 1000000)";
			st.executeUpdate(realQuery);
			
			//conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		}
		
	 //}
	     database.closeConnection();
		 return true;
	}
	
	
	public void addPlayer(Player player)
	{
		//add the player to the hashmap
		 Statement st;
		try {
			st = conn.createStatement();
			String query = "INSERT INTO test VALUES(1004, 'Adrian', 'Riscica')";
			st.executeUpdate(query);
			
			//conn.close();
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}                                 

				 

			
		
		
		
		
		
		
		
		/* daniel's initial code */
		/*if(playerMap.containsKey(player.getID()))
		{
			System.out.println("ERROR player ID already exists");
			return false;
			
		}
		else
		{
			playerMap.put(player.getID(),player);
			return true;
		}*/
		
		
		
	}
	
	
	
	
	
	public boolean authPlayer(String passedInputUser, String passedInputPass)
	{
		database.openConnection();
		//login functionality
		 Statement st;
		 String dbPass;
		
			 try {
				 	st = conn.createStatement();
			
				 	//here we authenticate 
				 	String inputUser = passedInputUser; // user must be unique, these will be passed in as parameters
				 	String inputPass = passedInputPass;
				 	
				 	if(inputUser == null | inputUser == "" | inputPass == null | inputPass == "")
				 	{
				 		System.out.println("null user or pass");
				 		database.closeConnection();
				 		return false;
				 	}
				 	
				 	String searchQuery = "SELECT * FROM Player WHERE username='"+inputUser+"'"; // ***playerID needs to change to Username column***
				 	
				 	ResultSet rs =  st.executeQuery(searchQuery);
				 	if(rs.next())
				 		{
				 			//result found, valid username exists, now check for pass
				 			//dbUser = rs.getString(1); //dbUsername
				 			dbPass = rs.getString(3); //dbPassword
				 			if(dbPass.equals(inputPass))
				 				{
				 					//password match
				 					System.out.println("User and Pass match returning true");
				 					database.closeConnection();
				 					return true;
				 				}	 			
				 		}
				 	else
				 		{
				 			System.out.println("No user with that username returning false");
				 			database.closeConnection();
				 			return false;
				 		}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		}
		
		 System.out.println("password didnt match but user does exist, returning false");
		 database.closeConnection();
		 return false;
	}
	
	public Player getPlayer(String inputUser)
	{
		database.openConnection();
		
		 Statement st;
		 Player loadPlayer = null;
		 
		
			 try {
				 	st = conn.createStatement();
			
				 	//here we authenticate 
				 	
				 	
				 	String getPlayerQuery = "SELECT * FROM Player WHERE username='"+inputUser+"'"; // ***playerID needs to change to Username column***
				 	ResultSet rs =  st.executeQuery(getPlayerQuery);
				 	if(rs.next())
				 	{
				 		System.out.println("extracting player details");
				 		String id = rs.getString(1);
				 		String username = rs.getString(2);
				 		String password = rs.getString(3);
				 		String firstName = rs.getString(4);
				 		String lastName = rs.getString(5);
				 		String email = rs.getString(6);
				 		BigDecimal funds = new BigDecimal(rs.getDouble(7));
				 		System.out.println("player name: " + username);
				 		ArrayList<CPstock> portfolio = getPlayerPortfolio(username);
				 		
				 		loadPlayer = new Player(username, password, firstName, lastName, id,funds,portfolio,email);
				 		//loadPlayer.setPortfolio(database.getPlayerPortfolio(username));
				 	}
				 database.closeConnection();
				 return loadPlayer;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		}
		
		
		
		//if this returns here, it returns a null object suggesting something has gone wrong
		database.closeConnection();
		return loadPlayer;
	}
	
	
	private ArrayList<CPstock> getPlayerPortfolio(String username)
	{
		ArrayList<CPstock >portfolio = new ArrayList<CPstock>();
		Statement st;
		
		
			 try {
				 	st = conn.createStatement();
			
				 	//here we authenticate 
				 	
				 	
				 	String getPortfolioQuery = "SELECT * FROM Portfolio WHERE username='"+username+"'"; // ***playerID needs to change to Username column***
				 	ResultSet rs =  st.executeQuery(getPortfolioQuery);
				 	
				 	while(rs.next())
				 	{
				 		//extract portfolio record data here and build portfolio arraylist
				 		String recordUsername = rs.getString(2);
				 		String stockSymbol = rs.getString(3);
				 		int stockQuantity = rs.getInt(4);
				 		double investment = rs.getDouble(5);
				 		BigDecimal convertInvestment = new BigDecimal(investment);
				 		
				 		Stock stock = null;
				 		stock = YahooFinance.get(stockSymbol);
				 		
				 		CPstock portfolioItem = new CPstock(stock, stockQuantity, convertInvestment);
				 		System.out.println("quantity: " + portfolioItem.getQuantity());
				 		portfolio.add(portfolioItem);
				 	}
				
				 	if(rs.first() == false)
				 	{
				 		System.out.println("No portfolio objects found");
				 		//portfolio = null; i've commented this out because i want an empty list in the case that theres no objects to rebuild a complete player object
				 		return portfolio;
				 	}
				 	
				 return portfolio;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		} catch (IOException eIO)
			 {
			eIO.printStackTrace();
			
			 }
		
		
		
		return portfolio;
	}
	
	
	public boolean addToPlayerPortfolio(String username, Stock stock, int quantity, BigDecimal baseInvestment)
	{
		database.openConnection();
		
		if(stock.isValid()!=true | quantity <= 0 | baseInvestment.compareTo(BigDecimal.ZERO) <=0)
		{
			database.closeConnection();
			return false;
		}
		
		
		Statement st;	
		 try {
			 	st = conn.createStatement();
		
			 	
			 	String stockSym = stock.getSymbol();
			 	
			 	String getPortfolioQuery = "SELECT * FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'"; // ***playerID needs to change to Username column***
			 	ResultSet rs = st.executeQuery(getPortfolioQuery);
			 	
			 	if(rs.next())
			 	{
			 		//record exists therefore, add quantity to portfolio item
			 		int dbQuantity = rs.getInt(4);
			 		double dbBaseInvest = rs.getDouble(5);
			 		double convertedAccBaseInvestment = baseInvestment.doubleValue() + dbBaseInvest;
			 		
			 		quantity = dbQuantity + quantity;
			 		String amendPortfolioQuery = "UPDATE Portfolio SET stockquantity='"+quantity+"' WHERE username='"+username+"' AND "
			 				+ "stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(amendPortfolioQuery);
			 		amendPortfolioQuery = "UPDATE Portfolio SET baseinvestment='"+convertedAccBaseInvestment+"' WHERE "
			 				+ "username='"+username+"' AND "
			 				+ "stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(amendPortfolioQuery);
			 		database.closeConnection();
			 		return true;
			 	}
			 	else
			 	{
			 		double convertedBaseInvest = baseInvestment.doubleValue();
			 		String addPortfolioQuery = "INSERT INTO Portfolio(username, stocksymbol, stockquantity, baseinvestment) "
			 				+ "VALUES('"+username+"', '"+stockSym+"', '"+quantity+"', '"+convertedBaseInvest+"')"; 						// ***playerID needs to change to Username column***
			 		st.executeUpdate(addPortfolioQuery);
			 		database.closeConnection();
			 		return true;
			 	}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
		database.closeConnection();
		return false;
	}
	
	
	public boolean removeFromPlayerPortfolio(String username, Stock stock, int quantity, BigDecimal baseInvestmentReduction)
	{
		database.openConnection();
		if(stock.isValid()!=true | quantity <= 0 | baseInvestmentReduction.compareTo(BigDecimal.ZERO) <=0)
		{
			database.closeConnection();
			return false;
		}
		
		Statement st;
		
		
		 try {
			 	st = conn.createStatement();
		
			 	//here we authenticate 
			 	String stockSym = stock.getSymbol();
			 	
			 	String getPortfolioQuery = "SELECT * FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'"; // ***playerID needs to change to Username column***
			 	ResultSet rs = st.executeQuery(getPortfolioQuery);
			 	
			 	if(rs.next())
			 	{
			 		int dbQuantity = rs.getInt(4);
			 		double dbBaseInvestment = rs.getDouble(5);
			 		if(quantity < dbQuantity)
			 		{
			 			
			 			quantity = dbQuantity - quantity;
			 			
			 			double convertedBaseReduction = dbBaseInvestment - baseInvestmentReduction.doubleValue();
			 			String amendQuery = "UPDATE Portfolio SET stockquantity='"+quantity+"' WHERE username='"+username+"' AND "
			 					+ "stocksymbol='"+stockSym+"'";
			 			st.executeUpdate(amendQuery);
			 			amendQuery = "UPDATE Portfolio SET baseinvestment='"+convertedBaseReduction+"' WHERE username='"+username+"' AND "
			 					+ "stocksymbol='"+stockSym+"'";
			 			st.executeUpdate(amendQuery);
			 			database.closeConnection();
			 			return true; // update successful
			 		}
			 		else if(quantity == dbQuantity)
			 		{
			 			//delete record here
			 			System.out.println("printing here");
			 			String deleteQuery = "DELETE FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'";
			 			st.executeUpdate(deleteQuery);
			 			database.closeConnection();
			 			return true;
			 		}
			 		
			 	}
			 	else
			 	{
			 		System.out.println("invalid negative input");
			 		database.closeConnection();
			 		return false; // no record found
			 	}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
	
		database.closeConnection();
		return false;
		
	}
	
	
	public boolean buyUpdate(Player player, String stockSym, int quantity, BigDecimal stockPrice)
	{
		database.openConnection();
		Statement st;
		
		if(quantity <= 0 | stockPrice.compareTo(BigDecimal.ZERO) <=0)
		{
			database.closeConnection();
			return false;
		}
		
		
		
		 try {
			 Stock stock = YahooFinance.get(stockSym);
			 if(stock.isValid()!=true)
			 {
				 database.closeConnection();
				 return false;
			 }
			 	st = conn.createStatement();
	
			 	//here we authenticate 
			 	
			 	
			 	//String modifyFundsQuery = "UPDATE Player SET funds='"+player.getFunds()+"' WHERE username='"+player.getUserName()+"'";
			 	//st.executeUpdate(modifyFundsQuery);
			 	
			 	String searchQuery = "SELECT * FROM BuyRequests WHERE username='"+player.getUserName()+"' AND stocksymbol='"+stockSym+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	
			 	
			 	if(rs.next())
			 		{
			 		//if record exists...
			 		System.out.println("modifying buy request record");
			 		String alterQuantityQuery = "UPDATE BuyRequests SET quantity='"+quantity+"' WHERE "
			 				+ "username='"+player.getUserName()+"' AND stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(alterQuantityQuery);
			 		
			 		String alterPurchasePriceQuery = "UPDATE BuyRequests SET purchaseprice='"+stockPrice.doubleValue()+"' WHERE "
			 				+ "username='"+player.getUserName()+"' AND stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(alterPurchasePriceQuery);
			 		database.closeConnection();
			 		return true;
			 		}
			 	//if record does not exist...
			 	String addBuyQuery = "INSERT INTO BuyRequests(username, stocksymbol, quantity, purchaseprice) VALUES('"+player.getUserName()+"', '"+stockSym+"', '"+quantity+"', '"+stockPrice.doubleValue()+"')";
			 	st.executeUpdate(addBuyQuery);
			 	database.closeConnection();
			 	return true;

		 	} catch (SQLException | IOException e) {
		 		// TODO Auto-generated catch block
		 		e.printStackTrace();
		 		System.out.println("hello world");
		 	}
		 database.closeConnection();
		 return false;
	}
	
	public BigDecimal getOldBuyPrice(String username, String stockSymbol)
	{
		database.openConnection();
		
		if(username == "" | username == null)
		{
			database.closeConnection();
			return null;
		}

		Statement st;
		
		try {
			 Stock stock = YahooFinance.get(stockSymbol);
			 if(stock.isValid()!=true)
			 {
				 database.closeConnection();
				 return null;
			 }
			
		 	st = conn.createStatement();
	
		 	
		 	
		 	String searchQuery = "SELECT * FROM BuyRequests WHERE username='"+username+"' AND "
		 			+ "stocksymbol='"+stockSymbol+"'";
		 	
		 	ResultSet rs =  st.executeQuery(searchQuery);
		 	if(rs.next())
		 		{
		 			//found record
		 			Double purchasePrice = rs.getDouble(5);
		 			int quantity = rs.getInt(4);
		 			System.out.println(purchasePrice);
		 			BigDecimal value = new BigDecimal(purchasePrice, MathContext.DECIMAL64);
		 			BigDecimal finalValue = value.multiply(new BigDecimal(quantity));
		 			database.closeConnection();
		 			return finalValue;
		 			
		 		}
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		}
		database.closeConnection();
		return null;
	}
	

	public boolean checkStockDuplicity(String username, String stockSymbol)
 	{
			database.openConnection();
			
			if(username == "" | username == null)
			{
				database.closeConnection();
				return true;
			}
			
			Statement st;
			
			try {
				 Stock stock = YahooFinance.get(stockSymbol);
				 if(stock.isValid()!=true)
				 {
					 database.closeConnection();
					 return true;
				 }
				
				
			 	st = conn.createStatement();
			 	String searchQuery = "SELECT * FROM BuyRequests WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
			 	
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	if(rs.next())
			 		{
			 			//found record
			 			System.out.println("record found");
			 			database.closeConnection();
			 			return true;
			 		}
		
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("hello world");
			}
		database.closeConnection();
 		return false;
		
 	}

	
	public boolean checkStockDuplicitySell(String username, String stockSymbol)
 	{
			database.openConnection();
			
			if(username == "" | username == null)
			{
				database.closeConnection();
				return true;
			}
			
			Statement st;
			
			try {
				
				Stock stock = YahooFinance.get(stockSymbol);
				 if(stock.isValid()!=true)
				 {
					 database.closeConnection();
					 return true;
				 }
				
			 	st = conn.createStatement();
			 	String searchQuery = "SELECT * FROM SellRequests WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
			 	
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	if(rs.next())
			 		{
			 			//found record
			 			System.out.println("record found");
			 			database.closeConnection();
			 			return true;
			 		}
		
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
		database.closeConnection();
 		return false;
		
 	}
	
	
	public boolean checkStockQuantity(String username, String stockSymbol, int quantity)
 	{
			database.openConnection();
			Statement st;
			
			if(username == "" | username == null | quantity <=0)
			{
				database.closeConnection();
				return false;
			}
			
			
			try {
				
				Stock stock = YahooFinance.get(stockSymbol);
				 if(stock.isValid()!=true)
				 {
					 database.closeConnection();
					 return false;
				 }
				
			 	st = conn.createStatement();
		
			 	
			 	
			 	String searchQuery = "SELECT * FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSymbol+"'";
			 	
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	if(rs.next())
			 		{
			 			//found record
			 			System.out.println("record found");
			 			
			 			if((rs.getInt(4) - quantity) < 0)
			 			{
			 				database.closeConnection();
			 				return false;
			 			}
			 			database.closeConnection();
			 			return true;
			 		}
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("hello world");
			}
		database.closeConnection();
 		return false;
		
 	}
	
	
	public boolean sellUpdate(Player player, String stockSym, int quantity, BigDecimal sellPrice)
	{
		database.openConnection();
		Statement st;
		
		if(quantity <= 0 | sellPrice.compareTo(BigDecimal.ZERO) <=0)
		{
			database.closeConnection();
			return false;
		}
		
		 try {
			 Stock stock = YahooFinance.get(stockSym);
			 if(stock.isValid()!=true)
			 {
				 database.closeConnection();
				 return false;
			 }
			 st = conn.createStatement();
		

			 	String searchQuery = "SELECT * FROM SellRequests WHERE username='"+player.getUserName()+"' AND "
			 			+ "stocksymbol='"+stockSym+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	if(rs.next())
			 		{
			 		//if record exists...
			 		System.out.println("modifying sell request record");
			 		String query = "UPDATE SellRequests SET quantity='"+quantity+"' WHERE username='"+player.getUserName()+"' AND "
			 				+ "stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(query);
			 		query = "UPDATE SellRequests SET sellprice='"+sellPrice.doubleValue()+"' WHERE username='"+player.getUserName()+"' AND "
			 				+ "stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(query);
			 		database.closeConnection();
			 		return true;
			 		}
			 	//if record does not exist...
			 	String addSellQuery = "INSERT INTO SellRequests(username, stocksymbol, quantity, sellprice) "
			 			+ "VALUES('"+player.getUserName()+"', '"+stockSym+"', '"+quantity+"', '"+sellPrice.doubleValue()+"')";
			 	st.executeUpdate(addSellQuery);
			 	database.closeConnection();
			 	return true;

		 	} catch (SQLException | IOException e) {
		 		// TODO Auto-generated catch block
		 		e.printStackTrace();
		 		System.out.println("hello world");
		 	}
		 database.closeConnection();
		 return false;
	}
	
	
	public LinkedList<Request> getAllBuyRequests()
	{
		database.openConnection();
		LinkedList<Request> buyRequestHolder = new LinkedList<Request>();
		
		Statement st;
		
		try {
		 	st = conn.createStatement();
		 	String searchQuery = "SELECT * FROM BuyRequests";
		 	
		 	ResultSet rs =  st.executeQuery(searchQuery);
		 	while(rs.next())
		 		{
		 			//found record
		 			//add to arraylist in here
		 		
		 			String username = rs.getString(2);
		 			String stockSymbol = rs.getString(3);
		 			int quantity = rs.getInt(4);
		 			Double price = rs.getDouble(5);
		 		
		 			BigDecimal convertedPrice = new BigDecimal(price);
		 			
		 			Request newRequest = new Request(username, stockSymbol, quantity, convertedPrice);
		 			buyRequestHolder.add(newRequest);
		 		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		if(buyRequestHolder.size() == 0)
		{
			System.out.println("no buy requests at all");
			database.closeConnection();
			return buyRequestHolder;
		}
		database.closeConnection();
		return buyRequestHolder;
	}
	
	public LinkedList<Request> getAllSellRequests()
	{
		database.openConnection();
		LinkedList<Request> sellRequestHolder = new LinkedList<Request>();
		
		Statement st;
		
		try {
		 	st = conn.createStatement();
		 	String searchQuery = "SELECT * FROM SellRequests";
		 	
		 	ResultSet rs =  st.executeQuery(searchQuery);
		 	while(rs.next())
		 		{
		 			//found record
		 			//add to arraylist in here
		 		
		 			String username = rs.getString(2);
		 			String stockSymbol = rs.getString(3);
		 			int quantity = rs.getInt(4);
		 			Double price = rs.getDouble(5);
		 		
		 			BigDecimal convertedPrice = new BigDecimal(price);
		 			
		 			Request newRequest = new Request(username, stockSymbol, quantity, convertedPrice);
		 			sellRequestHolder.add(newRequest);
		 		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		if(sellRequestHolder.size() == 0)
		{
			System.out.println("no sell requests at all");
			database.closeConnection();
			return sellRequestHolder;
		}
		database.closeConnection();
		return sellRequestHolder;
	}
	
	public ArrayList<String> getPlayerBuyRequests(String username)
	{
		database.openConnection();
		Statement st;
		ArrayList<String> buyRequests = new ArrayList<String>();
	
		
		
		
		 try {
			
			
			 	st = conn.createStatement();
	
			 	//here we authenticate 
			 	
			 	
			 	//String modifyFundsQuery = "UPDATE Player SET funds='"+player.getFunds()+"' WHERE username='"+player.getUserName()+"'";
			 	//st.executeUpdate(modifyFundsQuery);
			 	
			 	String searchQuery = "SELECT * FROM BuyRequests WHERE username='"+username+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	
			 	while(rs.next())
			 	{
			 		String stockSymbol = rs.getString(3);
			 		buyRequests.add(stockSymbol);
			 	}
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
database.closeConnection();
	return buyRequests;
	
	}
	
	
	public ArrayList<String> getPlayerSellRequests(String username)
	{
		database.openConnection();
		Statement st;
		ArrayList<String> sellRequests = new ArrayList<String>();
	
		
		
		
		 try {
			
			
			 	st = conn.createStatement();
	
			 	//here we authenticate 
			 	
			 	
			 	//String modifyFundsQuery = "UPDATE Player SET funds='"+player.getFunds()+"' WHERE username='"+player.getUserName()+"'";
			 	//st.executeUpdate(modifyFundsQuery);
			 	
			 	String searchQuery = "SELECT * FROM SellRequests WHERE username='"+username+"'";
			 	ResultSet rs =  st.executeQuery(searchQuery);
			 	
			 	while(rs.next())
			 	{
			 		String stockSymbol = rs.getString(3);
			 		sellRequests.add(stockSymbol);
			 	}
			 	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
	database.closeConnection();
	return sellRequests;
	
	}
	
	public boolean deletePlayerBuyRequest(Request req)
	{
		database.openConnection();
		Statement st;
	
		 try {

			 	st = conn.createStatement();
			 	String deleteQuery = "DELETE FROM BuyRequests WHERE username='"+req.getUsername()+"' AND stocksymbol='"+req.getSymbol()+"'";
			 	st.executeUpdate(deleteQuery);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
	
	}
	
	public boolean deletePlayerSellRequest(Request req)
	{
		database.openConnection();
		Statement st;
		
		 try {

			 	st = conn.createStatement();
			 	String deleteQuery = "DELETE FROM SellRequests WHERE username='"+req.getUsername()+"' AND stocksymbol='"+req.getSymbol()+"'";
			 	st.executeUpdate(deleteQuery);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
		database.closeConnection();
		return false;
	}
	database.closeConnection();
	return true;
	
	}
	
	
	
	
}
