package controller;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.ShareMarket;
import yahoofinance.Stock;

@SuppressWarnings("serial")
public class AmendOrderServlet extends HttpServlet
{
	
	private ShareMarket shareMarket = new ShareMarket();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		HttpSession session = request.getSession();
		
		String userName = (String) session.getAttribute("username");
		String stockSymbol = request.getParameter("requestSelect");
		BigDecimal stockPrice;
		int quantity;

		String quantitySTR = request.getParameter("quantity");
		String StockPriceSTR = request.getParameter("limitValue");

		if (!stockSymbol.endsWith(".AX")) 
		{
			stockSymbol = stockSymbol + ".AX";
		}
		
		
		if(validInput(stockSymbol, StockPriceSTR, quantitySTR)) //if the form data is all valid
		{
			if(request.getParameter("item").equals("buy")) //if its an amendBbuy request
			{
				System.out.println("valid input calling amendBuy");
				
				quantity = Integer.parseInt(quantitySTR);
				stockPrice = new BigDecimal(StockPriceSTR);
				
				shareMarket.amendBuy(userName, stockSymbol, stockPrice, quantity);
			}
			else //its an amendSell request
			{
				System.out.println("valid input calling amendSell");
				
				quantity = Integer.parseInt(quantitySTR);
				stockPrice = new BigDecimal(StockPriceSTR);
				
				shareMarket.amendSell(userName, stockSymbol, stockPrice, quantity);
			}
		}
		else
		{
			System.out.println("could not complete amend request, input is invalid!");
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("amend.jsp"); 
		dispatcher.forward(request, response);
		
		
		
		
	}
	
	/**
	 * Returns True if all the form data sent by the player is valid and can be
	 * used to call a share market method
	 * 
	 * @param stockSymbol
	 * @param stockPriceSTR
	 * @param quantitySTR
	 * @return
	 * 
	 * True if Input is valid for a bidOrder or bidOrderSell
	 */
	public boolean validInput(String stockSymbol, String stockPriceSTR, String quantitySTR) 
	{
		return (stockIsValid(stockSymbol) && priceIsValid(stockPriceSTR) && quantityIsValid(quantitySTR));
	}
	
	
	/**
	 * returns true if the quantity is a valid number
	 * 
	 * @param quantitySTR
	 * @return
	 */
	private boolean quantityIsValid(String quantitySTR) 
	{
		for (int i = 0; i < quantitySTR.length(); i++) 
		{
			if (Character.isDigit(quantitySTR.charAt(i))) 
			{
				continue;
			} 
			else 
			{
				System.out.println("quantitiy is not valid!");
				return false;
			}
		}

		System.out.println("quantity is valid");
		return true;
	}

	/**
	 * returns true if the price is valid
	 * 
	 * @param stockPriceSTR
	 * @return
	 */
	private boolean priceIsValid(String stockPriceSTR) 
	{
		try 
		{
			BigDecimal stockPrice = new BigDecimal(stockPriceSTR/* .replaceAll(",", "") */);
		} 
		catch (NumberFormatException e) 
		{
			e.printStackTrace();
			System.out.println("price invalid couldnt be converted to Big Decimal");
			return false;
		}

		System.out.println("price is valid");
		return true;
	}

	/**
	 * Returns true if the stock symbol passed is a valid AX stock
	 * 
	 * @param stockSymbol
	 * @return
	 */
	private boolean stockIsValid(String stockSymbol) 
	{
		Stock stock = shareMarket.getSingleStock(stockSymbol);

		if (stock != null && stock.getQuote().getAsk() != null) //if the stock has an ask price quote and is not null its a valid .AX stock
		{
			System.out.println("stock is valid");

			return true;
		} 
		else 
		{
			System.out.println("Stock is not valid!");
			return false;
		}
	}
}
