package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;

public class AddToPortfolioTest
{	
	private RegisterServlet server;
	Player player;
	
	Stock stock, invalidStock;
	ShareMarket sm;
	String user, user2, correctPass, wrongPass, nullPass, nullUser;
	int quantity, invalidQuantity;
	BigDecimal baseInvestment, invalidBaseInvestment;
	ArrayList<CPstock> portfolio;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "ruff";
		user2 = "newUser";
		db = Database.getInstance();
		Player player;
		sm = new ShareMarket();
		stock = sm.getSingleStock("MMJ.AX");
		baseInvestment = new BigDecimal(1250);
		invalidStock = sm.getSingleStock("NOTSTOCK");
		quantity = 1000;
		invalidQuantity = -200;
		invalidBaseInvestment = new BigDecimal(-200);
	}
	@Test
	public void amendCurrentRecordIfExist() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(true, db.addToPlayerPortfolio(user, stock, quantity, baseInvestment));	
	
		
	}
	
	@Test
	public void createNewRecord() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(true, db.addToPlayerPortfolio(user2, stock, quantity, baseInvestment));	
	}
	
	
	@Test
	public void checkStockFailure() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(false, db.addToPlayerPortfolio(user, invalidStock, quantity, baseInvestment));	
	}
	
	@Test
	public void checkQuantityInvalid() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(false, db.addToPlayerPortfolio(user, stock, invalidQuantity, baseInvestment));	
	}
	
	
	@Test
	public void checkBaseInvestmentInvalid() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(false, db.addToPlayerPortfolio(user, stock, quantity, invalidBaseInvestment));	
	}
	
}