package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;

public class SellUpdateTest
{	
	private RegisterServlet server;
	Player player;
	
	
	ShareMarket sm;
	String user, stockSymbol, stockSymbol2, invalidStockSymbol;
	int quantity, invalidQuantity;
	BigDecimal stockPrice, invalidStockPrice;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "ruff";
		
		db = Database.getInstance();
		sm = new ShareMarket();
		stockPrice = new BigDecimal(0.70);
		invalidStockPrice = new BigDecimal(-0.80);
	
		quantity = 1000;
		invalidQuantity = -200;
		stockSymbol = "MMJ.AX";
		stockSymbol2 = "CPH.AX";
		invalidStockSymbol = "NOTASYMBOL.AX";
		
	}
	@Test
	public void amendCurrentRecordIfExist() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		player = db.getPlayer(user);
		assertEquals(true, db.sellUpdate(player, stockSymbol, quantity, stockPrice));	
	
		
	}
	
	@Test
	public void createNewRecordForStock() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		player = db.getPlayer(user);
		assertEquals(true, db.sellUpdate(player, stockSymbol2, quantity, stockPrice));
	}
	
	
	@Test
	public void checkStockFailure() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(false, db.sellUpdate(player, invalidStockSymbol, quantity, stockPrice));	
	}
	
	@Test
	public void checkQuantityInvalid() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(false, db.sellUpdate(player, stockSymbol, invalidQuantity, stockPrice));	
	}
	
	
	@Test
	public void checkpurchasePriceInvalid() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(false, db.sellUpdate(player, stockSymbol, quantity, invalidStockPrice));	
	}
	
}