package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;

public class GetRequestsTest
{	
	private RegisterServlet server;
	
	
	
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		
		
	}
	@Test
	public void checkNonEmptyRequestsBuy() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(true, db.getAllBuyRequests().size() != 0);	
	}
	
	@Test
	public void checkNonEmptyRequestsSell() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		
		assertEquals(true, db.getAllSellRequests().size() != 0);	
	}

	
}