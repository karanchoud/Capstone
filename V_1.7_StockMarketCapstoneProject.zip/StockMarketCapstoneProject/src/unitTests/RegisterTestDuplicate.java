package unitTests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.Database;
import model.Player;
import yahoofinance.Stock;

public class RegisterTestDuplicate
{	
	private RegisterServlet server;
	Player player;
	
	Stock stock;
	
	String user, user2, user3, correctPass, wrongPass1, wrongPass2, wrongPass3, first, last, email, nullUser;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "unique";
		user3 = "unique2";
		user2 = "duplicate";
		nullUser = "";
		correctPass = "AmAzing2";
		wrongPass1 = "pass"; //less than 6 characters long
		wrongPass2 = "nocapitalsinpassword34";
		wrongPass3 = "NONUMBERSINpassword";
		first = "testname";
		last = "testlastname";
		email = "testing@hotmail.com";
		db = Database.getInstance();
		server = new RegisterServlet();
		
		
		
		
	}
	@Test
	public void checkUniqueRecord() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(true, db.addPlayer(user, correctPass, first, last, email));
		System.out.println("its true");
		
	
		
	}
	
	@Test
	public void checkDuplicateRecord() 
	{
		/*test checks for addition of new player, NOTE: username must be a duplicate!*/
		assertEquals(false, db.addPlayer(user2, correctPass, first, last, email));
		System.out.println("username already exists in database");
		
	
		
	}
	
	@Test
	public void checkNullUser() 
	{
		/*test checks for addition of new player, NOTE: username must be a duplicate!*/
		assertEquals(false, db.addPlayer(nullUser, correctPass, first, last, email));
		System.out.println("username is null");
	
		
	}
	
	@Test
	public void checkPassLength()
	{
		assertEquals(false, db.addPlayer(user3, wrongPass1, first, last, email));
		
	}
	
	@Test
	public void checkPassCapital()
	{
		assertEquals(false, db.addPlayer(user3, wrongPass2, first, last, email));
		
	}
	
	@Test
	public void checkPassDigit()
	{
		assertEquals(false, db.addPlayer(user3, wrongPass3, first, last, email));
		
	}

}
