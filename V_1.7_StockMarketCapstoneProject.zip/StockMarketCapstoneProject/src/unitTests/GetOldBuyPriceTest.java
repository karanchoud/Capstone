package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;

public class GetOldBuyPriceTest
{	
	private RegisterServlet server;
	Player player;
	
	
	ShareMarket sm;
	String user, user2, stockSymbol, stockSymbol2, invalidStockSymbol;
	int quantity, invalidQuantity;
	BigDecimal purchasePrice, expectedCalculation;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		db = Database.getInstance();
		sm = new ShareMarket();
		
		//invalidStockPrice = new BigDecimal(-0.80);
		user = "ruff";
		user2 = "afakeusername";
		stockSymbol = "BIG.AX";
		expectedCalculation = new BigDecimal(700);
		stockSymbol2 = "CPH.AX";
		invalidStockSymbol = "NOTASYMBOL.AX";
		
	}
	@Test
	public void checkCorrectCalculation() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		
		purchasePrice = db.getOldBuyPrice(user, stockSymbol);
		int check = purchasePrice.compareTo(expectedCalculation);
		assertEquals(0,check);
		
		//assertEquals(true, db.buyUpdate(player, stockSymbol, quantity, stockPrice));	
		
		
	}
	

	@Test
	public void checkSuccessfulExecution()
	{
		purchasePrice = db.getOldBuyPrice(user, stockSymbol);
		assertEquals(true,purchasePrice !=null);
	}
	
	
	@Test 
	public void checkUsernameNotExist()
	{
		purchasePrice = db.getOldBuyPrice(user2, stockSymbol);
		assertEquals(true, purchasePrice == null);
	}
	
	@Test 
	public void checkInvalidStock()
	{
		purchasePrice = db.getOldBuyPrice(user, invalidStockSymbol);
		assertEquals(true, purchasePrice == null);
	}
	
}