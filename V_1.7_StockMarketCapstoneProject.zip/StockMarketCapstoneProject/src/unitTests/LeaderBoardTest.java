package unitTests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import app.ServletMain;
import model.CPstock;
import model.FAKEDatabase;
import model.Player;
import yahoofinance.YahooFinance;

public class LeaderBoardTest 
{
	private ServletMain server;
	
	
	@Before
	public void setUp() throws Exception 
	{
		server = new ServletMain();
		
		
		
	}

	@Test
	public void test() 
	{
		server.getLeaderBoard().generateTestPlayers(20);
		
		server.getLeaderBoard().ShowTopPlayers(15);
		
		for(int i = 1; i < server.getLeaderBoard().getPlayerLeaderBoard().size(); i++)
		{
			if(server.getLeaderBoard().getPlayerLeaderBoard().get(i).getTotalFunds().doubleValue() < server.getLeaderBoard().getPlayerLeaderBoard().get(i - 1).getTotalFunds().doubleValue())
			{
				assertTrue(true);
			}
			else
			{
				assertTrue(false);
			}
			
		}
		
		
		
		
	}

}
