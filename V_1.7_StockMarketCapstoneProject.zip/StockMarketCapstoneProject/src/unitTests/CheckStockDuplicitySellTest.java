package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.opsworkscm.model.Server;

import app.ServletMain;
import controller.LoginServlet;
import controller.RegisterServlet;
import model.*;
import yahoofinance.Stock;

public class CheckStockDuplicitySellTest
{	
	private RegisterServlet server;
	
	
	ShareMarket sm;
	String user, nullUser, fakeUser, stockSymbol, stockSymbol2, invalidStockSymbol;
	int quantity, invalidQuantity;
	BigDecimal stockPrice, invalidStockPrice;
	private Database db;
	@Before
	public void setup() throws Exception 
	{
		
		user = "ruff";
		nullUser = "";
		fakeUser = "afakeuser";
		db = Database.getInstance();
		sm = new ShareMarket();
		stockPrice = new BigDecimal(0.70);
		invalidStockPrice = new BigDecimal(-0.80);
	
		quantity = 1000;
		invalidQuantity = -200;
		stockSymbol = "MMJ.AX";
		stockSymbol2 = "NUH.AX";
		invalidStockSymbol = "NOTASYMBOL.AX";
		
	}
	@Test
	public void bidStockExists() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(true, db.checkStockDuplicitySell(user, stockSymbol));	
	}
	
	@Test
	public void bidStockDoesNotExist() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		
		assertEquals(false, db.checkStockDuplicitySell(user, stockSymbol2));
	}
	
	
	@Test
	public void checkStockFailure() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(true, db.checkStockDuplicitySell(user, invalidStockSymbol));
	}
	
	@Test
	public void checkNullUserPassedInSell() 
	{
		/*test checks for addition of new player, NOTE: username must be unique!*/
		assertEquals(true, db.checkStockDuplicitySell(nullUser, stockSymbol));	
	}
	
}