package model;

import java.math.BigDecimal;

public class ProfitLoss {

	private BigDecimal percentChange;
	private BigDecimal valueChange;
	
	public ProfitLoss(BigDecimal percenChange, BigDecimal valueChange)
	{
		this.percentChange = percentChange;
		this.valueChange = valueChange;
		
	}
	
	public BigDecimal getPercentChange()
	{
		return percentChange;
	}
	
	public BigDecimal getValueChange()
	{
		return valueChange;
	}
	
	public void setPercentChange(BigDecimal percentChange)
	{
		this.percentChange = percentChange;
	}
	
	public void setValueChange(BigDecimal valueChange)
	{
		this.valueChange = valueChange;
	}
	
}
