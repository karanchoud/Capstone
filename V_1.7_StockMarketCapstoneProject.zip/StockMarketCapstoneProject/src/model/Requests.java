package model;

import java.math.BigDecimal;
import java.util.ArrayList;

import yahoofinance.Stock;

public class Requests 
{
	private BigDecimal price;
	private String username;
	private String stockSymbol;
	private int quantity;
	
	public Requests(String username, String stockSymbol, int quantity, BigDecimal price)
	{
		this.username = username;
		this.stockSymbol = stockSymbol;
		this.quantity = quantity;
		this.price = price;
	}
	

	
	

	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	
	public String getUsername()
	{
		return username;
	}

	public void setUsername(String user) 
	{
		username = user;
	}
	
	public BigDecimal getPrice()
	{
		return price;
	}

	public void setPrice(BigDecimal price) 
	{
		this.price = price;
	}
	
	public String getSymbol()
	{
		return stockSymbol;
	}
	
	public void setSymbol(String newSymbol)
	{
		stockSymbol = newSymbol;
	}
	
	
	
}
