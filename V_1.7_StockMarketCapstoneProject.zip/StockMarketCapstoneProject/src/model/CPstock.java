package model;

import java.math.BigDecimal;
import java.util.ArrayList;

import yahoofinance.Stock;

public class CPstock 
{
	private Stock stock;
	int quantity;
	private BigDecimal investment;
	
	public CPstock()
	{
		
	}
	
	public CPstock(Stock stock, int quantity, BigDecimal investment)
	{
		this.stock = stock;
		this.quantity = quantity;		
		this.investment = investment;
	}
	
	
	public Stock getStock()
	{
		return stock;
	}
	
	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	
	public BigDecimal getInvestment()
	{
		return investment;
	}
	
	public void setInvestment(BigDecimal investment)
	{
		this.investment = investment;
	}
	
	
}
