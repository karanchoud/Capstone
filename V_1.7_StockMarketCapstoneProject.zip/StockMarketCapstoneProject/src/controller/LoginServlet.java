package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.amazonaws.services.appstream.model.Session;

import model.Database;
import model.FAKEDatabase;
import model.Player;


public class LoginServlet extends HttpServlet
{
	
	private FAKEDatabase Fdatabase = FAKEDatabase.getInstance();
	
	private Database database = Database.getInstance();
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	 {
		 HttpSession session = request.getSession();
		 database.openConnection();
		 
		 if(database.getConnectionSuccess() == false)
		 {
			 
			 System.out.println("connection failed to database");
			 database = null;
			 RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp"); //return all info back to the client
			 dispatcher.forward(request,response);
			 return;
		 }
		 else
		 {
		 //Fdatabase.addPlayer(new Player());
		 
		 PrintWriter out=response.getWriter();
		 
		 if(request.getParameter("loginForm") != null)
			{
				System.out.println("login form is not null!");
				
				String username = request.getParameter("username");
				
				String password = request.getParameter("password");
				System.out.println("hello");
				
				boolean authenticate = database.authPlayer(username, password);
				if(authenticate == true)
				{
				Player player = database.getPlayer(username);
				
				
				session.setAttribute("username", player.getUserName());
				session.setAttribute("errorMsg", "");
				
				//session.setAttribute("username", username);
				//request.setAttribute("username", "karan");
				//request.getSession().setAttribute("username", "karan");
				System.out.println("yoo: " + session.getAttribute("username"));
				//out.println("welcome: " + session.getAttribute("username"));
				RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); //return all info back to the client
				 dispatcher.forward(request,response);
				
				}
				else
				{
					System.out.println("login failed");
					session.setAttribute("errorMsg", "ERROR");
					RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp"); //return all info back to the client
					dispatcher.forward(request,response);
				}
				
				/*
				if(player.getPassword().equals(password)) //if the passwords match log the player in
				{
					
					HttpSession session = request.getSession();
					
					session.setAttribute("username", username);
					
					out.println("welcome: " + session.getAttribute("username"));
					
					/*RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); //return all info back to the client
					dispatcher.forward(request,response);
				}
				*/
				
				/*
				if(Fdatabase.retrievePlayer(username).getPassword().equals(password))
				{
					HttpSession session = request.getSession();
					
					session.setAttribute("username", username);
					
					
					out.println("welcome" + username);
					
					RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp"); //return all info back to the client
					dispatcher.forward(req,resp);
				}
				else
				{
					//invalid password
				}
				*/
				
			}
	 }
		 database.closeConnection();
	}
	 
}
