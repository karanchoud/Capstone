package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Database;
import model.FAKEDatabase;
import model.Player;
import model.ShareMarket;
import yahoofinance.Stock;

import model.*;
public class BuySellServlet extends HttpServlet
{
	
	private FAKEDatabase Fdatabase = FAKEDatabase.getInstance();
	
	private Database database = Database.getInstance();
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	 {
		HttpSession session = request.getSession();
		//Player playerStatic = database.getPlayer("ruff");
		Player player = database.getPlayer(session.getAttribute("username").toString());
		
		boolean invalidInput = false;
		ShareMarket sm = new ShareMarket();
		String stockSymbol = null;
		String quantity = null;
		String strLimit = null;
		String buy, sell, limit, market;
		BigDecimal convertLimitVal = null;
		if(request.getParameter("code") != null && request.getParameter("quantity") != null)
		{
			stockSymbol = request.getParameter("code").toString();
			quantity = request.getParameter("quantity").toString();
			if(stockSymbol == "" | quantity == "")
			{
				session.setAttribute("errorMsg", "ERROR: No quantity or Stock code entered");
				RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp");
				dispatcher.forward(request,response);
				return;
			}
		
		}
	
		
		
		for(int i=0; i< quantity.length(); i++)
		{
			if(Character.isDigit(quantity.charAt(i)))
			{
				continue;
			}
			else
			{
				invalidInput = true;
				break;
			}
		}
		
		if(invalidInput == true)
		{
			//write error message here, return back to page
			
			session.setAttribute("errorMsg", "ERROR: Quantity entered is invalid");
			RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp");
			dispatcher.forward(request,response);
			return;
		}
		else
		{
			session.setAttribute("errorMsg", "");
			//clear error message
		}
		Integer quantityInt = Integer.parseInt(quantity);
		
	
		
		if(stockSymbol.endsWith(".AX")!=true)
		{
			System.out.println("doesnt contrain .AX");
			stockSymbol = stockSymbol + ".AX";
			System.out.println("new stock symbol: " + stockSymbol);
			
		}
		
		Stock stock = sm.getSingleStock(stockSymbol);
		System.out.println(stock);
		if(stock == null)
		{
			//error message here, return back to page
			session.setAttribute("errorMsg", "ERROR: stock does not exist");
			RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp");
			dispatcher.forward(request,response);
			return;
		}
		
		
		
		if(request.getParameter("buy").equals("buy"))
		{
			System.out.println("buy selected");
			buy = request.getParameter("buy").toString();
			if(request.getParameter("price").equals("market"))
			{
				System.out.println("market selected");
				market = request.getParameter("price").toString();
				session.setAttribute("errorMsg", "");
				RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp");
				dispatcher.forward(request,response);
				return;
				//TODO
			}
			else
			{
				System.out.println("limit selected");
				//limit = request.getParameter("price").toString();
				System.out.println("quantity entered: " + quantityInt);
				System.out.println("stock entered: " + stockSymbol);
				
				if(request.getParameter("limitValue") ==null | request.getParameter("limitValue") == "")
				{
					System.out.println("limit is empty");
					session.setAttribute("errorMsg", "Error, Limit is Empty");
					RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp");
					dispatcher.forward(request,response);
					return;
				}
				else
				{
					System.out.println("limit is not empty");
					strLimit = request.getParameter("limitValue").toString();
					convertLimitVal = new BigDecimal(strLimit);
					System.out.println(convertLimitVal);
				}
				
				if(convertLimitVal != null)
				{
					session.setAttribute("errorMsg", "");
					sm.bidOrder(player.getUserName(), stockSymbol, convertLimitVal, quantityInt);
					RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp");
					dispatcher.forward(request,response);
					return;
				}
				
				//sm.bidOrder(player.getUserName(), stockSymbol, convertLimitVal, quantityInt);
			}
		}
		else
		{
			System.out.println("sell selected");
			if(request.getParameter("price").equals("market"))
			{
				System.out.println("sell market selected");
				session.setAttribute("errorMsg", "");
				RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp");
				dispatcher.forward(request,response);
				return;
				//TODO
			}
			else
			{
				System.out.println("sell limit selected");
				//limit = request.getParameter("limit").toString();
				System.out.println("quantity entered: " + quantityInt);
				System.out.println("stock entered: " + stockSymbol);
				
				if(request.getParameter("limitValue") ==null | request.getParameter("limitValue") == "")
				{
					System.out.println("limit is empty");
					session.setAttribute("errorMsg", "ERROR: Limit is empty");
					RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp");
					dispatcher.forward(request,response);
					
				}
				else
				{
					System.out.println("limit is not empty");
					strLimit = request.getParameter("limitValue").toString();
					convertLimitVal = new BigDecimal(strLimit);
					System.out.println(convertLimitVal);
				}
				
				if(convertLimitVal != null)
				{
					session.setAttribute("errorMsg", "");
					sm.bidOrderSell(player.getUserName(), stockSymbol, convertLimitVal, quantityInt);
					RequestDispatcher dispatcher = request.getRequestDispatcher("trading.jsp");
					dispatcher.forward(request,response);
				}
				
				//sm.bidOrderSell(player.getUserName(), stockSymbol, new BigDecimal(0.90), quantityInt);
			}
		}
		
		
		 //Fdatabase.addPlayer(new Player());
		
		 //PrintWriter out=response.getWriter();
		 /* At the moment this servlet is only used for testing buy and sell requests until a page can be built for user input */
		/* ShareMarket sm = new ShareMarket();
		 Stock stock = sm.getSingleStock("MMJ.AX");
		 stock.getQuote().getPrice();
		 System.out.println("hi");
		 BigDecimal b = new BigDecimal(0.80);
		 System.out.println("process sell");
		 sm.amendSell("ruff", stock.getSymbol(), b, 400);*/
		 
		 
		 System.out.println("hellooo");
		 
		 
		//ArrayList<CPstock> portfolio = player.getPortfolio();
		
		//sm.calculateProfitLoss(portfolio);
		 
		 /*ArrayList<Requests>allBuyRequests = new ArrayList<Requests>();
		 allBuyRequests = database.getAllBuyRequests();
		 for(int i=0; i< allBuyRequests.size();i++)
		 {
			 System.out.println("username: " + allBuyRequests.get(i).getUsername());
			 System.out.println("quantity: " + allBuyRequests.get(i).getQuantity());
		 }
		 
		 ArrayList<Requests>allSellRequests = new ArrayList<Requests>();
		 allSellRequests = database.getAllSellRequests();
		 for(int i=0; i< allSellRequests.size();i++)
		 {
			 System.out.println("username: " + allSellRequests.get(i).getUsername());
			 System.out.println("quantity: " + allSellRequests.get(i).getQuantity());
		 }
		 Stock stock = sm.getSingleStock("CPH.AX");
		 database.addToPlayerPortfolio("ruff", stock, 1000, new BigDecimal(9000));*/
		 //database.removeFromPlayerPortfolio("ruff", stock, 1000, new BigDecimal(4000));
		 
		 
		 
		 //ShareMarket sm = new ShareMarket();
		 //Stock stock = sm.getSingleStock("MMJ.AX");
		 
		 //stock.print();
		 //BigDecimal b = stock.getQuote().getPrice();
		 //System.out.println(b);
		 //sm.bidOrder("ruff", stock.getSymbol(), b, 100);
		// sm.amendBuy("ruff", stock.getSymbol(), new BigDecimal(0.60), 100);
		 
	 }
}
