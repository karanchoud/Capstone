/**
 * 
 */
package unitTests;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;

import org.junit.Test;

import app.ServletMain;
import model.CPstock;
import model.Player;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

/**
 * @author Dan
 *
 */
public class MarketOrderTest 
{
	
	private Player testPlayer;
	private ServletMain server;
	private Stock stock;
	private BigDecimal stockPrice;
	private int quantity = 1;
	
	private BigDecimal expectedRemainingFunds;
	
	private CPstock expectedStock; //the expected stock in the first round of buying
	
	private CPstock expectedStock2; //the stock values of the second stock bought with a different symbol
	
	private Stock stock2; //stores the stock data from the third marketOrder
	
	private BigDecimal stockPrice2;
	

	@Before
	public void setUp() throws Exception 
	{
		testPlayer = new Player("username", "password", "firstName", "lastName","testID","email");
		server = new ServletMain();
		
		stock = YahooFinance.get("YHOO");
		
		stock2 = YahooFinance.get("INTC");
		
		stockPrice = stock.getQuote().getAsk();
		
		stockPrice2 = stock2.getQuote().getAsk();
		
		expectedRemainingFunds = testPlayer.getFunds().subtract(stockPrice);
		
		expectedStock = new CPstock(stock,1);
		
		expectedStock2 = new CPstock(stock2,1);
				
		server.getDatabase().addPlayer(testPlayer);
				
	}

	@Test
	public void test() 
	{		
		assertTrue(server.getDatabase().getPlayerMap().size() == 1);
				
		server.marketOrder(testPlayer.getID(), "YHOO", stockPrice, quantity); //purchase a stock at market price (ask price)
		
		assertTrue("player should have 1 stock in their portfolio",testPlayer.getPortfolio().size() == 1);
		
		assertEquals(expectedRemainingFunds,testPlayer.getFunds());
		
		assertEquals(expectedStock.getStock().getQuote().getAsk(), testPlayer.getPortfolio().get(0).getStock().getQuote().getAsk());
		
		assertEquals(expectedStock.getStock().getName(), testPlayer.getPortfolio().get(0).getStock().getName());
		
		assertEquals(expectedStock.getQuantity(),testPlayer.getPortfolio().get(0).getQuantity());
		
		
		server.marketOrder(testPlayer.getID(), "YHOO", stockPrice, quantity); //purchase a second stock with the same symbol
		
		
		assertEquals(expectedStock.getQuantity() + 1,testPlayer.getPortfolio().get(0).getQuantity());
		
		
		
		server.marketOrder(testPlayer.getID(), "INTC", stockPrice2, quantity); //purchase a third stock with a different symbol
		
		assertEquals(expectedStock2.getQuantity(),testPlayer.getPortfolio().get(1).getQuantity());
		
		assertEquals(expectedStock2.getStock().getSymbol(),testPlayer.getPortfolio().get(1).getStock().getSymbol());
				
	}
	
}





















