/**
 * 
 */
package model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * @author Dan
 *
 */
public class Leaderboard 
{
	private ArrayList<LPlayer> playerLeaderBoard;

	public Leaderboard() 
	{
		this.playerLeaderBoard = new ArrayList<LPlayer>();
	}
	
	public void ShowTopPlayers(int playerNum)
	{
		sortLeaderBoard();
		
		for(int i = 0; i < playerNum; i++)
		{
			System.out.println(playerLeaderBoard.get(i).getPlayerName() + " " + "totalFunds: $" + playerLeaderBoard.get(i).getTotalFunds());
		}
		//TODO list the top players on the leaderBoard
		//size of the list is from user input e.g playerNum = 10; list the top 10 players
	}
	
	public void ShowTopPlayers()
	{
		sortLeaderBoard();
		
		for(LPlayer player: playerLeaderBoard)
		{
			System.out.println(player.getPlayerName() +" :$" + player.getTotalFunds());
		}
		
	
		
		//returns the entire leaderBoard
	}
	
	public void addPlayerToLeaderBoard(Player player)
	{
		LPlayer lPlayer = new LPlayer(player);
		
		playerLeaderBoard.add(lPlayer);
		
		this.sortLeaderBoard();
	}
	
	public void removePlayerFromLeaderBoard(String playerID)
	{
		for(LPlayer player: playerLeaderBoard)
		{
			if(player.getID().equals(playerID))
			{
				playerLeaderBoard.remove(player);
				
				System.out.println("Removed player: " + player.getPlayerName() + "ID: " + player.getID());
			}
			else
			{
				System.out.println("ERROR: player not found on leaderboard....");
			}
		}
		
		
		
		
	}
	
	
	private void sortLeaderBoard()
	{
		//sorts the leader board
		Collections.sort(playerLeaderBoard, new Comparator<LPlayer>()
		{
			@Override
			public int compare(LPlayer player1, LPlayer player2) //overrides the compare method to compare LPlayer objects
			{
				//return player1.getTotalFunds().intValue() - player2.getTotalFunds().intValue(); //acending order
				
				if(player1.getTotalFunds().doubleValue() > player2.getTotalFunds().doubleValue()) //if player1 has more funds than player2
				{
					return -1;
				}
				
				if(player1.getTotalFunds().doubleValue() < player2.getTotalFunds().doubleValue()) //if player1 has less funds than player2
				{
					return 1;
				}
				else //the values are even
				{
					return 0;
				}				
			}
		});
		
	}
	
	public void generateTestPlayers(int playerNum) //generates a set of random players specified by playerNum with random amount of funds
	{
		for( int i = 0; i < playerNum; i ++)
		{
			Random rand = new Random();
			int randFunds = rand.nextInt(50000);
			Player player = new Player("username" + Integer.toString(i),"password","firstName" + Integer.toString(i), "lastName" + Integer.toString(i), "IDNUM" + Integer.toString(i),"email");
			
			player.setFunds(new BigDecimal(randFunds));
			
			player.setTotalFunds(new BigDecimal(randFunds));
			
			this.addPlayerToLeaderBoard(player);
			
			this.sortLeaderBoard();
		}
	}
		
	public ArrayList<LPlayer> getPlayerLeaderBoard() 
	{
		return playerLeaderBoard;
	}

	public class LPlayer // a simplified player class to be used on the leader board 
	{	
		private String playerID;
		private String playerName;
		private BigDecimal funds;
		private BigDecimal equityFunds; //the amount of money invested in stock
		private BigDecimal totalFunds;
		
		
		public LPlayer(Player player)
		{
			playerName = player.getFirstName();
			funds = player.getFunds();
			equityFunds = player.getEquityFunds();
			totalFunds = player.getTotalFunds();
			
			playerID = player.getID();
		}

		public String getID()
		{
			return playerID;
		}
		public String getPlayerName() 
		{
			return playerName;
		}


		public void setPlayerName(String playerName) 
		{
			this.playerName = playerName;
		}


		public BigDecimal getFunds() 
		{
			return funds;
		}


		public void setFunds(BigDecimal funds) 
		{
			this.funds = funds;
		}


		public BigDecimal getEquityFunds() 
		{
			return equityFunds;
		}


		public void setEquityFunds(BigDecimal equityFunds) 
		{
			this.equityFunds = equityFunds;
		}


		public BigDecimal getTotalFunds() 
		{
			return totalFunds;
		}


		public void setTotalFunds(BigDecimal totalFunds) 
		{
			this.totalFunds = totalFunds;
		}
	}	
}
