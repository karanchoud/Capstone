package model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.UUID;


public class Player 
{
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	private String ID;
	private BigDecimal funds;
	private BigDecimal equityFunds; //the amount of money invested in stock
	private BigDecimal totalFunds;
	private ArrayList<CPstock> portfolio;
	private String email;
	
	//TODO add email to constructor
	
	public Player(String userName, String password, String firstName, String lastName, String ID, String email) 
	{
		
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
		this.email = email;
		funds = new BigDecimal(10000);
		portfolio = new ArrayList<CPstock>();
		
	}
	
	
	
	
	//database return constructor
	public Player(String userName, String password, String firstName, String lastName, String ID, BigDecimal funds,ArrayList<CPstock> portfolio, String email) 
	{	
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
		this.funds = funds;
		this.portfolio = portfolio;
		this.email = email;
	}




	/*
	public Player(String userName, String password, String firstName, String lastName, String ID, BigDecimal funds,BigDecimal equityFunds, BigDecimal totalFunds, ArrayList<CPstock> portfolio, String email) 
	{
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
		this.funds = funds;
		this.equityFunds = equityFunds;
		this.totalFunds = totalFunds;
		this.portfolio = portfolio;
		this.email = email;
	}

	*/

	public Player()
	{
		userName = "dummyPlayer";
		password = "password";
		firstName = "firstName";
		lastName = "lastName";
		ID = UUID.randomUUID().toString();
		funds = new BigDecimal(50000);
		portfolio = new ArrayList<CPstock>();
	}

	/*public Player(String firstName, String lastName,String ID,BigDecimal funds,ArrayList<CPstock> portfolio) 
	{
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
		this.funds = funds;
		this.portfolio = portfolio;
	}
	*/
	public void buyStock(String stockSSymbol, double price, int stockCount)
	{
		
	}
	
	public void sellStock()
	{
		
	}
	
	public void listCurrentStock()
	{
		
	}
	
	public void ammendOrder() //change 
	{
		
	}
	
	
	
	
	
	
	
	//getters and setters
	public String getFirstName() 
	{
		return firstName;
	}


	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}


	public String getLastName() 
	{
		return lastName;
	}


	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}


	public String getID() 
	{
		return ID;
	}


	public void setID(String iD) 
	{
		ID = iD;
	}


	public ArrayList<CPstock> getPortfolio() 
	{
		return portfolio;
	}


	public void setPortfolio(ArrayList<CPstock> portfolio) 
	{
		this.portfolio = portfolio;
	}

	public void setFunds(BigDecimal funds) 
	{
		this.funds = funds;
		// TODO Auto-generated method stub
		
	}

	public BigDecimal getFunds() {
		// TODO Auto-generated method stub
		return funds;
	}
	
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public BigDecimal getEquityFunds() {
		return equityFunds;
	}

	public void setEquityFunds(BigDecimal equityFunds) {
		this.equityFunds = equityFunds;
	}

	public BigDecimal getTotalFunds() {
		return totalFunds;
	}

	public void setTotalFunds(BigDecimal totalFunds) {
		this.totalFunds = totalFunds;
	}

	
	
}
