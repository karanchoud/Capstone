package model;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

//import javax.resource.cci.ResultSet;

public class Database //used to store player IDs, current stock data owned by players, and player account info


{

	
	Connection conn;
	HashMap<String,Player> playerMap = new HashMap<String,Player>();
	
	private static Database database = new Database();
	
	public static Database getInstance()
	{
		return database;
	}
	
	public Database()
	{
		
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://166.62.28.123:3306/stockmarketDB", "stockMarketAdmin", "passs");
		

		} catch (SQLException ex) {
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		} 
		catch (ClassNotFoundException e) {
			System.out.println("Where is your MySQL JDBC Driver?");
			e.printStackTrace();
			return;
		}

		System.out.println("connection established!");
		
		
	}
	
	
	//String user, String pass, String first, String last, String email
	public boolean addPlayer(String user, String pass, String first, String last, String email)
	{
		
		 Statement st;
		 int valid = 1;
		
			 try {
				 	st = conn.createStatement();
			
				 	//here we authenticate 
				 	String id = UUID.randomUUID().toString();
				 	//String id = "myid";
				 	String searchQuery = "SELECT * FROM Player WHERE username='"+user+"'";
				 	
				 	ResultSet rs =  st.executeQuery(searchQuery);
				 	if(rs.next())
				 		{
				 			valid = 0;
				 		}
				 if(valid == 0)
				 	{
				//duplicate found reset while loop and try again
					 	//valid = 1;
					 System.out.println("Duplicate Found!");
					 	return false; 
				 	//	continue;
				 	}
				 
				//valid = 2;
				
			//String query = "INSERT INTO test VALUES(1006, 'Karan', 'Choudhary')";
			String realQuery = "INSERT INTO Player VALUES('"+id+"', '"+user+"', '"+pass+"', '"+first+"', '"+last+"', '"+email+"', 1000000)";
			st.executeUpdate(realQuery);
			
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		}
		
	 //}
		 return true;
	}
	
	
	public void addPlayer(Player player)
	{
		//add the player to the hashmap
		 Statement st;
		try {
			st = conn.createStatement();
			String query = "INSERT INTO test VALUES(1004, 'Adrian', 'Riscica')";
			st.executeUpdate(query);
			
			//conn.close();
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}                                 

				 

			
		
		
		
		
		
		
		
		/* daniel's initial code */
		/*if(playerMap.containsKey(player.getID()))
		{
			System.out.println("ERROR player ID already exists");
			return false;
			
		}
		else
		{
			playerMap.put(player.getID(),player);
			return true;
		}*/
		
		
		
	}
	
	
	
	
	
	public boolean authPlayer(String passedInputUser, String passedInputPass)
	{
		//login functionality
		 Statement st;
		 String dbPass;
		
			 try {
				 	st = conn.createStatement();
			
				 	//here we authenticate 
				 	String inputUser = passedInputUser; // user must be unique, these will be passed in as parameters
				 	String inputPass = passedInputPass;
				 	
				 	String searchQuery = "SELECT * FROM Player WHERE username='"+inputUser+"'"; // ***playerID needs to change to Username column***
				 	
				 	ResultSet rs =  st.executeQuery(searchQuery);
				 	if(rs.next())
				 		{
				 			//result found, valid username exists, now check for pass
				 			//dbUser = rs.getString(1); //dbUsername
				 			dbPass = rs.getString(3); //dbPassword
				 			if(dbPass.equals(inputPass))
				 				{
				 					//password match
				 					System.out.println("User and Pass match returning true");
				 					return true;
				 				}	 			
				 		}
				 	else
				 		{
				 			System.out.println("No user with that username returning false");
				 			return false;
				 		}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		}
		
		 System.out.println("password didnt match but user does exist, returning false");
		 return false;
	}
	
	public Player getPlayer(String inputUser)
	{
		
		
		 Statement st;
		 Player loadPlayer = null;
		 
		
			 try {
				 	st = conn.createStatement();
			
				 	//here we authenticate 
				 	
				 	
				 	String getPlayerQuery = "SELECT * FROM Player WHERE username='"+inputUser+"'"; // ***playerID needs to change to Username column***
				 	ResultSet rs =  st.executeQuery(getPlayerQuery);
				 	if(rs.next())
				 	{
				 		System.out.println("extracting player details");
				 		String id = rs.getString(1);
				 		String username = rs.getString(2);
				 		String password = rs.getString(3);
				 		String firstName = rs.getString(4);
				 		String lastName = rs.getString(5);
				 		String email = rs.getString(6);
				 		BigDecimal funds = new BigDecimal(rs.getDouble(7));
				 		
				 		ArrayList<CPstock> portfolio = getPlayerPortfolio(username);
				 		
				 		loadPlayer = new Player(username, password, firstName, lastName, id,funds,portfolio,email);
				 	}
				 return loadPlayer;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		}
		
		
		
		//if this returns here, it returns a null object suggesting something has gone wrong
		return loadPlayer;
	}
	
	
	private ArrayList<CPstock> getPlayerPortfolio(String username)
	{
		ArrayList<CPstock >portfolio = new ArrayList<CPstock>();
		Statement st;
		
		
			 try {
				 	st = conn.createStatement();
			
				 	//here we authenticate 
				 	
				 	
				 	String getPortfolioQuery = "SELECT * FROM Portfolio WHERE username='"+username+"'"; // ***playerID needs to change to Username column***
				 	ResultSet rs =  st.executeQuery(getPortfolioQuery);
				 	
				 	while(rs.next())
				 	{
				 		//extract portfolio record data here and build portfolio arraylist
				 		String recordUsername = rs.getString(1);
				 		String stockSymbol = rs.getString(2);
				 		int stockQuantity = rs.getInt(3);
				 		
				 		Stock stock = null;
				 		stock = YahooFinance.get(stockSymbol);
				 		
				 		CPstock portfolioItem = new CPstock(stock, stockQuantity);
				 		portfolio.add(portfolioItem);
				 	}
				
				 	if(rs.first() == false)
				 	{
				 		System.out.println("No portfolio objects found");
				 		//portfolio = null; i've commented this out because i want an empty list in the case that theres no objects to rebuild a complete player object
				 		return portfolio;
				 	}
				 	
				 return portfolio;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("hello world");
		} catch (IOException eIO)
			 {
			eIO.printStackTrace();
			
			 }
		
		
		
		return portfolio;
	}
	
	
	public boolean addToPlayerPortfolio(String username, Stock stock, int quantity)
	{
		Statement st;
		
		
		 try {
			 	st = conn.createStatement();
		
			 	
			 	String stockSym = stock.getSymbol();
			 	
			 	String getPortfolioQuery = "SELECT * FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'"; // ***playerID needs to change to Username column***
			 	ResultSet rs = st.executeQuery(getPortfolioQuery);
			 	
			 	if(rs.next())
			 	{
			 		//record exists therefore, add quantity to portfolio item
			 		int dbQuantity = rs.getInt(4);
			 		quantity = dbQuantity + quantity;
			 		String amendPortfolioQuery = "UPDATE Portfolio SET stockquantity='"+quantity+"' WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'";
			 		st.executeUpdate(amendPortfolioQuery);
			 		return true;
			 	}
			 	else
			 	{
			 		String addPortfolioQuery = "INSERT INTO Portfolio(username, stocksymbol, stockquantity) VALUES('"+username+"', '"+stockSym+"', '"+quantity+"')"; // ***playerID needs to change to Username column***
			 		st.executeUpdate(addPortfolioQuery);
			 		return true;
			 	}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
	
		
		return false;
		
	}
	
	
	public int removePlayerPortfolioItem(String username, Stock stock, int quantity)
	{
		
		Statement st;
		
		
		 try {
			 	st = conn.createStatement();
		
			 	//here we authenticate 
			 	String stockSym = stock.getSymbol();
			 	
			 	String getPortfolioQuery = "SELECT * FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'"; // ***playerID needs to change to Username column***
			 	ResultSet rs = st.executeQuery(getPortfolioQuery);
			 	//TODO continue from this point, we obtained correct stock
			 	if(rs.next())
			 	{
			 		int dbQuantity = rs.getInt(4);
			 		if(quantity < dbQuantity)
			 		{
			 			//amend record here
			 			quantity = dbQuantity - quantity;
			 			String amendQuery = "UPDATE Portfolio SET stockquantity='"+quantity+"' WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'";
			 			st.executeUpdate(amendQuery);
			 			return 1; // update successful
			 		}
			 		else
			 		{
			 			//delete record here
			 			String deleteQuery = "DELETE FROM Portfolio WHERE username='"+username+"' AND stocksymbol='"+stockSym+"'";
			 			st.executeUpdate(deleteQuery);
			 			return 1;
			 		}
			 		
			 	}
			 	else
			 	{
			 		System.out.println("no record found");
			 		return 0; // no record found
			 	}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("hello world");
	}
	
		
		return 0;
		
	}
	

	public Player findPlayer(String playerID) //find the corresponding player within the map and return them
	{
		Player player = playerMap.get(playerID);
		
		
		return player;
	}

	public HashMap<String, Player> getPlayerMap() {
		return playerMap;
	}

	public void setPlayerMap(HashMap<String, Player> playerMap) {
		this.playerMap = playerMap;
	}

	public boolean checkPlayerID(String playerID, String userName) 
	{
		
		return true;
	}
	
	
	
}
