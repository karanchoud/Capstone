package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.CPstock;
import model.FAKEDatabase;
import model.Leaderboard;
import model.ShareMarket;
import model.Player;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

/**
 * The main HTTPServlet Application for the stock market program. Handles all player requests when
 * playing the game, buying, selling and trading stock. 
 * @author Daniel Lenders s3388091@student.rmit.edu.au
 *
 */

@SuppressWarnings("serial")
public class ServletMain extends HttpServlet
{	
	
	private FAKEDatabase database = FAKEDatabase.getInstance(); //stores player info
	
	private Leaderboard LB = new Leaderboard();
	
	private ShareMarket shareMarket = new ShareMarket(database);
	
	/**
	 * Handles all get method requests from the jsp pages
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException //returning stocks and player field updates
	{	
		System.out.println("testing?");
		
		String playerSingleStock = req.getParameter("singleStock");
		
		String[] stockList = req.getParameterValues("stockarray");
		
		//TODO stock symbol validation and sanitation
		
		if(playerSingleStock != null) //if the form submitted contained a request for 1 stocks data
		{
			//Stock stock = YahooFinance.get(playerSingleStock);
			
			Stock stock = shareMarket.getSingleStock(playerSingleStock);
			
			req.setAttribute("singleStockReq", stock);
		}
		
		if(stockList != null)
		{
			Map<String,Stock> stockMap; //map to store stock info
			
			stockMap = YahooFinance.get(stockList); //API request for stock info
			
			printStockmap(stockMap); //print stock map mainly here for testing values
			
			//return the stockmap to the user			
		}
		
		
		System.out.println(playerSingleStock);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp?singleStockReq=good"); //return all info back to the client
		dispatcher.forward(req,resp);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException //handles buy sell requests from player
	{
		/*PrintWriter out = resp.getWriter();
		
		System.out.println("the server received a post request");
		
		
		if(req.getParameter("registerForm") != null)
		{
			req.getParameter("registerForm");
			
			System.out.println("request form is working??");
			
			String firstName = req.getParameter("name");
			
			String lastName = req.getParameter("lastName");
			
			String userName = req.getParameter("username");
			
			String password = req.getParameter("password");
			
			System.out.println(firstName);			
			System.out.println(lastName);
			System.out.println(userName);
			System.out.println(password);
			
			
			database.addPlayer(userName,password,firstName,lastName);
			
		}
		
		*/
		
				
	}
	
	public void loginPlayer(String userName, String password)
	{
		
	}
	
	
	
	
	
	
	
	private static void printStockmap(Map<String,Stock> stockMap) //prints all stock info from a map
	{
		for(Entry<String,Stock> mapEntry : stockMap.entrySet()) //loop through each entry in the map
		{
			//String currentKey = mapEntry.getKey();
			//System.out.println(currentKey);
			Stock currentStock = mapEntry.getValue(); //assigns the map key's value to a stock object
						
			currentStock.print(); //print the current stock's info
		}
	}
	
	/**
	 * Makes a call to the Yahoo finance API for stock information.
	 * @param stockSymbol - The Symbol used to represent a company's stock.
	 * @return
	 * 
	 * A stock object containing all information regarding that stock
	 */
	public Stock getSingleStock(String stockSymbol) //makes a call to the Yahoo finance API for a stock's latest information
	{
		Stock stock;
		try 
		{
			stock = YahooFinance.get(stockSymbol);
			
			return stock;
		} 
		catch (IOException e) 
		{
			System.out.println("ERROR: Invalid stock symbol returning NULL");
			e.printStackTrace();
		}
		
		return null;
	}
	/**
	 * allows players to purchase stock and add stock to their port folio. updates player funds accordingly
	 * 
	 * @param playerID  - The players unique ID to the server.
	 * @param stockSymbol - The Symbol used to represent a company's stock. 
	 * @param stockPrice - The price the player is willing to buy the stock at.
	 * @param quantity - The amount of stock the Player is trying to buy.
	 */
	public void marketOrder(String playerID, String stockSymbol, BigDecimal stockPrice, int quantity) //a player order that will buy stock at the current ask price of the stock
	{
		Stock stock = getSingleStock(stockSymbol);
		
		if(stock.getQuote().getAsk().equals(stockPrice)) //if the player bid matches the stocks current ask price
		{
			System.out.println("Market order match found processing order......");
			
			Player currentPlayer = database.findPlayer(playerID); //retrieve the player object from the database
			
			BigDecimal checkFunds = calcNewFunds(currentPlayer,stockPrice,quantity); //verify the player can afford to purchase the stock(s)
			
			if(checkFunds != null) //if they can afford to buy the stock at market price
			{
				currentPlayer.setFunds(checkFunds); //update the players funds
				//TODO calculate equity funds
				//currentPlayer.setEquityFunds(equityFunds);
				
				addStock(currentPlayer,stock,quantity); //adds the stock to the players portfolio
				
			}
			
		}
		else
		{
			System.out.println("stock ask price does not match player bid, unable to complete Market Order");
		}
		
		
	}
	/**
	 * Allows the player to sell their stock on the market at the current asking price
	 * 
	 * @param playerID - Identifies the player
	 * @param stockSymbol - the symbol used to identify the stock
	 * @param stockPrice - the price the stock will be sold at (the current asking price at the time)
	 * @param quantity - the amount of stock being sold in the transaction
	 */
	public void marketOrderSell(String playerID, String stockSymbol, BigDecimal stockPrice, int quantity) //sells player stock at market ask price
	{
		Stock stock = getSingleStock(stockSymbol);
		
		if(stock.getQuote().getAsk().equals(stockPrice))
		{
			System.out.println("sell price matches current Ask price processing.....");
			
			Player currentPlayer = database.findPlayer(playerID);
			
			if(removeStock(currentPlayer,stock,quantity)) //if the player's stock request is valid and removed
			{
				BigDecimal totalProfit = stockPrice.multiply(new BigDecimal(quantity)); //calculate the players profit
				
				currentPlayer.setFunds(currentPlayer.getFunds().add(totalProfit)); //add the profits to the players funds
				
				System.out.println("Market Order sell transaction completed.....");
			}
			else
			{
				System.out.println("market order cancelled.. removeStock returned false");
			}			
		}
		
		
		
	}
	/**
	 * Removes a stock from the Player's portfolio
	 * 
	 * @param currentPlayer
	 * @param stock
	 * @param quantity
	 * @return
	 */
	private boolean removeStock(Player currentPlayer, Stock stock, int quantity) //remove stock from the players port folio
	{
		for(int i = 0; i < currentPlayer.getPortfolio().size(); i ++) //loop through the players port folio
		{
			if(currentPlayer.getPortfolio().get(i).getStock().getSymbol().equals(stock.getSymbol())) //if the stock exists in the player port folio 
			{
				int oldQuantity = currentPlayer.getPortfolio().get(i).getQuantity(); 
				
				int newQuantity = oldQuantity - quantity;
				
				if(oldQuantity < quantity)
				{
					System.out.println("ERROR: player trying to sell more stock then they own...");
					return false;
				}
				
				
				if(newQuantity == 0)
				{
					currentPlayer.getPortfolio().remove(i); //if the player doesn't own any stock in the company anymore
					
					return true;
				}
				else
				{
					currentPlayer.getPortfolio().get(i).setQuantity(newQuantity); //remove the amount of stock being sold
					return true;
				}
			}
		}
		
		return false;
		
	}
	/**
	 * adds a CPstock object to the player's port folio
	 * or increases the quantity if a player already owns a number of that stock
	 * @param currentPlayer - The player object
	 * @param stock - the stock to be added
	 * @param quantity - the amount of stock being added
	 */
	private void addStock(Player currentPlayer,Stock stock,int quantity) //adds the stock to the players portfolio
	{
		for(int i = 0; i < currentPlayer.getPortfolio().size(); i++) //loop through the list of currently owned stocks
		{
			if(currentPlayer.getPortfolio().get(i).getStock().getSymbol().equals(stock.getSymbol())) //if the player has invested in this stock before
			{
				currentPlayer.getPortfolio().get(i).setQuantity(quantity + currentPlayer.getPortfolio().get(i).getQuantity()); //increase the quantity of owned stock
				
				System.out.println("Market Order purchase completed...increased quantity of existing stock: " + stock.getSymbol());
				return;
			}
		}
		//if the player doesnt own any of this stock create a new stock and add it to the port folio				
		currentPlayer.getPortfolio().add(new CPstock(stock,quantity)); //adds the purchased stock to the player's portfolio
		
		System.out.println("Market Order purchase completed added new stock to portfolio: " + stock.getSymbol());	
	}
	
	public BigDecimal calcNewFunds(Player player, BigDecimal stockPrice, int quantity) //deducts the current purchase from the players total
	{
		BigDecimal newTotal = player.getFunds(); //current funds before the purchase
		
		if(quantity == 1)
		{
			newTotal = newTotal.subtract(stockPrice);
			
			if(newTotal.compareTo(BigDecimal.ZERO) >= 0) //if the exchange doesn't put the players funds into negative
			{
				return newTotal; //return the new total
			}
			else
			{
				System.out.println("not enough funds");
				return null;
			}
		}
		else
		{
			BigDecimal totalCost = stockPrice.multiply(new BigDecimal(quantity)); //the cost to buy all the stock in the order
			
			newTotal = newTotal.subtract(totalCost);
			
			if(newTotal.compareTo(BigDecimal.ZERO) >= 0) //if the exchange doesn't put the players funds into negative
			{
				return newTotal; //return the new total
			}
			else
			{
				System.out.println("not enough funds");
				return null;
			}
			
		}	
	}
	
	/**
	 * Returns the amount of money a player has in stock
	 * @param player
	 * @return
	 */
	private BigDecimal calcEquityFunds(Player player) //calculates the players equity funds after purchase
	{
		BigDecimal equityFunds = new BigDecimal(0);
		
		for(CPstock stock: player.getPortfolio())
		{
			equityFunds = equityFunds.add(stock.getStock().getQuote().getAsk().multiply(new BigDecimal(stock.getQuantity()))); //current ask price * quantity of stock
		}
		
		return equityFunds;
	}
	/**
	 * returns the total amount of money a player has on the stock market in actual money and amount invested into stock
	 * @param player
	 */
	private void calcTotalFunds(Player player) //calculates the players total amount of money based on current stock investments and money
	{
		BigDecimal totalFunds = new BigDecimal(0);
		
		totalFunds = player.getFunds().add(player.getEquityFunds());
	}
	
	public FAKEDatabase getDatabase()
	{
		return database;
	}
	
	public Player createPlayer(String userName, String pass, String firstName, String lastName)
	{
		
		String playerID = UUID.randomUUID().toString();
		
		if(database.checkPlayerID(playerID,userName))
		{
			Player newPlayer = new Player(userName, pass, firstName, lastName, playerID, "email");
			
			return newPlayer;
		}
		
		
		return null;
	}
	
	public Leaderboard getLeaderBoard() 
	{
		return LB;
	}
	/**
	 * calculates and applies the purchase tax for purchasing stock on the market
	 */
	public void applyPurchaseBrokerFee(Player player, BigDecimal stockPrice)
	{
		BigDecimal brokerageFee = new BigDecimal(50); //base cost of 50
		
		BigDecimal purchaseTax = stockPrice.divide(new BigDecimal(100).divide(new BigDecimal(0.25))); 
		
		brokerageFee  = brokerageFee.add(purchaseTax);
		
		player.setFunds(player.getFunds().subtract(brokerageFee));
		
	}
	
	/**
	 * calculates and applies the sales tax for selling stock on the market
	 * @param player
	 * @param stockPrice
	 */
	public void applySalesBrokerFee(Player player, BigDecimal stockPrice)
	{
		BigDecimal brokerageFee = new BigDecimal(50); //base cost of 50
		
		BigDecimal saleTax = stockPrice.divide(new BigDecimal(100).divide(new BigDecimal(1.0))); //calculate the sales tax
		
		brokerageFee  = brokerageFee.add(saleTax); //calculate the total brokerage fee
		
		player.setFunds(player.getFunds().subtract(brokerageFee)); //apply brokerage tax

	}
	
	
}
